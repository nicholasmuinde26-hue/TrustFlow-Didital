/**
 * ============================================================================
 * CONTRIBUTION PAYMENT ROUTES
 * ============================================================================
 *
 * API routes for contribution payments.
 *
 * Responsibilities
 * ----------------
 * ✓ Define endpoints
 * ✓ Attach middleware
 * ✓ Connect controllers
 *
 * DOES NOT
 * --------
 * ✗ Process payments
 * ✗ Validate business rules
 * ✗ Handle accounting
 *
 * ============================================================================
 */


import express from "express";


import contributionPaymentController
    from "./contributionPayment.controller.js";


// Future:
// import authMiddleware from "../../shared/middleware/auth.middleware.js";
// import authorize from "../../shared/middleware/authorize.middleware.js";


const router = express.Router();





/**
 * ============================================================================
 * CREATE MANUAL PAYMENT
 * ============================================================================
 *
 * POST
 *
 * /api/contributions/payments
 *
 * Example:
 *
 * {
 *    obligationId:"123",
 *    amount:500,
 *    paymentMethod:"MPESA"
 * }
 *
 */


router.post(

    "/",

    // authMiddleware,

    contributionPaymentController.createPayment

);







/**
 * ============================================================================
 * PAYMENT PROVIDER CALLBACK
 * ============================================================================
 *
 * POST
 *
 * /api/contributions/payments/callback
 *
 *
 * External providers:
 *
 * M-Pesa
 * Banks
 * Payment gateways
 *
 */


router.post(

    "/callback",

    contributionPaymentController.paymentCallback

);






export default router;