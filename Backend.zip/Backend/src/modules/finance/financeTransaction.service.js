/**
 * ============================================================================
 * FINANCIAL TRANSACTION SERVICE
 * ============================================================================
 *
 * Immutable recorder of financial events.
 *
 * This service records WHAT happened.
 * It does NOT decide HOW accounting should happen.
 *
 * ============================================================================
 */

import FinancialTransaction from "../../models/FinancialTransaction.js";

import {
    TRANSACTION_STATUS
} from "./accounting/accounting.constants.js";

class FinanceTransactionService {

    /**
     * ------------------------------------------------------------
     * CREATE
     * ------------------------------------------------------------
     */

    async create(context, session = null) {

        const transaction = await FinancialTransaction.create([{

            transactionType: context.transactionType,

            amount: context.amount,

            currency: context.currency,

            chama: context.chama,

            member: context.member,

            provider: context.provider,

            payment: context.payment,

            payout: context.payout,

            obligation: context.obligation,

            reference: context.reference,

            providerReference:
                context.providerReference,

            externalReference:
                context.externalReference,

            narration:
                context.narration,

            metadata:
                context.metadata,

            correlationId:
                context.correlationId,

            status:
                TRANSACTION_STATUS.PENDING

        }], { session });

        return transaction[0];

    }

    /**
     * ------------------------------------------------------------
     * MARK COMPLETED
     * ------------------------------------------------------------
     */

    async markCompleted(id, session = null) {

        return FinancialTransaction.findByIdAndUpdate(

            id,

            {

                status: TRANSACTION_STATUS.COMPLETED,

                completedAt: new Date()

            },

            {

                new: true,

                session

            }

        );

    }

    /**
     * ------------------------------------------------------------
     * MARK FAILED
     * ------------------------------------------------------------
     */

    async markFailed(id, reason, session = null) {

        return FinancialTransaction.findByIdAndUpdate(

            id,

            {

                status: TRANSACTION_STATUS.FAILED,

                failureReason: reason

            },

            {

                new: true,

                session

            }

        );

    }

    /**
     * ------------------------------------------------------------
     * FIND
     * ------------------------------------------------------------
     */

    async findById(id) {

        return FinancialTransaction.findById(id);

    }

    /**
     * ------------------------------------------------------------
     * CORRELATION
     * ------------------------------------------------------------
     */

    async findByCorrelationId(correlationId) {

        return FinancialTransaction.findOne({

            correlationId

        });

    }

    /**
     * ------------------------------------------------------------
     * PROVIDER REFERENCE
     * ------------------------------------------------------------
     */

    async findByProviderReference(reference) {

        return FinancialTransaction.findOne({

            providerReference: reference

        });

    }

}

export default new FinanceTransactionService();