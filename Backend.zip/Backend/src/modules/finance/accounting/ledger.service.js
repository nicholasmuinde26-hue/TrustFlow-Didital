/**
 * ============================================================================
 * LEDGER SERVICE
 * ============================================================================
 *
 * Generates balanced ledger entries for an existing Journal.
 *
 * Responsibilities
 * ----------------
 * ✓ Read accounting rules
 * ✓ Generate ledger entries
 * ✓ Validate journal
 * ✓ Persist ledger entries
 * ✓ Return posting aggregate
 *
 * DOES NOT
 * --------
 * ✗ Create journals
 * ✗ Create financial transactions
 * ✗ Update account balances
 * ✗ Know about Contributions or Payouts
 *
 * ============================================================================
 */

import LedgerEntry from "../../../models/LedgerEntry.js";

import { ACCOUNTING_RULES } from "./accounting.rules.js";

import {
    ENTRY_TYPES,
    POSTING_STATUS
} from "./accounting.constants.js";

import journalValidator from "./journal.validator.js";

class LedgerService {

    /**
     * ============================================================
     * POST JOURNAL
     * ============================================================
     */

    async post(journal, transaction, session = null) {

        const rule = ACCOUNTING_RULES[transaction.transactionType];

        if (!rule) {

            throw new Error(

                `No accounting rule defined for '${transaction.transactionType}'.`

            );

        }

        const entries = [];

        let totalDebit = 0;

        let totalCredit = 0;

        /**
         * --------------------------------------------------------
         * Generate Entries
         * --------------------------------------------------------
         */

        for (const line of rule.entries) {

            const entry = {

                journal: journal._id,

                transaction: transaction._id,

                chama: transaction.chama,

                member: transaction.member,

                account: line.account,

                type: line.type,

                amount: transaction.amount,

                currency: transaction.currency,

                provider: transaction.provider,

                reference: transaction.reference,

                description: line.description,

                status: POSTING_STATUS.POSTED,

                metadata: {

                    correlationId:
                        transaction.correlationId,

                    source:
                        rule.source,

                    payment:
                        transaction.payment,

                    obligation:
                        transaction.obligation,

                    payout:
                        transaction.payout

                }

            };

            entries.push(entry);

            if (entry.type === ENTRY_TYPES.DEBIT) {

                totalDebit += Number(entry.amount);

            }

            else {

                totalCredit += Number(entry.amount);

            }

        }

        /**
         * --------------------------------------------------------
         * Validate Journal
         * --------------------------------------------------------
         */

        journalValidator.validate(

            journal,

            entries

        );

        /**
         * --------------------------------------------------------
         * Persist Entries
         * --------------------------------------------------------
         */

        const savedEntries = await LedgerEntry.insertMany(

            entries,

            {

                session

            }

        );

        /**
         * --------------------------------------------------------
         * Update Journal Totals
         * --------------------------------------------------------
         */

        journal.totalDebit = totalDebit;

        journal.totalCredit = totalCredit;

        await journal.save({

            session

        });

        /**
         * --------------------------------------------------------
         * Return Aggregate
         * --------------------------------------------------------
         */

        return {

            journal,

            entries: savedEntries,

            debit: totalDebit,

            credit: totalCredit,

            balanced:

                totalDebit === totalCredit

        };

    }

    /**
     * ============================================================
     * BUILD REVERSAL ENTRIES
     * ============================================================
     */

    buildReversalEntries(entries = []) {

        return entries.map(entry => ({

            ...entry.toObject(),

            _id: undefined,

            journal: undefined,

            createdAt: undefined,

            updatedAt: undefined,

            type:

                entry.type === ENTRY_TYPES.DEBIT

                    ? ENTRY_TYPES.CREDIT

                    : ENTRY_TYPES.DEBIT,

            description:

                `Reversal - ${entry.description}`

        }));

    }

    /**
     * ============================================================
     * GET JOURNAL ENTRIES
     * ============================================================
     */

    async getJournalEntries(journalId) {

        return LedgerEntry.find({

            journal: journalId

        }).sort({

            createdAt: 1

        });

    }

}

export default new LedgerService();