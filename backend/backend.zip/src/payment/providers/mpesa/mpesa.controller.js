import crypto from 'node:crypto';
import ContributionObligation from '../../../models/ContributionObligation.js';
import ChamaMembership from '../../../models/ChamaMembership.js';
import ContributionGroupMember from '../../../models/ContributionGroupMember.js';
import PaymentIntent from '../../../models/PaymentIntent.js';
import AppError from '../../../utils/AppError.js';


import { reconcileB2cResult } from '../../../modules/business/business.service.js';
import { reconcileSavingsCallback, maybeCreateMgrPayoutForChama } from '../../../modules/chama/chamaFinance.service.js'; 
import MpesaAttempt from '../../../models/MpesaAttempt.js';
import paymentService from '../../../payment/payment.service.js';
import phoneUtil from '../../../utils/phone.js';

const generateUniqueReference = (displayRef) => {
  const ts = Date.now();
  const rand = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `${displayRef}-${ts}-${rand}`.slice(0, 100);
};

/**
 * ============================================================
 * GENERIC STK PUSH - FOR SAVINGS, CONTRIBUTION, MGR
 * ============================================================
 */
export const initiateStkPush = async (req, res, next) => {
  try {
    const {
      amount,
      phoneNumber,
      productType, // 'savings' | 'contribution' | 'mgr'
      chamaId,
      obligationId,
      planId,
      accountReference,
      transactionDescription,
      idempotencyKey,
    } = req.body;

    if (!amount) throw new AppError("Payment amount is required", 400);
    if (!phoneNumber) throw new AppError("M-Pesa phone number is required", 400);
    if (!['savings', 'contribution', 'mgr'].includes(productType)) throw new AppError("productType is required", 400);

    const userId = req.user?.id || req.user?._id;
    if (!userId) throw new AppError("Authenticated user is required", 401);

    const membership = await ChamaMembership.findOne({ chama_id: chamaId, user_id: userId, status: 'active' }).lean();
    if (!membership) throw new AppError('You are not a member of this chama', 403);

    // planId isn't always sent by the client - derive it from the obligation
    // when we have one. ContributionPayment requires plan_id, so without this
    // a contribution/mgr STK push fails DB validation.
    let resolvedPlanId = planId;
    if (!resolvedPlanId && obligationId) {
      const obligation = await ContributionObligation.findById(obligationId).select('plan_id').lean();
      if (!obligation) throw new AppError('Contribution obligation not found', 404);
      resolvedPlanId = obligation.plan_id;
    }
    if (['contribution', 'mgr'].includes(productType) && !resolvedPlanId) {
      throw new AppError('planId is required for contribution payments', 400);
    }

    const key = idempotencyKey || req.get('Idempotency-Key') || crypto.randomUUID();
    const normalizedPhone = phoneUtil.normalize(phoneNumber);
    const displayRef = (accountReference || `CHAMA-${productType.toUpperCase()}`).slice(0, 20);
    const uniqueRef = generateUniqueReference(displayRef);

    // Delegate everything to PaymentService
    const result = await paymentService.initiate({
        amount,
        currency: 'KES',
        type: productType, // CRITICAL: this routes to correct GL later
        chamaId,
        obligationId,
        planId: resolvedPlanId,
        participantId: membership._id,
        participantType: "ChamaMembership",
        phoneNumber: normalizedPhone,
        actorId: userId,
        provider: 'mpesa',
        reference: uniqueRef,
        displayReference: displayRef,
        description: transactionDescription || `Chama ${productType} payment`,
        idempotencyKey: key
    });

    // Create MpesaAttempt for tracking
    await MpesaAttempt.create({
        obligation_id: obligationId,
        payment_intent_id: result.paymentIntentId,
        amount,
        phone_number: normalizedPhone,
        initiated_by: userId,
        checkout_request_id: result.checkoutRequestId,
        status: 'pending'
    });

    return res.status(202).json({
        success: true,
        message: result.providerResponse.customerMessage || 'M-Pesa STK Push initiated successfully',
        data: { 
            paymentIntentId: result.paymentIntentId,
            paymentId: result.paymentId,
            reference: result.reference,
            checkoutRequestId: result.checkoutRequestId,
            customerMessage: result.providerResponse.customerMessage
        },
    });

  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "Duplicate payment detected. Please wait 10 seconds and try again." });
    }
    next(error);
  }
};

/**
 * Backward compatibility
 */
export const initiateContributionStkPush = initiateStkPush;

/**
 * ============================================================
 * M-PESA CALLBACK - SINGLE SOURCE OF TRUTH: PAYMENT SERVICE
 * ============================================================
 */
export const handleMpesaCallback = async (req, res) => {
  try {
    const callbackBody = req.body;
    
    // 1. Let PaymentService process it. It updates Intent, Payment, and EMITS EVENT
    await paymentService.handleCallback(callbackBody);

    // 2. Update MpesaAttempt for UI tracking
    const stk = callbackBody?.Body?.stkCallback;
    if (stk?.CheckoutRequestID) {
      const success = Number(stk.ResultCode) === 0;
      await MpesaAttempt.findOneAndUpdate(
        { checkout_request_id: stk.CheckoutRequestID },
        { 
            status: success ? 'completed' : 'failed',
            mpesa_receipt_number: success ? stk.CallbackMetadata?.Item?.find(i => i.Name === 'MpesaReceiptNumber')?.Value : null,
            result_description: stk.ResultDesc
        }
      );
    }

    // 3. Legacy: Check if MGR round is complete and trigger payout
    // FinanceEngine already posted GL via event. This just checks payout rules
    const intent = await PaymentIntent.findOne({ provider_request_id: stk?.CheckoutRequestID });
    if (intent?.type === 'mgr' && intent.status === 'completed') {
        await maybeCreateMgrPayoutForChama(intent.owner_id, intent.created_by).catch(() => null);
    }

    return res.status(200).json({ ResultCode: 0, ResultDesc: "Callback processed successfully" });

  } catch (error) {
    console.error("M-Pesa callback processing error:", error.message);
    // Safaricom requires 200 even on error
    return res.status(200).json({ ResultCode: 0, ResultDesc: "Callback received" });
  }
};

export const handleB2cResult = async (req, res) => {
  try {
    await reconcileB2cResult(req.body);
  } catch (error) {
    console.error("M-Pesa B2C result processing error:", error);
  }
  return res.status(200).json({ ResultCode: 0, ResultDesc: "Result received" });
};

export const queryMpesaPayment = async (req, res, next) => {
  try {
    const { checkoutRequestId } = req.body;
    if (!checkoutRequestId) return res.status(400).json({ success: false, message: "CheckoutRequestID is required" });
    const result = await paymentService.query({ provider: 'mpesa', checkoutRequestId });
    return res.status(200).json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
};

export const getPaymentIntentStatus = async (req, res, next) => {
  try {
    const { paymentIntentId } = req.params;
    const intent = await PaymentIntent.findById(paymentIntentId).lean();
    if (!intent) return res.status(404).json({ success: false, message: "Payment intent not found" });
    const userId = req.user?.id || req.user?._id;
    if (String(intent.created_by) !== String(userId)) return res.status(403).json({ success: false, message: "Not authorized" });

    return res.status(200).json({ success: true, data: intent });
  } catch (error) {
    next(error);
  }
};