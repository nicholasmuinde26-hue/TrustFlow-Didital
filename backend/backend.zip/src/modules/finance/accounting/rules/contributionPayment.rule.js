/**
 * ============================================================================
 * CONTRIBUTION PAYMENT ACCOUNTING RULE
 * ============================================================================
 */

import mongoose from "mongoose";
import FinancialAccount from "../../../../models/FinancialAccount.js";

const canUseTransactions = () => {
  const topology = mongoose.connection?.client?.topology;
  return topology?.description?.type === "ReplicaSetWithPrimary" || topology?.description?.type === "Sharded";
};

// FIXED: added :
const getOpts = (session) => canUseTransactions() && session? { session } : {};

class ContributionPaymentRule {

    name = "CONTRIBUTION_PAYMENT";

    async resolveAccounts(context, session = null) {
        const opts = getOpts(session);

        // FIX: owner_type/owner_id never exist at the top level of the
        // event object passed in from financeEngine.post() — they only
        // exist nested under event.context / event.metadata. Reading
        // context.owner_type/owner_id directly (as this used to) always
        // resolved to undefined, which mongoose silently drops from the
        // query — meaning FinancialAccount.findOne() below could match
        // ANY chama's account, not just this one.
        const inner = context?.context || {};
        const metadata = context?.metadata || inner?.metadata || {};

        const owner_type =
            context?.owner_type ||
            inner?.owner_type ||
            metadata?.owner_type ||
            "Chama";

        const owner_id =
            context?.owner_id ||
            inner?.owner_id ||
            inner?.chamaId ||
            inner?.chama_id ||
            metadata?.owner_id ||
            metadata?.chamaId ||
            metadata?.chama_id;

        if (!owner_id) {
            console.error("[ContributionPaymentRule] Missing owner_id.", { context, metadata });
            throw new Error("owner_id is required for contribution payment");
        }

        const paymentMethod = metadata?.payment_method || metadata?.paymentMethod || 'cash';

        const assetAccountCodeMap = {
            cash: 'CASH',
            bank: 'BANK',
            mpesa: 'MPESA_CLEARING'
        };
        let assetAccountCode = assetAccountCodeMap[paymentMethod] || 'CASH';

        let assetAccount = await FinancialAccount.findOne({
            owner_type, owner_id, account_code: assetAccountCode
        }, null, opts);

        if (!assetAccount && assetAccountCode === 'MPESA_CLEARING') {
            assetAccount = await FinancialAccount.findOne({
                owner_type, owner_id, account_code: 'BANK'
            }, null, opts);
            if (assetAccount) {
                console.warn(`MPESA_CLEARING not found. Falling back to BANK for ${owner_id}`);
            }
        }

        let equityAccount = await FinancialAccount.findOne({
            owner_type, owner_id, account_code: "MEMBER_CONTRIBUTIONS"
        }, null, opts);

        if (!assetAccount ||!equityAccount) {
            // FIX: pass session so bootstrap is atomic
            await FinancialAccount.bootstrapSystemAccounts({
              owner_type,
              owner_id,
              created_by: context.created_by
            }, session);

            if (!assetAccount) {
                assetAccount = await FinancialAccount.findOne({
                    owner_type, owner_id, account_code: assetAccountCode
                }, null, opts);
            }
            if (!equityAccount) {
                equityAccount = await FinancialAccount.findOne({
                    owner_type, owner_id, account_code: "MEMBER_CONTRIBUTIONS"
                }, null, opts);
            }
        }

        if (!assetAccount) {
            throw new Error(`${assetAccountCode} account not configured.`);
        }
        if (!equityAccount) {
            throw new Error("MEMBER_CONTRIBUTIONS account not configured.");
        }

        return {
            debitAccount: assetAccount._id,
            creditAccount: equityAccount._id
        };
    }

    async build(context, session = null) {
        const accounts = await this.resolveAccounts(context, session);

        return {
            transactionType: "CONTRIBUTION_PAYMENT",
            referenceType: "CONTRIBUTION_PAYMENT",
            referenceId: context.referenceId,
            organization: context.organization,
            entries: [
                {
                    account_id: accounts.debitAccount,
                    entryType: "DEBIT",
                    amount: context.amount,
                    description: `Contribution payment ${context.referenceId}`
                },
                {
                    account_id: accounts.creditAccount,
                    entryType: "CREDIT",
                    amount: context.amount,
                    description: `Contribution payment ${context.referenceId}`
                }
            ],
            metadata: {
                member: context.metadata?.participant_id,
                contributionPlan: context.metadata?.contribution_plan_id,
                obligation_id: context.metadata?.obligation_id,
                payment_method: context.metadata?.payment_method
            }
        };
    }
}

export default new ContributionPaymentRule();