import { Link } from "react-router-dom";

export default function DashboardLayout({ children }) {
  return (
    <div className="min-h-screen flex">
      <aside className="w-64 bg-gray-100 p-4">
        <h2 className="text-lg font-bold mb-4">Chama Manager</h2>
        <nav className="flex flex-col gap-2">
          <Link to="/dashboard" className="hover:underline">Dashboard</Link>
          <Link to="/members" className="hover:underline">Members</Link>
          <Link to="/finance" className="hover:underline">Finance</Link>
        </nav>
      </aside>

      <div className="flex-1 min-h-screen">
        <header className="bg-white shadow p-4">Header</header>
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}