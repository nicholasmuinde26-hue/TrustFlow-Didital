// src/modules/auth/hooks/useUpdateProfile.js

import { useMutation, useQueryClient } from "@tanstack/react-query";

import {
  updateProfile,
} from "../services/auth.service";

export default function useUpdateProfile() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateProfile,

    onSuccess: (updatedUser) => {
      queryClient.setQueryData(
        ["auth", "me"],
        updatedUser
      );

      queryClient.invalidateQueries({
        queryKey: ["auth", "me"],
      });

      queryClient.invalidateQueries({
        queryKey: ["members"],
      });
    },
  });
}