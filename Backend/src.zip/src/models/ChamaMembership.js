import mongoose from 'mongoose';


// ========================================
// CHAMA MEMBERSHIP
// ========================================
//
// A User can belong to many Chamas.
//
// User
//  │
//  ├── Chama A → Treasurer
//  ├── Chama B → Member
//  └── Chama C → Auditor
//
// This document represents the relationship
// between ONE User and ONE Chama.
//
// ========================================


// ========================================
// MEMBERSHIP ROLES
// ========================================

const MEMBERSHIP_ROLES = [

  'member',

  'treasurer',

  'secretary',

  'auditor',

  'chairperson',

];


// ========================================
// MEMBERSHIP STATUS
// ========================================

const MEMBERSHIP_STATUS = [

  'active',

  'inactive',

  'suspended',

  'removed',

];


// ========================================
// CHAMA MEMBERSHIP SCHEMA
// ========================================

const chamaMembershipSchema =

  new mongoose.Schema(

    {

      // ======================================
      // USER
      // ======================================
      //
      // The global User identity.
      //
      // A User can have multiple memberships
      // across different Chamas.
      //
      // ======================================

      userId: {

        type:
          mongoose.Schema.Types.ObjectId,

        ref:
          'User',

        required: true,

        index: true,

      },


      // ======================================
      // CHAMA
      // ======================================
      //
      // The Chama this membership belongs to.
      //
      // ======================================

      chamaId: {

        type:
          mongoose.Schema.Types.ObjectId,

        ref:
          'Chama',

        required: true,

        index: true,

      },


      // ======================================
      // ROLE
      // ======================================
      //
      // The user's role inside THIS Chama.
      //
      // Example:
      //
      // User A
      //   ├── Chama A → Treasurer
      //   ├── Chama B → Member
      //   └── Chama C → Auditor
      //
      // Role is therefore scoped to the
      // membership, not the User.
      //
      // ======================================

      role: {

        type:
          String,

        enum:
          MEMBERSHIP_ROLES,

        default:
          'member',

        required: true,

        index: true,

      },


      // ======================================
      // MEMBERSHIP STATUS
      // ======================================
      //
      // Controls the lifecycle of membership.
      //
      // active
      // inactive
      // suspended
      // removed
      //
      // ======================================

      status: {

        type:
          String,

        enum:
          MEMBERSHIP_STATUS,

        default:
          'active',

        required: true,

        index: true,

      },


      // ======================================
      // PAYOUT POSITION
      // ======================================
      //
      // Used for simple rotational Chamas.
      //
      // Example:
      //
      // Member A → Position 1
      // Member B → Position 2
      // Member C → Position 3
      //
      // For advanced rotations, this can later
      // move into a dedicated RotationParticipant
      // model.
      //
      // ======================================

      payoutPosition: {

        type:
          Number,

        min:
          1,

        default:
          null,

      },


      // ======================================
      // INVITED BY
      // ======================================
      //
      // User who invited this member.
      //
      // ======================================

      invitedBy: {

        type:
          mongoose.Schema.Types.ObjectId,

        ref:
          'User',

        default:
          null,

      },


      // ======================================
      // JOINED DATE
      // ======================================

      joinedAt: {

        type:
          Date,

        default:
          Date.now,

        immutable: true,

      },


      // ======================================
      // ACCEPTED DATE
      // ======================================
      //
      // Useful when we implement invitations.
      //
      // Example:
      //
      // Invitation Sent
      //       ↓
      // Member Accepts
      //       ↓
      // acceptedAt = Date
      //
      // ======================================

      acceptedAt: {

        type:
          Date,

        default:
          null,

      },


      // ======================================
      // REMOVED DATE
      // ======================================

      removedAt: {

        type:
          Date,

        default:
          null,

      },


      // ======================================
      // REMOVED BY
      // ======================================
      //
      // User who removed this member.
      //
      // ======================================

      removedBy: {

        type:
          mongoose.Schema.Types.ObjectId,

        ref:
          'User',

        default:
          null,

      },

    },

    {

      // Automatically adds:
      //
      // createdAt
      // updatedAt
      //
      timestamps: true,

    }

  );


// ========================================
// UNIQUE MEMBERSHIP CONSTRAINT
// ========================================
//
// A user can only have ONE membership
// record for a specific Chama.
//
// User A + Chama A
//       ↓
// ONE membership
//
// User A + Chama B
//       ↓
// ANOTHER membership
//
// ========================================

chamaMembershipSchema.index(

  {

    userId: 1,

    chamaId: 1,

  },

  {

    unique: true,

    name:
      'unique_user_chama_membership',

  }

);


// ========================================
// CHAMA MEMBERS LOOKUP
// ========================================
//
// Efficiently find members of a Chama.
//
// Example:
//
// GET /chamas/:chamaId/members
//
// ========================================

chamaMembershipSchema.index({

  chamaId: 1,

  status: 1,

});


// ========================================
// ROLE LOOKUP
// ========================================
//
// Efficiently find members by role.
//
// Example:
//
// Find all active auditors
// in a specific Chama.
//
// ========================================

chamaMembershipSchema.index({

  chamaId: 1,

  role: 1,

  status: 1,

});


// ========================================
// USER MEMBERSHIP LOOKUP
// ========================================
//
// Efficiently find all Chamas
// belonging to a specific User.
//
// ========================================

chamaMembershipSchema.index({

  userId: 1,

  status: 1,

  createdAt: -1,

});


// ========================================
// EXPORT MODEL
// ========================================

const ChamaMembership =

  mongoose.model(

    'ChamaMembership',

    chamaMembershipSchema

  );


export default ChamaMembership;