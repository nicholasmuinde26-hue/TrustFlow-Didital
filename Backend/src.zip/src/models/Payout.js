import mongoose from 'mongoose';

const payoutSchema = new mongoose.Schema(
  {
    // ========================================
    // CHAMA
    // ========================================

    chama_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Chama',
      required: true,
      index: true
    },


    // ========================================
    // RECIPIENT
    // ========================================

    member_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Member',
      required: true
    },


    // ========================================
    // PAYOUT POSITION
    // ========================================

    payout_position: {
      type: Number,
      required: true
    },


    // ========================================
    // AMOUNT
    // ========================================

    amount: {
      type: Number,
      required: true,
      min: 0
    },


    // ========================================
    // STATUS
    // ========================================

    status: {
      type: String,

      enum: [
        'pending',
        'paid',
        'cancelled'
      ],

      default: 'pending',

      index: true
    },


    // ========================================
    // PAYMENT DATE
    // ========================================

    paid_at: {
      type: Date,
      default: null
    },


    // ========================================
    // CANCEL DATE
    // ========================================

    cancelled_at: {
      type: Date,
      default: null
    }
  },

  {
    timestamps: true
  }
);


// ========================================
// PREVENT MULTIPLE ACTIVE PAYOUTS
// ========================================

payoutSchema.index(
  {
    chama_id: 1,
    status: 1
  }
);


export default mongoose.model(
  'Payout',
  payoutSchema
);