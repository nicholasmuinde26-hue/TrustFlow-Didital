import mongoose from 'mongoose';

import ContributionPayment
  from '../models/ContributionPayment.js';

import ContributionObligation
  from '../models/ContributionObligation.js';

import AppError
  from '../utils/AppError.js';

import {
  createContributionPayment,
  completeContributionPayment,
  failContributionPayment,
  cancelContributionPayment,
  getContributionPaymentById,
  getContributionPaymentByExternalReference,
  getContributionPaymentByProviderTransaction
} from '../modules/contributionPlan/contributionPayment.service.js';

import {
  validateObjectId,
  validateOwnerType,
  validateParticipantType,
  validateOwnerParticipantCompatibility,
  validatePaymentAmount,
  validateCurrency,
  validatePaymentChannel,
  validatePaymentMethod,
  validateProvider,
  validateProviderTransactionId,
  validateExternalReference,
  validateIdempotencyKey
}  from '../modules/contributionPlan/contributionPayment.service.js';


// ============================================================
// PAYMENT SERVICE
// ============================================================
//
// This service is the payment orchestration layer.
//
// It connects:
//
// Payment API
//      │
//      ▼
// Payment Service
//      │
//      ├── ContributionPayment Service
//      │
//      └── Payment Provider
//
// IMPORTANT
//
// This service DOES NOT directly:
//
// - Update ContributionObligation
// - Create FinancialTransaction
// - Update FinancialAccount
// - Create LedgerEntry
//
// Those responsibilities remain inside the hardened
// contribution payment + finance engine services.
//
// ============================================================


// ============================================================
// CONSTANTS
// ============================================================

const PAYMENT_CHANNEL = {

  CASH:
    'cash',

  MPESA:
    'mpesa',

  BANK:
    'bank',

  MOBILE_MONEY:
    'mobile_money',

  CARD:
    'card',

  TRANSFER:
    'transfer',

  OTHER:
    'other'

};


const PAYMENT_PROVIDER = {

  MPESA:
    'mpesa',

  MANUAL:
    'manual',

  BANK:
    'bank',

  OTHER:
    'other'

};


const PAYMENT_STATUS = {

  PENDING:
    'pending',

  COMPLETED:
    'completed',

  FAILED:
    'failed',

  CANCELLED:
    'cancelled',

  REVERSED:
    'reversed'

};


// ============================================================
// VALIDATE PAYMENT REQUEST
// ============================================================
//
// Common validation for payment initiation.
//
// ============================================================

const validatePaymentRequest = ({
  obligation_id,
  owner_type,
  owner_id,
  participant_type,
  participant_id,
  amount,
  currency,
  payment_channel,
  payment_method,
  created_by
}) => {

  validateObjectId(
    obligation_id,
    'contribution obligation ID'
  );

  validateOwnerType(
    owner_type
  );

  validateObjectId(
    owner_id,
    'owner ID'
  );

  validateParticipantType(
    participant_type
  );

  validateObjectId(
    participant_id,
    'participant ID'
  );

  validateOwnerParticipantCompatibility({

    owner_type,

    participant_type

  });

  validatePaymentAmount(
    amount
  );

  validateCurrency(
    currency
  );

  validatePaymentChannel(
    payment_channel
  );

  if (
    payment_method
  ) {

    validatePaymentMethod(
      payment_method
    );

  }

  validateObjectId(
    created_by,
    'payment creator ID'
  );

};


// ============================================================
// LOAD OBLIGATION FOR PAYMENT
// ============================================================

const loadPaymentObligation = async ({
  obligation_id,
  owner_type,
  owner_id,
  participant_type,
  participant_id,
  session
}) => {

  const obligation =
    await ContributionObligation
      .findOne({

        _id:
          obligation_id,

        owner_type,

        owner_id,

        participant_type,

        participant_id

      })
      .session(session);

  if (
    !obligation
  ) {

    throw new AppError(
      'Contribution obligation not found or does not belong to the specified participant',
      404
    );

  }

  return obligation;

};


// ============================================================
// CREATE GENERIC PAYMENT
// ============================================================
//
// This is the common entry point for payment creation.
//
// For cash:
//    creates + completes payment.
//
// For digital:
//    creates pending payment.
//
// Provider-specific services then continue the lifecycle.
//
// ============================================================

export const initiateContributionPayment = async ({
  obligation_id,
  owner_type,
  owner_id,
  participant_type,
  participant_id,

  amount,

  currency = 'KES',

  payment_channel,

  payment_method = null,

  payment_instrument_id = null,

  payment_instrument_snapshot = null,

  provider = null,

  external_reference = null,

  idempotency_key = null,

  description = '',

  paid_at = null,

  initiated_at = null,

  recorded_by = null,

  created_by,

  posted_by = null,

  payment_account_id = null,

  notes = '',

  session = null
}) => {

  validatePaymentRequest({

    obligation_id,

    owner_type,

    owner_id,

    participant_type,

    participant_id,

    amount,

    currency,

    payment_channel,

    payment_method,

    created_by

  });


  const normalizedCurrency =
    validateCurrency(
      currency
    );


  const normalizedProvider =
    validateProvider(
      provider
    );


  const normalizedExternalReference =
    validateExternalReference(
      external_reference
    );


  const normalizedIdempotencyKey =
    validateIdempotencyKey(
      idempotency_key
    );


  // ==========================================================
  // LOAD OBLIGATION
  // ==========================================================

  const obligation =
    await loadPaymentObligation({

      obligation_id,

      owner_type,

      owner_id,

      participant_type,

      participant_id,

      session

    });


  // ==========================================================
  // CREATE CONTRIBUTION PAYMENT
  // ==========================================================

  const result =
    await createContributionPayment({

      obligation_id,

      owner_type,

      owner_id,

      participant_type,

      participant_id,

      amount,

      currency:
        normalizedCurrency,

      payment_channel,

      payment_method,

      payment_instrument_id,

      payment_instrument_snapshot,

      provider:
        normalizedProvider,

      external_reference:
        normalizedExternalReference,

      idempotency_key:
        normalizedIdempotencyKey,

      description,

      paid_at,

      initiated_at,

      recorded_by,

      created_by,

      posted_by,

      payment_account_id,

      notes,

      session

    });


  return {

    ...result,

    obligation:

      result.obligation ||
      obligation

  };

};


// ============================================================
// INITIATE M-PESA CONTRIBUTION PAYMENT
// ============================================================
//
// IMPORTANT
//
// This function creates the ContributionPayment record first.
//
// It does NOT call Safaricom yet.
//
// The M-Pesa service will:
//
// 1. Create the pending payment.
// 2. Send STK Push.
// 3. Save provider identifiers.
//
// This separation prevents M-Pesa code from becoming tightly
// coupled to financial accounting.
//
// ============================================================

export const initiateMpesaContributionPayment = async ({
  obligation_id,
  owner_type,
  owner_id,
  participant_type,
  participant_id,

  amount,

  currency = 'KES',

  phone_number,

  idempotency_key,

  payment_instrument_id = null,

  payment_instrument_snapshot = null,

  external_reference = null,

  description = '',

  recorded_by = null,

  created_by,

  notes = '',

  session = null
}) => {

  // ==========================================================
  // VALIDATE PHONE NUMBER
  // ==========================================================

  if (
    !phone_number ||
    typeof phone_number !==
    'string'
  ) {

    throw new AppError(
      'M-Pesa phone number is required',
      400
    );

  }


  const normalizedPhone =
    phone_number
      .trim();


  if (
    !normalizedPhone
  ) {

    throw new AppError(
      'M-Pesa phone number is required',
      400
    );

  }


  // ==========================================================
  // VALIDATE IDEMPOTENCY
  // ==========================================================

  const normalizedIdempotencyKey =
    validateIdempotencyKey(
      idempotency_key
    );


  // ==========================================================
  // CREATE PENDING PAYMENT
  // ==========================================================

  const result =
    await initiateContributionPayment({

      obligation_id,

      owner_type,

      owner_id,

      participant_type,

      participant_id,

      amount,

      currency,

      payment_channel:
        PAYMENT_CHANNEL.MPESA,

      payment_method:
        PAYMENT_CHANNEL.MPESA,

      payment_instrument_id,

      payment_instrument_snapshot: {

        ...(
          payment_instrument_snapshot ||
          {}
        ),

        phone_number:
          normalizedPhone

      },

      provider:
        PAYMENT_PROVIDER.MPESA,

      external_reference,

      idempotency_key:
        normalizedIdempotencyKey,

      description,

      recorded_by,

      created_by,

      notes,

      session

    });


  return {

    ...result,

    phone_number:
      normalizedPhone,

    requiresProviderCompletion:
      true

  };

};


// ============================================================
// COMPLETE PROVIDER PAYMENT
// ============================================================
//
// This is the generic provider completion bridge.
//
// M-Pesa callback will eventually call this function.
//
// The actual accounting is delegated to:
//
// completeContributionPayment()
//
// ============================================================

export const completeProviderContributionPayment = async ({
  payment_id,

  provider_transaction_id,

  provider_status = 'success',

  external_reference = null,

  callback_received_at = null,

  payment_account_id,

  created_by,

  posted_by = null,

  description = '',

  session = null
}) => {

  validateObjectId(

    payment_id,

    'contribution payment ID'

  );


  const normalizedProviderTransactionId =
    validateProviderTransactionId(

      provider_transaction_id

    );


  if (
    !normalizedProviderTransactionId
  ) {

    throw new AppError(
      'Provider transaction ID is required to complete a provider payment',
      400
    );

  }


  const normalizedExternalReference =
    validateExternalReference(

      external_reference

    );


  // ==========================================================
  // LOAD PAYMENT
  // ==========================================================

  const payment =
    await getContributionPaymentById({

      payment_id,

      session

    });


  // ==========================================================
  // PROVIDER VALIDATION
  // ==========================================================

  if (
    payment.provider &&
    payment.provider !==
    PAYMENT_PROVIDER.MPESA
  ) {

    throw new AppError(
      `Payment belongs to provider "${payment.provider}" and cannot be completed as an M-Pesa payment`,
      409
    );

  }


  // ==========================================================
  // DELEGATE TO CONTRIBUTION PAYMENT SERVICE
  // ==========================================================

  return completeContributionPayment({

    payment_id,

    provider_transaction_id:
      normalizedProviderTransactionId,

    provider_status,

    external_reference:
      normalizedExternalReference,

    callback_received_at,

    payment_account_id,

    created_by,

    posted_by,

    description,

    session

  });

};


// ============================================================
// FAIL PROVIDER PAYMENT
// ============================================================

export const failProviderContributionPayment = async ({
  payment_id,

  provider_status = 'failed',

  failure_reason,

  callback_received_at = null,

  session = null
}) => {

  validateObjectId(

    payment_id,

    'contribution payment ID'

  );


  const payment =
    await getContributionPaymentById({

      payment_id,

      session

    });


  if (
    payment.provider &&
    payment.provider !==
    PAYMENT_PROVIDER.MPESA
  ) {

    throw new AppError(
      `Payment belongs to provider "${payment.provider}" and cannot be failed as an M-Pesa payment`,
      409
    );

  }


  return failContributionPayment({

    payment_id,

    provider_status,

    failure_reason,

    callback_received_at,

    session

  });

};


// ============================================================
// CANCEL PROVIDER PAYMENT
// ============================================================

export const cancelProviderContributionPayment = async ({
  payment_id,

  cancelled_by,

  cancellation_reason,

  session = null
}) => {

  validateObjectId(

    payment_id,

    'contribution payment ID'

  );


  const payment =
    await getContributionPaymentById({

      payment_id,

      session

    });


  if (
    payment.provider &&
    payment.provider !==
    PAYMENT_PROVIDER.MPESA
  ) {

    throw new AppError(
      `Payment belongs to provider "${payment.provider}" and cannot be cancelled as an M-Pesa payment`,
      409
    );

  }


  return cancelContributionPayment({

    payment_id,

    cancelled_by,

    cancellation_reason,

    session

  });

};

// ============================================================
// PROCESS M-PESA CALLBACK
// ============================================================
//
// This is the internal bridge between the M-Pesa provider
// callback and the ContributionPayment lifecycle.
//
// IMPORTANT:
//
// This function does NOT directly:
//
// - Update ContributionObligation
// - Create FinancialTransaction
// - Create LedgerEntry
// - Update FinancialAccount
//
// It delegates successful completion to:
//
// completeProviderContributionPayment()
//
// and failed payments to:
//
// failProviderContributionPayment()
//
// ============================================================

export const processMpesaCallback = async ({
  callback
}) => {

  if (!callback) {

    throw new AppError(
      'M-Pesa callback data is required',
      400
    );

  }


  // ==========================================================
  // EXTRACT CALLBACK IDENTIFIERS
  // ==========================================================

  const {
    checkoutRequestId,
    merchantRequestId,
    resultCode,
    resultDesc,
    mpesaReceiptNumber,
    transactionDate,
    phoneNumber,
    amount,
    externalReference
  } = callback;


  // ==========================================================
  // BASIC CALLBACK VALIDATION
  // ==========================================================

  if (!checkoutRequestId) {

    throw new AppError(
      'M-Pesa callback is missing CheckoutRequestID',
      400
    );

  }


  // ==========================================================
  // LOCATE PAYMENT
  // ==========================================================
  //
  // The preferred lookup should be CheckoutRequestID.
  //
  // This assumes mpesa.service.js saved the CheckoutRequestID
  // as the payment external reference or provider reference.
  //
  // We will refine this once we inspect your ContributionPayment
  // schema and mpesa.service.js.
  //
  // ==========================================================

  let payment =
    await getContributionPaymentByExternalReference({

      external_reference:
        checkoutRequestId

    });


  // ==========================================================
  // FALLBACK: EXTERNAL REFERENCE
  // ==========================================================

  if (
    !payment &&
    externalReference
  ) {

    payment =
      await getContributionPaymentByExternalReference({

        external_reference:
          externalReference

      });

  }


  // ==========================================================
  // PAYMENT NOT FOUND
  // ==========================================================

  if (!payment) {

    throw new AppError(
      `No contribution payment found for M-Pesa CheckoutRequestID: ${checkoutRequestId}`,
      404
    );

  }


  // ==========================================================
  // IDEMPOTENCY CHECK
  // ==========================================================
  //
  // M-Pesa/provider callbacks may be delivered more than once.
  //
  // If the payment has already reached a terminal state,
  // we must NOT post the transaction again.
  //
  // ==========================================================

  if (
    isPaymentCompleted({
      payment
    })
  ) {

    return {

      success: true,

      alreadyProcessed: true,

      message:
        'M-Pesa payment callback was already processed',

      payment

    };

  }


  // ==========================================================
  // FAILURE CALLBACK
  // ==========================================================
  //
  // Safaricom ResultCode !== 0 means the STK payment failed
  // or was cancelled.
  //
  // ==========================================================

  if (
    Number(resultCode) !== 0
  ) {

    const failedPayment =
      await failProviderContributionPayment({

        payment_id:
          payment._id,

        provider_status:
          'failed',

        failure_reason:
          resultDesc ||
          'M-Pesa payment failed',

        callback_received_at:
          new Date()

      });


    return {

      success: true,

      alreadyProcessed: false,

      payment:
        failedPayment,

      provider_status:
        'failed'

    };

  }


  // ==========================================================
  // SUCCESS CALLBACK VALIDATION
  // ==========================================================

  if (
    !mpesaReceiptNumber
  ) {

    throw new AppError(
      'Successful M-Pesa callback is missing M-Pesa receipt number',
      400
    );

  }


  // ==========================================================
  // COMPLETE PAYMENT
  // ==========================================================
  //
  // IMPORTANT:
  //
  // This delegates to the hardened contribution payment
  // service.
  //
  // That service is responsible for the financial pipeline.
  //
  // ==========================================================

  const completedPayment =
    await completeProviderContributionPayment({

      payment_id:
        payment._id,

      provider_transaction_id:
        mpesaReceiptNumber,

      provider_status:
        'success',

      external_reference:
        checkoutRequestId,

      callback_received_at:
        new Date(),

      // This should eventually come from the payment's
      // configured M-Pesa financial account.
      //
      // Do not hard-code this.
      payment_account_id:
        payment.payment_account_id,

      created_by:
        payment.created_by,

      posted_by:
        payment.created_by

    });


  return {

    success: true,

    alreadyProcessed: false,

    payment:
      completedPayment,

    provider_transaction_id:
      mpesaReceiptNumber,

    checkout_request_id:
      checkoutRequestId,

    merchant_request_id:
      merchantRequestId

  };

};


// ============================================================
// RESOLVE PAYMENT FROM M-PESA CALLBACK
// ============================================================
//
// The callback may identify a payment using:
//
// 1. CheckoutRequestID
// 2. External reference
// 3. Provider transaction ID
//
// The actual provider-specific matching will be implemented
// in mpesa.service.js.
//
// This function provides safe lookup helpers.
//
// ============================================================

export const findPaymentByProviderTransaction = async ({
  provider,
  provider_transaction_id,
  session = null
}) => {

  return getContributionPaymentByProviderTransaction({

    provider,

    provider_transaction_id,

    session

  });

};


// ============================================================
// FIND PAYMENT BY EXTERNAL REFERENCE
// ============================================================

export const findPaymentByExternalReference = async ({
  external_reference,

  owner_type = null,

  owner_id = null,

  session = null
}) => {

  return getContributionPaymentByExternalReference({

    external_reference,

    owner_type,

    owner_id,

    session

  });

};


// ============================================================
// GET PAYMENT
// ============================================================

export const getPayment = async ({
  payment_id,

  session = null
}) => {

  return getContributionPaymentById({

    payment_id,

    session

  });

};


// ============================================================
// CHECK PAYMENT COMPLETION
// ============================================================
//
// Used by provider callbacks.
//
// A repeated callback must never cause another financial
// transaction.
//
// ============================================================

export const isPaymentCompleted = ({
  payment
}) => {

  if (
    !payment
  ) {

    return false;

  }


  return (
    payment.status ===
    PAYMENT_STATUS.COMPLETED
  );

};


// ============================================================
// CHECK PAYMENT PENDING
// ============================================================

export const isPaymentPending = ({
  payment
}) => {

  if (
    !payment
  ) {

    return false;

  }


  return (
    payment.status ===
    PAYMENT_STATUS.PENDING
  );

};


// ============================================================
// CHECK PAYMENT TERMINAL STATE
// ============================================================

export const isPaymentTerminal = ({
  payment
}) => {

  if (
    !payment
  ) {

    return false;

  }


  return [

    PAYMENT_STATUS.COMPLETED,

    PAYMENT_STATUS.FAILED,

    PAYMENT_STATUS.CANCELLED,

    PAYMENT_STATUS.REVERSED

  ].includes(

    payment.status

  );

};


// ============================================================
// EXPORT CONSTANTS
// ============================================================

export {

  PAYMENT_CHANNEL,

  PAYMENT_PROVIDER,

  PAYMENT_STATUS

};