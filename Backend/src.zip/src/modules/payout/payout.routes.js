import express from 'express';

import {
  getPayoutHistoryController,
  getCurrentPayoutController,
  getPayoutController,
  startPayoutController,
  markPayoutPaidController,
  cancelPayoutController
} from './payout.controller.js';

import {
  protect
} from '../../middleware/auth.middleware.js';

import {
  requireChamaMember
} from '../../middleware/chama.middleware.js';

import {
  requireTreasurer
} from '../../middleware/treasurer.middleware.js';


const router = express.Router();


// ========================================
// AUTHENTICATION
// ========================================

router.use(
  protect
);


// ========================================
// GET PAYOUT HISTORY
// ========================================

router.get(
  '/:id/payouts',
  requireChamaMember,
  getPayoutHistoryController
);


// ========================================
// GET CURRENT PAYOUT
// ========================================

router.get(
  '/:id/payouts/current',
  requireChamaMember,
  getCurrentPayoutController
);


// ========================================
// GET SINGLE PAYOUT
// ========================================

router.get(
  '/:id/payouts/:payoutId',
  requireChamaMember,
  getPayoutController
);


// ========================================
// START PAYOUT
// TREASURER ONLY
// ========================================

router.post(
  '/:id/payouts/start',
  requireChamaMember,
  requireTreasurer,
  startPayoutController
);


// ========================================
// MARK PAYOUT AS PAID
// TREASURER ONLY
// ========================================

router.patch(
  '/:id/payouts/:payoutId/pay',
  requireChamaMember,
  requireTreasurer,
  markPayoutPaidController
);


// ========================================
// CANCEL PAYOUT
// TREASURER ONLY
// ========================================

router.patch(
  '/:id/payouts/:payoutId/cancel',
  requireChamaMember,
  requireTreasurer,
  cancelPayoutController
);


export default router;