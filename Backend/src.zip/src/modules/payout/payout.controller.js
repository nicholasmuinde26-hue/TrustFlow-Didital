import {
  getPayoutHistory,
  getCurrentPayout,
  getPayoutById,
  startPayout,
  markPayoutPaid,
  cancelPayout
} from './payout.service.js';


// ========================================
// GET PAYOUT HISTORY
// ========================================

export const getPayoutHistoryController = async (
  req,
  res,
  next
) => {

  try {

    const payouts =
      await getPayoutHistory(
        req.params.id
      );


    res.status(200).json({

      success: true,

      data: {
        payouts
      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// GET CURRENT PAYOUT
// ========================================

export const getCurrentPayoutController = async (
  req,
  res,
  next
) => {

  try {

    const payout =
      await getCurrentPayout(
        req.params.id
      );


    res.status(200).json({

      success: true,

      data: {
        payout
      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// GET SINGLE PAYOUT
// ========================================

export const getPayoutController = async (
  req,
  res,
  next
) => {

  try {

    const payout =
      await getPayoutById(

        req.params.id,

        req.params.payoutId

      );


    res.status(200).json({

      success: true,

      data: {
        payout
      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// START PAYOUT
// TREASURER ONLY
// ========================================

export const startPayoutController = async (
  req,
  res,
  next
) => {

  try {

    const payout =
      await startPayout(
        req.params.id
      );


    res.status(201).json({

      success: true,

      message:
        'Payout started successfully',

      data: {
        payout
      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// MARK PAYOUT AS PAID
// TREASURER ONLY
// ========================================

export const markPayoutPaidController = async (
  req,
  res,
  next
) => {

  try {

    const payout =
      await markPayoutPaid(

        req.params.id,

        req.params.payoutId

      );


    res.status(200).json({

      success: true,

      message:
        'Payout marked as paid successfully',

      data: {
        payout
      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// CANCEL PAYOUT
// TREASURER ONLY
// ========================================

export const cancelPayoutController = async (
  req,
  res,
  next
) => {

  try {

    const payout =
      await cancelPayout(

        req.params.id,

        req.params.payoutId

      );


    res.status(200).json({

      success: true,

      message:
        'Payout cancelled successfully',

      data: {
        payout
      }

    });

  } catch (error) {

    next(error);

  }

};