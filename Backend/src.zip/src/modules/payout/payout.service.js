import Payout from '../../models/Payout.js';
import Member from '../../models/User.js';
import Chama from '../../models/Chama.js';


// ========================================
// HELPER
// GET CHAMA MEMBERS IN PAYOUT ORDER
// ========================================

const getOrderedMembers = async (
  chamaId
) => {

  const members =
    await Member.find({
      chama_id: chamaId,
      status: 'active'
    })
      .sort({
        payout_position: 1
      });


  return members;
};


// ========================================
// GET PAYOUT HISTORY
// ========================================

export const getPayoutHistory = async (
  chamaId
) => {

  const chama =
    await Chama.findById(
      chamaId
    );


  if (!chama) {

    throw new Error(
      'Chama not found'
    );

  }


  const payouts =
    await Payout.find({
      chama_id: chamaId
    })

      .populate(
        'member_id',
        'name phone role payout_position'
      )

      .sort({
        createdAt: -1
      });


  return payouts;
};


// ========================================
// GET CURRENT PAYOUT
// ========================================

export const getCurrentPayout = async (
  chamaId
) => {

  const payout =
    await Payout.findOne({

      chama_id:
        chamaId,

      status:
        'pending'

    })

      .populate(
        'member_id',
        'name phone role payout_position'
      );


  return payout;
};


// ========================================
// GET SINGLE PAYOUT
// ========================================

export const getPayoutById = async (
  chamaId,
  payoutId
) => {

  const payout =
    await Payout.findOne({

      _id:
        payoutId,

      chama_id:
        chamaId

    })

      .populate(
        'member_id',
        'name phone role payout_position'
      );


  if (!payout) {

    throw new Error(
      'Payout not found'
    );

  }


  return payout;
};


// ========================================
// START PAYOUT
// ========================================

export const startPayout = async (
  chamaId
) => {

  // ----------------------------------------
  // 1. Check Chama
  // ----------------------------------------

  const chama =
    await Chama.findById(
      chamaId
    );


  if (!chama) {

    throw new Error(
      'Chama not found'
    );

  }


  // ----------------------------------------
  // 2. Check existing pending payout
  // ----------------------------------------

  const existingPayout =
    await Payout.findOne({

      chama_id:
        chamaId,

      status:
        'pending'

    });


  if (existingPayout) {

    throw new Error(
      'There is already an active payout'
    );

  }


  // ----------------------------------------
  // 3. Get active members
  // ----------------------------------------

  const members =
    await getOrderedMembers(
      chamaId
    );


  if (!members.length) {

    throw new Error(
      'No active members found'
    );

  }


  // ----------------------------------------
  // 4. Ensure payout positions
  // ----------------------------------------

  // Treasurer must always be position 1

  const treasurer =
    members.find(
      member =>
        member._id.toString() ===
        chama.treasurer_id.toString()
    );


  if (!treasurer) {

    throw new Error(
      'Treasurer is not an active member'
    );

  }


  // ----------------------------------------
  // 5. Find next payout position
  // ----------------------------------------

  const paidPayouts =
    await Payout.find({
      chama_id:
        chamaId,

      status:
        'paid'
    })
      .sort({
        payout_position: -1
      });


  let nextPosition = 1;


  if (paidPayouts.length > 0) {

    const lastPayout =
      paidPayouts[0];


    const lastPosition =
      lastPayout.payout_position;


    const maxPosition =
      members.length;


    nextPosition =
      lastPosition >= maxPosition
        ? 1
        : lastPosition + 1;

  }


  // ----------------------------------------
  // 6. Find recipient
  // ----------------------------------------

  const recipient =
    members.find(
      member =>
        member.payout_position ===
        nextPosition
    );


  if (!recipient) {

    throw new Error(
      `No active member found at payout position ${nextPosition}`
    );

  }


  // ----------------------------------------
  // 7. Determine amount
  // ----------------------------------------

  const amount =
    Number(
      chama.monthly_savings
    ) *
    members.length;


  if (
    !Number.isFinite(amount) ||
    amount <= 0
  ) {

    throw new Error(
      'Invalid payout amount'
    );

  }


  // ----------------------------------------
  // 8. Create payout
  // ----------------------------------------

  const payout =
    await Payout.create({

      chama_id:
        chamaId,

      member_id:
        recipient._id,

      payout_position:
        nextPosition,

      amount,

      status:
        'pending'

    });


  // ----------------------------------------
  // 9. Return populated payout
  // ----------------------------------------

  const populatedPayout =
    await Payout.findById(
      payout._id
    )

      .populate(
        'member_id',
        'name phone role payout_position'
      );


  return populatedPayout;
};


// ========================================
// MARK PAYOUT AS PAID
// ========================================

export const markPayoutPaid = async (
  chamaId,
  payoutId
) => {

  // ----------------------------------------
  // 1. Find payout
  // ----------------------------------------

  const payout =
    await Payout.findOne({

      _id:
        payoutId,

      chama_id:
        chamaId

    });


  if (!payout) {

    throw new Error(
      'Payout not found'
    );

  }


  // ----------------------------------------
  // 2. Check status
  // ----------------------------------------

  if (
    payout.status !==
    'pending'
  ) {

    throw new Error(
      `Payout cannot be marked as paid because it is already ${payout.status}`
    );

  }


  // ----------------------------------------
  // 3. Confirm member still exists
  // ----------------------------------------

  const member =
    await Member.findOne({

      _id:
        payout.member_id,

      chama_id:
        chamaId,

      status:
        'active'

    });


  if (!member) {

    throw new Error(
      'Payout recipient is no longer an active member'
    );

  }


  // ----------------------------------------
  // 4. Mark paid
  // ----------------------------------------

  payout.status =
    'paid';

  payout.paid_at =
    new Date();


  await payout.save();


  // ----------------------------------------
  // 5. Return updated payout
  // ----------------------------------------

  return await Payout.findById(
    payout._id
  )

    .populate(
      'member_id',
      'name phone role payout_position'
    );
};


// ========================================
// CANCEL PAYOUT
// ========================================

export const cancelPayout = async (
  chamaId,
  payoutId
) => {

  // ----------------------------------------
  // 1. Find payout
  // ----------------------------------------

  const payout =
    await Payout.findOne({

      _id:
        payoutId,

      chama_id:
        chamaId

    });


  if (!payout) {

    throw new Error(
      'Payout not found'
    );

  }


  // ----------------------------------------
  // 2. Check status
  // ----------------------------------------

  if (
    payout.status !==
    'pending'
  ) {

    throw new Error(
      `Payout cannot be cancelled because it is already ${payout.status}`
    );

  }


  // ----------------------------------------
  // 3. Cancel payout
  // ----------------------------------------

  payout.status =
    'cancelled';

  payout.cancelled_at =
    new Date();


  await payout.save();


  // ----------------------------------------
  // 4. Return payout
  // ----------------------------------------

  return await Payout.findById(
    payout._id
  )

    .populate(
      'member_id',
      'name phone role payout_position'
    );
};