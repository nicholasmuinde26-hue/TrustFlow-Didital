import mongoose from 'mongoose';

import FinancialAccount
  from '../../models/FinancialAccount.js';

import AppError
  from '../../utils/AppError.js';


// ========================================
// SUPPORTED OWNER TYPES
// ========================================

const OWNER_TYPES = [

  'Chama',

  'ContributionGroup'

];


// ========================================
// DEFAULT CHAMA CHART OF ACCOUNTS
// ========================================
//
// These are the core accounts automatically
// created when a Chama initializes its
// Finance Engine.
//
// IMPORTANT:
//
// These accounts belong ONLY to the Chama.
//
// Contribution Groups have their own
// independent Chart of Accounts.
//
// ACCOUNTING DESIGN:
//
// 1300 = Loans Receivable
// 1310 = Member Contributions Receivable
//
// This separation is intentional.
//
// Contribution obligations must NEVER use
// the Chama Loans Receivable account.
//
// ========================================

const DEFAULT_CHAMA_ACCOUNTS = [

  // ======================================
  // ASSETS
  // ======================================

  {
    account_code:
      '1000',

    name:
      'Cash',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'cash',

    description:
      'Physical cash held by the Chama.'

  },


  {
    account_code:
      '1100',

    name:
      'Bank',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'bank',

    description:
      'Funds held in the Chama bank account.'

  },


  {
    account_code:
      '1200',

    name:
      'M-Pesa',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'mpesa',

    description:
      'Funds held in the Chama M-Pesa account.'

  },


  // ======================================
  // LOANS RECEIVABLE
  // ======================================
  //
  // IMPORTANT:
  //
  // This account is ONLY for outstanding
  // loan principal owed to the Chama.
  //
  // Contribution obligations must use
  // account 1310 instead.
  //
  // ======================================

  {
    account_code:
      '1300',

    name:
      'Loans Receivable',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'receivable',

    description:
      'Outstanding principal amounts owed to the Chama by borrowers.'

  },


  // ======================================
  // MEMBER CONTRIBUTIONS RECEIVABLE
  // ======================================
  //
  // Dedicated receivable account for
  // contribution obligations.
  //
  // OBLIGATION:
  //
  // DR 1310 Member Contributions Receivable
  // CR 3000 Member Contributions
  //
  // PAYMENT:
  //
  // DR 1000 / 1100 / 1200
  // CR 1310 Member Contributions Receivable
  //
  // ======================================

  {
    account_code:
      '1310',

    name:
      'Member Contributions Receivable',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'receivable',

    description:
      'Contributions owed by Chama members but not yet paid.'

  },


  // ======================================
  // EQUITY
  // ======================================

  {
    account_code:
      '3000',

    name:
      'Member Contributions',

    account_type:
      'equity',

    normal_balance:
      'credit',

    account_category:
      'contribution',

    description:
      'Capital contributed by Chama members.'

  },


  {
    account_code:
      '3100',

    name:
      'Retained Earnings',

    account_type:
      'equity',

    normal_balance:
      'credit',

    account_category:
      'equity',

    description:
      'Accumulated surplus or deficit retained by the Chama.'

  },


  // ======================================
  // INCOME
  // ======================================

  {
    account_code:
      '4000',

    name:
      'Loan Interest Income',

    account_type:
      'income',

    normal_balance:
      'credit',

    account_category:
      'income',

    description:
      'Interest income earned from Chama loans.'

  },


  {
    account_code:
      '4100',

    name:
      'Other Income',

    account_type:
      'income',

    normal_balance:
      'credit',

    account_category:
      'income',

    description:
      'Other income received by the Chama.'

  },


  // ======================================
  // EXPENSES
  // ======================================

  {
    account_code:
      '5000',

    name:
      'Operating Expenses',

    account_type:
      'expense',

    normal_balance:
      'debit',

    account_category:
      'expense',

    description:
      'General operating expenses incurred by the Chama.'

  },


  {
    account_code:
      '5100',

    name:
      'Bank Charges',

    account_type:
      'expense',

    normal_balance:
      'debit',

    account_category:
      'expense',

    description:
      'Bank transaction and service charges.'

  },


  {
    account_code:
      '5200',

    name:
      'M-Pesa Charges',

    account_type:
      'expense',

    normal_balance:
      'debit',

    account_category:
      'expense',

    description:
      'M-Pesa transaction charges and fees.'

  }

];


// ========================================
// DEFAULT CONTRIBUTION GROUP ACCOUNTS
// ========================================
//
// Contribution Groups are completely
// independent from Chamas.
//
// A ContributionGroup can exist:
//
// - Without any Chama
// - Without any Chama membership
// - Without being attached to a Chama
//
// Therefore its financial accounts are
// owned directly by:
//
// owner_type = ContributionGroup
//
// owner_id = ContributionGroup._id
//
// ACCOUNTING DESIGN:
//
// 1300 = Member Contributions Receivable
//
// ========================================

const DEFAULT_CONTRIBUTION_GROUP_ACCOUNTS = [

  // ======================================
  // ASSETS
  // ======================================

  {
    account_code:
      '1000',

    name:
      'Cash',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'cash',

    description:
      'Physical cash held by the contribution group.'

  },


  {
    account_code:
      '1100',

    name:
      'Bank',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'bank',

    description:
      'Funds held in the contribution group bank account.'

  },


  {
    account_code:
      '1200',

    name:
      'M-Pesa',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'mpesa',

    description:
      'Funds held in the contribution group M-Pesa account.'

  },


  // ======================================
  // MEMBER CONTRIBUTIONS RECEIVABLE
  // ======================================
  //
  // Contribution Group obligations use
  // this account for outstanding amounts.
  //
  // ======================================

  {
    account_code:
      '1300',

    name:
      'Member Contributions Receivable',

    account_type:
      'asset',

    normal_balance:
      'debit',

    account_category:
      'receivable',

    description:
      'Contributions owed by members but not yet paid.'

  },


  // ======================================
  // EQUITY
  // ======================================

  {
    account_code:
      '3000',

    name:
      'Member Contributions',

    account_type:
      'equity',

    normal_balance:
      'credit',

    account_category:
      'contribution',

    description:
      'Capital contributed by contribution group members.'

  },


  // ======================================
  // INCOME
  // ======================================

  {
    account_code:
      '4000',

    name:
      'Other Income',

    account_type:
      'income',

    normal_balance:
      'credit',

    account_category:
      'income',

    description:
      'Other income received by the contribution group.'

  },


  // ======================================
  // EXPENSE
  // ======================================

  {
    account_code:
      '5000',

    name:
      'Operating Expenses',

    account_type:
      'expense',

    normal_balance:
      'debit',

    account_category:
      'expense',

    description:
      'General operating expenses incurred by the contribution group.'

  }

];


// ========================================
// OWNER VALIDATION
// ========================================

const validateOwner = ({

  owner_type,

  owner_id

}) => {

  // ======================================
  // VALIDATE OWNER TYPE
  // ======================================

  if (

    !OWNER_TYPES.includes(

      owner_type

    )

  ) {

    throw new AppError(

      'Invalid financial account owner type',

      400

    );

  }


  // ======================================
  // VALIDATE OWNER ID
  // ======================================

  if (

    !owner_id ||

    !mongoose.Types.ObjectId.isValid(

      owner_id

    )

  ) {

    throw new AppError(

      'Invalid financial account owner ID',

      400

    );

  }

};


// ========================================
// GET DEFAULT ACCOUNT DEFINITIONS
// ========================================

const getDefaultAccounts = (

  owner_type

) => {

  if (

    owner_type ===

    'Chama'

  ) {

    return DEFAULT_CHAMA_ACCOUNTS;

  }


  if (

    owner_type ===

    'ContributionGroup'

  ) {

    return DEFAULT_CONTRIBUTION_GROUP_ACCOUNTS;

  }


  throw new AppError(

    'Unsupported financial account owner type',

    400

  );

};


// ========================================
// CREATE FINANCIAL ACCOUNT
// ========================================
//
// Creates one account.
//
// This function does NOT create arbitrary
// accounts for an invalid owner.
//
// ========================================

export const createFinancialAccount =

  async ({

    owner_type,

    owner_id,

    name,

    account_code =

      null,

    account_type,

    normal_balance,

    account_category =

      'other',

    currency =

      'KES',

    description =

      '',

    created_by =

      null,

    is_system_account =

      false

  }) => {

    // ====================================
    // VALIDATE OWNER
    // ====================================

    validateOwner({

      owner_type,

      owner_id

    });


    // ====================================
    // VALIDATE ACCOUNT NAME
    // ====================================

    if (

      !name ||

      !name.trim()

    ) {

      throw new AppError(

        'Financial account name is required',

        400

      );

    }


    // ====================================
    // VALIDATE ACCOUNT TYPE
    // ====================================

    const validAccountTypes = [

      'asset',

      'liability',

      'equity',

      'income',

      'expense'

    ];


    if (

      !validAccountTypes.includes(

        account_type

      )

    ) {

      throw new AppError(

        'Invalid financial account type',

        400

      );

    }


    // ====================================
    // VALIDATE NORMAL BALANCE
    // ====================================

    if (

      ![

        'debit',

        'credit'

      ].includes(

        normal_balance

      )

    ) {

      throw new AppError(

        'Invalid financial account normal balance',

        400

      );

    }


    // ====================================
    // VALIDATE ACCOUNTING RULE
    // ====================================

    const expectedNormalBalance = {

      asset:
        'debit',

      expense:
        'debit',

      liability:
        'credit',

      equity:
        'credit',

      income:
        'credit'

    };


    if (

      expectedNormalBalance[

        account_type

      ] !==

      normal_balance

    ) {

      throw new AppError(

        `${account_type} accounts must have a ${expectedNormalBalance[account_type]}-normal balance`,

        400

      );

    }


    // ====================================
    // VALIDATE CURRENCY
    // ====================================

    if (

      !currency ||

      currency.length !==

      3

    ) {

      throw new AppError(

        'Currency must be a valid 3-letter ISO currency code',

        400

      );

    }


    // ====================================
    // CREATE ACCOUNT
    // ====================================

    try {

      const account =

        await FinancialAccount.create({

          owner_type,

          owner_id,

          name:
            name.trim(),

          account_code:

            account_code

              ? account_code.trim()

              : null,

          account_type,

          normal_balance,

          account_category,

          currency:

            currency.toUpperCase(),

          current_balance:

            mongoose.Types.Decimal128

              .fromString(

                '0'

              ),

          status:
            'active',

          is_system_account,

          description:

            description.trim(),

          created_by

        });


      return account;

    } catch (error) {

      // ==================================
      // HANDLE DUPLICATE ACCOUNT
      // ==================================

      if (

        error?.code ===

        11000

      ) {

        throw new AppError(

          'A financial account with the same name or account code already exists for this owner',

          409

        );

      }


      throw error;

    }

  };


// ========================================
// INITIALIZE CHART OF ACCOUNTS
// ========================================
//
// Creates the default system accounts for:
//
// Chama
//
// OR
//
// ContributionGroup
//
// This operation is IDEMPOTENT.
//
// Running it multiple times will not create
// duplicate accounts.
//
// ========================================

export const initializeChartOfAccounts =

  async ({

    owner_type,

    owner_id,

    currency =

      'KES',

    created_by =

      null

  }) => {

    // ====================================
    // VALIDATE OWNER
    // ====================================

    validateOwner({

      owner_type,

      owner_id

    });


    // ====================================
    // GET DEFAULT ACCOUNTS
    // ====================================

    const defaultAccounts =

      getDefaultAccounts(

        owner_type

      );


    // ====================================
    // CREATE ACCOUNTS
    // ====================================

    const createdAccounts = [];


    for (

      const definition

      of defaultAccounts

    ) {

      // ================================
      // CHECK EXISTING ACCOUNT
      // ================================

      let account =

        await FinancialAccount.findOne({

          owner_type,

          owner_id,

          account_code:

            definition.account_code

        });


      // ================================
      // CREATE IF NOT EXISTS
      // ================================

      if (!account) {

        account =

          await createFinancialAccount({

            owner_type,

            owner_id,

            name:

              definition.name,

            account_code:

              definition.account_code,

            account_type:

              definition.account_type,

            normal_balance:

              definition.normal_balance,

            account_category:

              definition.account_category,

            currency,

            description:

              definition.description,

            created_by,

            is_system_account:

              true

          });

      }


      createdAccounts.push(

        account

      );

    }


    // ====================================
    // RETURN CHART OF ACCOUNTS
    // ====================================

    return createdAccounts;

  };


// ========================================
// GET FINANCIAL ACCOUNT BY ID
// ========================================

export const getFinancialAccountById =

  async ({

    account_id,

    owner_type,

    owner_id,

    session = null

  }) => {

    validateOwner({

      owner_type,

      owner_id

    });


    if (

      !mongoose.Types.ObjectId.isValid(

        account_id

      )

    ) {

      throw new AppError(

        'Invalid financial account ID',

        400

      );

    }


    const account =

      await FinancialAccount.findOne({

        _id:
          account_id,

        owner_type,

        owner_id

      })

        .session(

          session

        );


    if (!account) {

      throw new AppError(

        'Financial account not found',

        404

      );

    }


    return account;

  };


// ========================================
// GET OWNER CHART OF ACCOUNTS
// ========================================

export const getFinancialAccounts =

  async ({

    owner_type,

    owner_id,

    status =

      'active',

    session = null

  }) => {

    validateOwner({

      owner_type,

      owner_id

    });


    const filter = {

      owner_type,

      owner_id

    };


    if (

      status

    ) {

      filter.status =

        status;

    }


    return FinancialAccount.find(

      filter

    )

      .sort({

        account_code:
          1,

        name:
          1

      })

      .session(

        session

      );

  };


// ========================================
// FIND ACCOUNT BY CODE
// ========================================

export const getFinancialAccountByCode =

  async ({

    owner_type,

    owner_id,

    account_code,

    session = null

  }) => {

    validateOwner({

      owner_type,

      owner_id

    });


    if (

      !account_code

    ) {

      throw new AppError(

        'Account code is required',

        400

      );

    }


    const account =

      await FinancialAccount.findOne({

        owner_type,

        owner_id,

        account_code:

          account_code.trim(),

        status:
          'active'

      })

        .session(

          session

        );


    if (!account) {

      throw new AppError(

        'Financial account not found',

        404

      );

    }


    return account;

  };


// ========================================
// GET CONTRIBUTION RECEIVABLE ACCOUNT
// ========================================
//
// This is the central owner-aware account
// resolver for the contribution accounting
// subsystem.
//
// CONTRIBUTION GROUP:
//
// 1300
// Member Contributions Receivable
//
// CHAMA:
//
// 1310
// Member Contributions Receivable
//
// IMPORTANT:
//
// Never allow contribution services to
// directly assume that account 1300 is
// always the contribution receivable.
//
// For Chamas:
//
// 1300 = Loans Receivable
// 1310 = Member Contributions Receivable
//
// For ContributionGroups:
//
// 1300 = Member Contributions Receivable
//
// This function guarantees the correct
// accounting account is selected based on
// the financial owner.
//
// ========================================

export const getContributionReceivableAccount =

  async ({

    owner_type,

    owner_id,

    session = null

  }) => {

    validateOwner({

      owner_type,

      owner_id

    });


    // ====================================
    // OWNER-AWARE ACCOUNT CODE
    // ====================================

    const contributionReceivableCode =

      owner_type ===

      'Chama'

        ? '1310'

        : '1300';


    // ====================================
    // RESOLVE ACCOUNT
    // ====================================

    const account =

      await getFinancialAccountByCode({

        owner_type,

        owner_id,

        account_code:

          contributionReceivableCode,

        session

      });


    // ====================================
    // DEFENSIVE VALIDATION
    // ====================================
    //
    // The account code alone should not be
    // trusted.
    //
    // Verify that the resolved account is
    // actually configured as a receivable
    // asset.
    //
    // ====================================

    if (

      account.account_type !==

      'asset'

    ) {

      throw new AppError(

        `Contribution receivable account ${contributionReceivableCode} must be an asset account`,

        500

      );

    }


    if (

      account.normal_balance !==

      'debit'

    ) {

      throw new AppError(

        `Contribution receivable account ${contributionReceivableCode} must have a debit-normal balance`,

        500

      );

    }


    if (

      account.account_category !==

      'receivable'

    ) {

      throw new AppError(

        `Financial account ${contributionReceivableCode} is not configured as a receivable account`,

        500

      );

    }


    return account;

  };


// ========================================
// GET CONTRIBUTION EQUITY ACCOUNT
// ========================================
//
// Resolves the Member Contributions equity
// account.
//
// Both supported owner types currently use:
//
// 3000
// Member Contributions
//
// This helper keeps contribution accounting
// centralized and prevents hard-coded
// account lookup logic from spreading into
// obligation and payment services.
//
// ========================================

export const getContributionEquityAccount =

  async ({

    owner_type,

    owner_id,

    session = null

  }) => {

    validateOwner({

      owner_type,

      owner_id

    });


    const account =

      await getFinancialAccountByCode({

        owner_type,

        owner_id,

        account_code:
          '3000',

        session

      });


    // ====================================
    // DEFENSIVE VALIDATION
    // ====================================

    if (

      account.account_type !==

      'equity'

    ) {

      throw new AppError(

        'Member Contributions account must be an equity account',

        500

      );

    }


    if (

      account.normal_balance !==

      'credit'

    ) {

      throw new AppError(

        'Member Contributions account must have a credit-normal balance',

        500

      );

    }


    if (

      account.account_category !==

      'contribution'

    ) {

      throw new AppError(

        'Financial account 3000 is not configured as a contribution account',

        500

      );

    }


    return account;

  };


// ========================================
// GET CONTRIBUTION PAYMENT ASSET ACCOUNT
// ========================================
//
// Resolves the asset account receiving
// contribution payment.
//
// Supported account categories:
//
// cash
// bank
// mpesa
//
// This prevents contribution payment
// services from accidentally posting a
// payment into an arbitrary account.
//
// ========================================

export const getContributionPaymentAssetAccount =

  async ({

    owner_type,

    owner_id,

    payment_method,

    session = null

  }) => {

    validateOwner({

      owner_type,

      owner_id

    });


    if (

      !payment_method ||

      typeof payment_method !==

      'string'

    ) {

      throw new AppError(

        'Contribution payment method is required',

        400

      );

    }


    const normalizedPaymentMethod =

      payment_method

        .trim()

        .toLowerCase();


    const paymentAccountCodes = {

      cash:
        '1000',

      bank:
        '1100',

      mpesa:
        '1200'

    };


    const accountCode =

      paymentAccountCodes[

        normalizedPaymentMethod

      ];


    if (!accountCode) {

      throw new AppError(

        `Unsupported contribution payment method: ${payment_method}`,

        400

      );

    }


    const account =

      await getFinancialAccountByCode({

        owner_type,

        owner_id,

        account_code:

          accountCode,

        session

      });


    // ====================================
    // DEFENSIVE VALIDATION
    // ====================================

    if (

      account.account_type !==

      'asset'

    ) {

      throw new AppError(

        `Contribution payment account ${accountCode} must be an asset account`,

        500

      );

    }


    if (

      account.normal_balance !==

      'debit'

    ) {

      throw new AppError(

        `Contribution payment account ${accountCode} must have a debit-normal balance`,

        500

      );

    }


    if (

      ![

        'cash',

        'bank',

        'mpesa'

      ].includes(

        account.account_category

      )

    ) {

      throw new AppError(

        `Financial account ${accountCode} is not configured as a valid contribution payment asset account`,

        500

      );

    }


    return account;

  };


// ========================================
// CLOSE FINANCIAL ACCOUNT
// ========================================
//
// System accounts cannot be deleted.
//
// Instead they can be closed.
//
// ========================================

export const closeFinancialAccount =

  async ({

    account_id,

    owner_type,

    owner_id

  }) => {

    const account =

      await getFinancialAccountById({

        account_id,

        owner_type,

        owner_id

      });


    if (

      account.status ===

      'closed'

    ) {

      throw new AppError(

        'Financial account is already closed',

        400

      );

    }


    // ====================================
    // SYSTEM ACCOUNTS
    // ====================================

    if (

      account.is_system_account

    ) {

      throw new AppError(

        'System financial accounts cannot be closed',

        400

      );

    }


    account.status =

      'closed';


    account.closed_at =

      new Date();


    await account.save();


    return account;

  };