import mongoose from 'mongoose';

import FinancialTransaction
  from '../../models/FinancialTransaction.js';

import FinancialAccount
  from '../../models/FinancialAccount.js';

import LedgerEntry
  from '../../models/LedgerEntry.js';

import {
  toDecimal,
  addMoney,
  subtractMoney,
  isMoneyEqual,
  isMoneyPositive
} from '../../shared/decimal.js';

import AppError
  from '../../utils/AppError.js';


// ========================================
// CALCULATE NEW ACCOUNT BALANCE
// ========================================
//
// Applies accounting normal-balance rules.
//
// DEBIT-NORMAL
//
// Asset
// Expense
//
// Debit  → Increase
// Credit → Decrease
//
//
// CREDIT-NORMAL
//
// Liability
// Equity
// Income
//
// Credit → Increase
// Debit  → Decrease
//
// ========================================

const calculateNewAccountBalance = ({

  currentBalance,

  entryAmount,

  entryType,

  normalBalance

}) => {

  // ======================================
  // VALIDATE NORMAL BALANCE
  // ======================================

  if (
    ![
      'debit',
      'credit'
    ].includes(
      normalBalance
    )
  ) {

    throw new AppError(

      'Invalid account normal balance configuration',

      500

    );

  }


  // ======================================
  // VALIDATE ENTRY TYPE
  // ======================================

  if (
    ![
      'debit',
      'credit'
    ].includes(
      entryType
    )
  ) {

    throw new AppError(

      'Invalid ledger entry type',

      400

    );

  }


  // ======================================
  // CONVERT TO DECIMAL
  // ======================================

  const balance =
    toDecimal(
      currentBalance
    );


  const amount =
    toDecimal(
      entryAmount
    );


  // ======================================
  // VALIDATE AMOUNT
  // ======================================

  if (
    !isMoneyPositive(
      amount
    )
  ) {

    throw new AppError(

      'Ledger entry amount must be greater than zero',

      400

    );

  }


  // ======================================
  // DEBIT-NORMAL ACCOUNT
  // ======================================

  if (
    normalBalance ===
    'debit'
  ) {

    if (
      entryType ===
      'debit'
    ) {

      return addMoney(

        balance,

        amount

      );

    }


    return subtractMoney(

      balance,

      amount

    );

  }


  // ======================================
  // CREDIT-NORMAL ACCOUNT
  // ======================================

  if (
    normalBalance ===
    'credit'
  ) {

    if (
      entryType ===
      'credit'
    ) {

      return addMoney(

        balance,

        amount

      );

    }


    return subtractMoney(

      balance,

      amount

    );

  }


  // ======================================
  // SAFETY FALLBACK
  // ======================================

  throw new AppError(

    'Unable to calculate account balance',

    500

  );

};


// ========================================
// VALIDATE TRANSACTION ENTRIES
// ========================================
//
// Rules:
//
// 1. At least two entries
// 2. At least one debit
// 3. At least one credit
// 4. Every amount > 0
// 5. Debits === Credits
//
// ========================================

const validateLedgerEntries = (
  entries
) => {

  // ======================================
  // MINIMUM ENTRIES
  // ======================================

  if (
    !Array.isArray(entries) ||
    entries.length < 2
  ) {

    throw new AppError(

      'A financial transaction must contain at least two ledger entries',

      400

    );

  }


  // ======================================
  // TOTALS
  // ======================================

  let totalDebits =
    toDecimal('0');


  let totalCredits =
    toDecimal('0');


  let hasDebit =
    false;


  let hasCredit =
    false;


  // ======================================
  // VALIDATE EACH ENTRY
  // ======================================

  for (
    const entry of entries
  ) {

    // ------------------------------------
    // ACCOUNT
    // ------------------------------------

    if (
      !entry.account_id
    ) {

      throw new AppError(

        'Every ledger entry must specify an account',

        400

      );

    }


    // ------------------------------------
    // ENTRY TYPE
    // ------------------------------------

    if (
      !entry.entry_type
    ) {

      throw new AppError(

        'Every ledger entry must specify debit or credit',

        400

      );

    }


    if (
      ![
        'debit',
        'credit'
      ].includes(
        entry.entry_type
      )
    ) {

      throw new AppError(

        'Invalid ledger entry type',

        400

      );

    }


    // ------------------------------------
    // AMOUNT
    // ------------------------------------

    const amount =
      toDecimal(
        entry.amount
      );


    if (
      !isMoneyPositive(
        amount
      )
    ) {

      throw new AppError(

        'Ledger entry amount must be greater than zero',

        400

      );

    }


    // ------------------------------------
    // DEBIT
    // ------------------------------------

    if (
      entry.entry_type ===
      'debit'
    ) {

      totalDebits =
        addMoney(

          totalDebits,

          amount

        );


      hasDebit =
        true;

    }


    // ------------------------------------
    // CREDIT
    // ------------------------------------

    if (
      entry.entry_type ===
      'credit'
    ) {

      totalCredits =
        addMoney(

          totalCredits,

          amount

        );


      hasCredit =
        true;

    }

  }


  // ======================================
  // REQUIRE DEBIT
  // ======================================

  if (
    !hasDebit
  ) {

    throw new AppError(

      'Transaction must contain at least one debit entry',

      400

    );

  }


  // ======================================
  // REQUIRE CREDIT
  // ======================================

  if (
    !hasCredit
  ) {

    throw new AppError(

      'Transaction must contain at least one credit entry',

      400

    );

  }


  // ======================================
  // DOUBLE-ENTRY VALIDATION
  // ======================================

  if (
    !isMoneyEqual(

      totalDebits,

      totalCredits

    )
  ) {

    throw new AppError(

      'Financial transaction is not balanced',

      400

    );

  }


  return {

    totalDebits,

    totalCredits

  };

};


// ========================================
// VALIDATE FINANCIAL ACCOUNTS
// ========================================

const validateAccounts = async (

  entries,

  ownerType,

  ownerId,

  session

) => {

  // ======================================
  // EXTRACT UNIQUE ACCOUNT IDS
  // ======================================

  const accountIds = [

    ...new Set(

      entries.map(

        entry =>
          String(
            entry.account_id
          )

      )

    )

  ];


  // ======================================
  // VALIDATE OBJECT IDS
  // ======================================

  for (
    const accountId of accountIds
  ) {

    if (
      !mongoose.Types.ObjectId.isValid(
        accountId
      )
    ) {

      throw new AppError(

        'Invalid financial account ID',

        400

      );

    }

  }


  // ======================================
  // LOAD ACCOUNTS
  // ======================================

  const accounts =
    await FinancialAccount.find({

      _id: {

        $in:
          accountIds

      },

      owner_type:
        ownerType,

      owner_id:
        ownerId,

      status:
        'active'

    })
      .session(
        session
      );


  // ======================================
  // ENSURE ALL ACCOUNTS EXIST
  // ======================================

  if (
    accounts.length !==
    accountIds.length
  ) {

    throw new AppError(

      'One or more financial accounts are invalid, inactive, or do not belong to this owner',

      400

    );

  }


  return accounts;

};


// ========================================
// AGGREGATE ACCOUNT MOVEMENTS
// ========================================
//
// Multiple ledger entries can reference
// the same account.
//
// Example:
//
// Cash:
//   Debit 100
//   Debit 50
//   Credit 20
//
// Result:
//
//   Debits  = 150
//   Credits = 20
//
// Net movement:
//
//   Debit 130
//
// Account is updated once.
//
// ========================================

const aggregateAccountMovements = (
  entries
) => {

  const accountMovements =
    new Map();


  for (
    const entry of entries
  ) {

    const accountId =
      String(
        entry.account_id
      );


    let movement =
      accountMovements.get(
        accountId
      );


    // ======================================
    // INITIALIZE MOVEMENT
    // ======================================

    if (!movement) {

      movement = {

        account_id:
          entry.account_id,

        totalDebits:
          toDecimal('0'),

        totalCredits:
          toDecimal('0')

      };

    }


    // ======================================
    // CONVERT AMOUNT
    // ======================================

    const amount =
      toDecimal(
        entry.amount
      );


    // ======================================
    // AGGREGATE DEBIT
    // ======================================

    if (
      entry.entry_type ===
      'debit'
    ) {

      movement.totalDebits =
        addMoney(

          movement.totalDebits,

          amount

        );

    }


    // ======================================
    // AGGREGATE CREDIT
    // ======================================

    if (
      entry.entry_type ===
      'credit'
    ) {

      movement.totalCredits =
        addMoney(

          movement.totalCredits,

          amount

        );

    }


    // ======================================
    // SAVE MOVEMENT
    // ======================================

    accountMovements.set(

      accountId,

      movement

    );

  }


  return accountMovements;

};


// ========================================
// CALCULATE NET ACCOUNT MOVEMENT
// ========================================

const calculateNetAccountMovement = ({

  totalDebits,

  totalCredits

}) => {

  // ======================================
  // DEBIT > CREDIT
  // ======================================

  if (
    totalDebits.greaterThan(
      totalCredits
    )
  ) {

    return {

      direction:
        'debit',

      amount:

        subtractMoney(

          totalDebits,

          totalCredits

        )

    };

  }


  // ======================================
  // CREDIT > DEBIT
  // ======================================

  if (
    totalCredits.greaterThan(
      totalDebits
    )
  ) {

    return {

      direction:
        'credit',

      amount:

        subtractMoney(

          totalCredits,

          totalDebits

        )

    };

  }


  // ======================================
  // BALANCED ACCOUNT MOVEMENT
  // ======================================

  return {

    direction:
      null,

    amount:
      toDecimal('0')

  };

};


// ========================================
// UPDATE ACCOUNT BALANCES
// ========================================
//
// Important:
//
// Each account is updated exactly once.
//
// The update uses optimistic concurrency
// protection.
//
// The original balance is included in
// the MongoDB filter.
//
// If another transaction changes the
// balance first, matchedCount becomes 0.
//
// The parent MongoDB transaction is then
// aborted.
//
// ========================================

const updateAccountBalances = async ({

  entries,

  accountMap,

  session

}) => {

  // ======================================
  // AGGREGATE ACCOUNT MOVEMENTS
  // ======================================

  const accountMovements =
    aggregateAccountMovements(
      entries
    );


  // ======================================
  // PROCESS EACH ACCOUNT ONCE
  // ======================================

  for (
    const [
      accountId,
      movement
    ]
    of accountMovements
  ) {

    // ====================================
    // FIND ACCOUNT
    // ====================================

    const account =
      accountMap.get(
        accountId
      );


    if (!account) {

      throw new AppError(

        'Financial account not found during balance update',

        400

      );

    }


    // ====================================
    // VALIDATE NORMAL BALANCE
    // ====================================

    if (
      ![
        'debit',
        'credit'
      ].includes(
        account.normal_balance
      )
    ) {

      throw new AppError(

        `Invalid normal balance configuration for financial account ${account._id}`,

        500

      );

    }


    // ====================================
    // CALCULATE NET MOVEMENT
    // ====================================

    const netMovement =
      calculateNetAccountMovement({

        totalDebits:
          movement.totalDebits,

        totalCredits:
          movement.totalCredits

      });


    // ====================================
    // NOTHING TO UPDATE
    // ====================================

    if (
      netMovement.amount.isZero()
    ) {

      continue;

    }


    // ====================================
    // ORIGINAL BALANCE
    // ====================================

    const originalBalance =
      toDecimal(

        account.current_balance

      );


    // ====================================
    // CALCULATE NEW BALANCE
    // ====================================

    const newBalance =
      calculateNewAccountBalance({

        currentBalance:
          originalBalance,

        entryAmount:
          netMovement.amount,

        entryType:
          netMovement.direction,

        normalBalance:
          account.normal_balance

      });


    // ====================================
    // ATOMIC BALANCE UPDATE
    // ====================================

    const updateResult =
      await FinancialAccount.updateOne(

        {

          _id:
            account._id,

          owner_type:
            account.owner_type,

          owner_id:
            account.owner_id,

          status:
            'active',

          current_balance:

            mongoose.Types.Decimal128
              .fromString(

                originalBalance.toFixed()

              )

        },

        {

          $set: {

            current_balance:

              mongoose.Types.Decimal128
                .fromString(

                  newBalance.toFixed()

                )

          }

        },

        {

          session

        }

      );


    // ====================================
    // CONCURRENCY FAILURE
    // ====================================

    if (
      updateResult.matchedCount !==
      1
    ) {

      throw new AppError(

        `Financial account ${account._id} was modified by another transaction. The financial transaction has been rolled back. Please retry.`,

        409

      );

    }


    // ====================================
    // MODIFICATION FAILURE
    // ====================================

    if (
      updateResult.modifiedCount !==
      1
    ) {

      throw new AppError(

        `Financial account ${account._id} balance could not be updated`,

        500

      );

    }

  }

};

// ========================================
// FIND EXISTING TRANSACTION BY REFERENCE
// ========================================

const findExistingTransactionByReference = async ({
  ownerType,
  ownerId,
  externalReference,
  session
}) => {

  if (
    !externalReference
  ) {

    return null;

  }


  const existingTransaction =
    await FinancialTransaction
      .findOne({

        owner_type:
          ownerType,

        owner_id:
          ownerId,

        external_reference:
          externalReference

      })
      .session(
        session
      );


  return existingTransaction;

};

// ========================================
// VALIDATE IDEMPOTENT TRANSACTION MATCH
// ========================================

const validateExistingTransactionMatch = ({
  transaction,
  transactionType,
  amount,
  currency,
  sourceType,
  sourceId
}) => {

  if (
    transaction.transaction_type !==
    transactionType
  ) {

    throw new AppError(

      'A transaction with this external reference already exists with a different transaction type',

      409

    );

  }


  if (
    transaction.currency !==
    currency
  ) {

    throw new AppError(

      'A transaction with this external reference already exists with a different currency',

      409

    );

  }


  if (
    !isMoneyEqual(

      toDecimal(
        transaction.amount
      ),

      toDecimal(
        amount
      )

    )
  ) {

    throw new AppError(

      'A transaction with this external reference already exists with a different amount',

      409

    );

  }


  if (
    transaction.source_type !==
    sourceType
  ) {

    throw new AppError(

      'A transaction with this external reference already exists with a different source type',

      409

    );

  }


  if (
    String(
      transaction.source_id
    ) !==
    String(
      sourceId
    )
  ) {

    throw new AppError(

      'A transaction with this external reference already exists with a different source',

      409

    );

  }


  return true;

};


// ========================================
// POST FINANCIAL TRANSACTION
// ========================================
//
// This is the core double-entry posting
// engine.
//
// It supports two modes:
//
// 1. STANDALONE MODE
//
// No session supplied.
//
// The service:
// - creates session
// - starts transaction
// - commits transaction
// - aborts on error
// - ends session
//
//
//
// 2. NESTED MODE
//
// Existing session supplied.
//
// The service:
// - reuses existing session
// - does NOT start transaction
// - does NOT commit transaction
// - does NOT abort transaction
// - does NOT end session
//
// The parent service owns the transaction.
//
// ========================================

export const postFinancialTransaction = async ({

  owner_type,

  owner_id,

  transaction_type,

  amount,

  currency =
    'KES',

  source_type,

  source_id,

  entries,

  description =
    '',

  external_reference =
    null,

  reference =
    null,

  created_by,

  posted_by =
    null,

  session:
    existingSession =
      null

}) => {

  // ======================================
  // DETERMINE SESSION OWNERSHIP
  // ======================================

  const ownsSession =
    !existingSession;


  // ======================================
  // CREATE OR REUSE SESSION
  // ======================================

  const session =
    existingSession ||
    await mongoose.startSession();


  try {

    // ====================================
    // START TRANSACTION IF WE OWN SESSION
    // ====================================

    if (
      ownsSession
    ) {

      session.startTransaction();

    }


    // ====================================
    // VALIDATE TRANSACTION OWNER
    // ====================================

    if (
      !owner_type ||
      !owner_id
    ) {

      throw new AppError(

        'Transaction owner is required',

        400

      );

    }


    // ====================================
    // VALIDATE TRANSACTION TYPE
    // ====================================

    if (
      !transaction_type
    ) {

      throw new AppError(

        'Transaction type is required',

        400

      );

    }


    // ====================================
    // VALIDATE SOURCE
    // ====================================

    if (
      !source_type ||
      !source_id
    ) {

      throw new AppError(

        'Transaction source is required',

        400

      );

    }


    // ====================================
    // VALIDATE CREATOR
    // ====================================

    if (
      !created_by
    ) {

      throw new AppError(

        'Transaction creator is required',

        400

      );

    }


    // ====================================
    // VALIDATE ENTRIES
    // ====================================

    const {

      totalDebits,

      totalCredits

    } =
      validateLedgerEntries(
        entries
      );


    // ====================================
    // VALIDATE TRANSACTION AMOUNT
    // ====================================

    const transactionAmount =
      toDecimal(
        amount
      );


    if (
      !isMoneyPositive(
        transactionAmount
      )
    ) {

      throw new AppError(

        'Transaction amount must be greater than zero',

        400

      );

    }


    // ====================================
    // TRANSACTION AMOUNT = TOTAL DEBITS
    // ====================================

    if (
      !isMoneyEqual(

        transactionAmount,

        totalDebits

      )
    ) {

      throw new AppError(

        'Transaction amount does not match total debit amount',

        400

      );

    }


    // ====================================
    // TRANSACTION AMOUNT = TOTAL CREDITS
    // ====================================

    if (
      !isMoneyEqual(

        transactionAmount,

        totalCredits

      )
    ) {

      throw new AppError(

        'Transaction amount does not match total credit amount',

        400

      );

    }


    // ====================================
    // VALIDATE ACCOUNTS
    // ====================================

    const accounts =
      await validateAccounts(

        entries,

        owner_type,

        owner_id,

        session

      );


    // ====================================
    // CREATE ACCOUNT MAP
    // ====================================

    const accountMap =
      new Map(

        accounts.map(

          account => [

            String(
              account._id
            ),

            account

          ]

        )

      );


    // ====================================
    // VALIDATE CURRENCY
    // ====================================

    for (
      const entry of entries
    ) {

      const account =
        accountMap.get(

          String(
            entry.account_id
          )

        );


      if (
        !account
      ) {

        throw new AppError(

          'Financial account not found',

          400

        );

      }


      if (
        account.currency !==
        currency
      ) {

        throw new AppError(

          'Transaction currency does not match account currency',

          400

        );

      }

    }


    // ====================================
    // POSTING TIMESTAMP
    // ====================================

    const postedAt =
      new Date();



      // ========================================
// IDEMPOTENCY CHECK
// ========================================

const existingTransaction =
  await findExistingTransactionByReference({

    ownerType:
      owner_type,

    ownerId:
      owner_id,

    externalReference:
      external_reference,

    session

  });


if (
  existingTransaction
) {

  validateExistingTransactionMatch({

    transaction:
      existingTransaction,

    transactionType:
      transaction_type,

    amount:
      transactionAmount,

    currency,

    sourceType:
      source_type,

    sourceId:
      source_id

  });


  // ======================================
  // RETURN EXISTING TRANSACTION
  // ======================================

  if (
    ownsSession
  ) {

    await session.commitTransaction();

  }


  return existingTransaction;

}
    // ====================================
    // CREATE FINANCIAL TRANSACTION
    // ====================================

    const transaction =
      new FinancialTransaction({

        owner_type,

        owner_id,

        transaction_type,

        amount:

          mongoose.Types.Decimal128
            .fromString(

              transactionAmount.toFixed()

            ),

        currency,

        source_type,

        source_id,

        external_reference,

        reference,

        status:
          'posted',

        description,

        created_by,

        posted_by:

          posted_by ||
          created_by,

        posted_at:
          postedAt

      });


    await transaction.save({

      session

    });


    // ====================================
    // CREATE LEDGER ENTRIES
    // ====================================

    const ledgerEntries =

      entries.map(

        entry => {

          const entryAmount =
            toDecimal(
              entry.amount
            );


          return {

            transaction_id:
              transaction._id,

            owner_type,

            owner_id,

            account_id:
              entry.account_id,

            entry_type:
              entry.entry_type,

            amount:

              mongoose.Types.Decimal128
                .fromString(

                  entryAmount.toFixed()

                ),

            currency,

            description:

              entry.description ||
              description,

            status:
              'posted',

            posted_at:
              postedAt,

            posted_by:

              posted_by ||
              created_by

          };

        }

      );


    await LedgerEntry.insertMany(

      ledgerEntries,

      {

        session

      }

    );


    // ====================================
    // UPDATE ACCOUNT BALANCES
    // ====================================
    //
    // Account movements are aggregated
    // before updating balances.
    //
    // Each account is updated once.
    //
    // Optimistic concurrency protection
    // prevents stale cached balances from
    // overwriting newer balances.
    //
    // ====================================

    await updateAccountBalances({

      entries,

      accountMap,

      session

    });


    // ====================================
    // COMMIT ONLY OUR OWN TRANSACTION
    // ====================================

    if (
      ownsSession
    ) {

      await session.commitTransaction();

    }


    // ====================================
    // RETURN POSTED TRANSACTION
    // ====================================

    return transaction;


  } catch (error) {

    // ====================================
    // ABORT ONLY OUR OWN TRANSACTION
    // ====================================

    if (
      ownsSession &&
      session.inTransaction()
    ) {

      await session.abortTransaction();

    }


    throw error;


  } finally {

    // ====================================
    // END ONLY OUR OWN SESSION
    // ====================================

    if (
      ownsSession
    ) {

      await session.endSession();

    }

  }

};