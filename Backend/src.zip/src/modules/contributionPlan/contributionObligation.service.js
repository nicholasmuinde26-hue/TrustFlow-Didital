import mongoose from 'mongoose';

import ContributionObligation
  from '../../models/ContributionObligation.js';

import ContributionPlan
  from '../../models/ContributionPlan.js';

import ContributionGroupMember
  from '../../models/ContributionGroupMember.js';

import ChamaMembership
  from '../../models/ChamaMembership.js';

import AppError
  from '../../utils/AppError.js';

import {
  getFinancialAccountByCode
} from '../finance/financeAccount.service.js';

import {
  postFinancialTransaction
} from '../finance/financeTransaction.service.js';

import {
  toDecimal,
  subtractMoney,
  isMoneyPositive,
  isMoneyEqual
} from '../../shared/decimal.js';


// ========================================
// SUPPORTED OWNER TYPES
// ========================================

const OWNER_TYPES = [

  'Chama',

  'ContributionGroup'

];


// ========================================
// SUPPORTED PARTICIPANT TYPES
// ========================================

const PARTICIPANT_TYPES = [

  'ChamaMembership',

  'ContributionGroupMember'

];


// ========================================
// SUPPORTED OBLIGATION STATUSES
// ========================================

const OBLIGATION_STATUSES = [

  'pending',

  'partially_paid',

  'paid',

  'overdue',

  'waived',

  'cancelled'

];


// ========================================
// TERMINAL OBLIGATION STATUSES
// ========================================
//
// These statuses represent obligations that
// should no longer be modified through normal
// payment or lifecycle workflows.
//

const TERMINAL_OBLIGATION_STATUSES = [

  'paid',

  'waived',

  'cancelled'

];


// ========================================
// FINANCIAL ACCOUNT CODES
// ========================================
//
// Contribution obligation recognition:
//
// DR 1300 Member Contributions Receivable
// CR 3000 Member Contributions
//
// Payment settlement:
//
// DR 1000 / 1100 / 1200
// CR 1300 Member Contributions Receivable
//
// These accounts belong to the
// ContributionGroup or Chama owner.
//
// ========================================

const CONTRIBUTION_RECEIVABLE_ACCOUNT_CODE =
  '1300';


const MEMBER_CONTRIBUTIONS_ACCOUNT_CODE =
  '3000';


// ========================================
// VALIDATE OBJECT ID
// ========================================

const validateObjectId = (

  value,

  fieldName

) => {

  if (

    !value ||

    !mongoose.Types.ObjectId.isValid(

      value

    )

  ) {

    throw new AppError(

      `Invalid ${fieldName}`,

      400

    );

  }

};


// ========================================
// VALIDATE OWNER TYPE
// ========================================

const validateOwnerType = (

  owner_type

) => {

  if (

    !OWNER_TYPES.includes(

      owner_type

    )

  ) {

    throw new AppError(

      'Invalid contribution obligation owner type',

      400

    );

  }

};


// ========================================
// VALIDATE PARTICIPANT TYPE
// ========================================

const validateParticipantType = (

  participant_type

) => {

  if (

    !PARTICIPANT_TYPES.includes(

      participant_type

    )

  ) {

    throw new AppError(

      'Invalid contribution obligation participant type',

      400

    );

  }

};


// ========================================
// VALIDATE OBLIGATION STATUS
// ========================================

const validateObligationStatus = (

  status

) => {

  if (

    status &&

    !OBLIGATION_STATUSES.includes(

      status

    )

  ) {

    throw new AppError(

      `Invalid contribution obligation status: ${status}`,

      400

    );

  }

};


// ========================================
// VALIDATE OWNER / PARTICIPANT COMPATIBILITY
// ========================================
//
// The architecture intentionally maps:
//
// Chama
//   -> ChamaMembership
//
// ContributionGroup
//   -> ContributionGroupMember
//
// ========================================

const validateOwnerParticipantCompatibility = ({

  owner_type,

  participant_type

}) => {

  validateOwnerType(

    owner_type

  );


  validateParticipantType(

    participant_type

  );


  // ======================================
  // CHAMA
  // ======================================

  if (

    owner_type ===

    'Chama' &&

    participant_type !==

    'ChamaMembership'

  ) {

    throw new AppError(

      'Chama obligations must use ChamaMembership participants',

      400

    );

  }


  // ======================================
  // CONTRIBUTION GROUP
  // ======================================

  if (

    owner_type ===

    'ContributionGroup' &&

    participant_type !==

    'ContributionGroupMember'

  ) {

    throw new AppError(

      'ContributionGroup obligations must use ContributionGroupMember participants',

      400

    );

  }

};


// ========================================
// VALIDATE DATE VALUE
// ========================================

const validateDateValue = (

  value,

  fieldName

) => {

  if (!value) {

    return null;

  }


  const date =

    new Date(

      value

    );


  if (

    Number.isNaN(

      date.getTime()

    )

  ) {

    throw new AppError(

      `Invalid ${fieldName}`,

      400

    );

  }


  return date;

};


// ========================================
// VALIDATE PARTICIPANT MEMBERSHIP
// ========================================

const validateParticipant = async ({

  owner_type,

  owner_id,

  participant_type,

  participant_id,

  session

}) => {

  validateObjectId(

    owner_id,

    'owner ID'

  );


  validateObjectId(

    participant_id,

    'participant ID'

  );


  validateOwnerParticipantCompatibility({

    owner_type,

    participant_type

  });


  // ======================================
  // CHAMA MEMBERSHIP
  // ======================================

  if (

    participant_type ===

    'ChamaMembership'

  ) {

    const membership =

      await ChamaMembership.findOne({

        _id:

          participant_id,

        chama_id:

          owner_id

      })

        .session(

          session

        );


    if (!membership) {

      throw new AppError(

        'Chama membership does not exist or does not belong to the specified Chama',

        400

      );

    }


    if (

      membership.status &&

      membership.status !==

      'active'

    ) {

      throw new AppError(

        'The Chama membership is not active',

        400

      );

    }


    return membership;

  }


  // ======================================
  // CONTRIBUTION GROUP MEMBER
  // ======================================

  if (

    participant_type ===

    'ContributionGroupMember'

  ) {

    const membership =

      await ContributionGroupMember.findOne({

        _id:

          participant_id,

        contribution_group_id:

          owner_id,

        status:

          'active'

      })

        .session(

          session

        );


    if (!membership) {

      throw new AppError(

        'Contribution group membership does not exist, is inactive, or does not belong to the specified ContributionGroup',

        400

      );

    }


    return membership;

  }


  // ======================================
  // SAFETY FALLBACK
  // ======================================

  throw new AppError(

    'Unable to validate contribution participant',

    500

  );

};


// ========================================
// VALIDATE CONTRIBUTION PLAN
// ========================================

const validateContributionPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  session

}) => {

  validateObjectId(

    plan_id,

    'contribution plan ID'

  );


  validateObjectId(

    owner_id,

    'owner ID'

  );


  validateOwnerType(

    owner_type

  );


  const plan =

    await ContributionPlan.findOne({

      _id:

        plan_id,

      owner_type,

      owner_id

    })

      .session(

        session

      );


  if (!plan) {

    throw new AppError(

      'Contribution plan does not exist or does not belong to the specified owner',

      404

    );

  }


  if (

    plan.status !==

    'active'

  ) {

    throw new AppError(

      `Contribution plan is not active. Current status: ${plan.status}`,

      400

    );

  }


  return plan;

};


// ========================================
// VALIDATE EXPECTED AMOUNT
// ========================================

const validateExpectedAmount = (

  expectedAmount

) => {

  let amount;


  try {

    amount =

      toDecimal(

        expectedAmount

      );

  } catch (error) {

    throw new AppError(

      'Invalid contribution obligation expected amount',

      400

    );

  }


  if (

    !isMoneyPositive(

      amount

    )

  ) {

    throw new AppError(

      'Contribution obligation expected amount must be greater than zero',

      400

    );

  }


  return amount;

};


// ========================================
// VALIDATE CURRENCY
// ========================================

const validateCurrency = (

  currency

) => {

  if (

    !currency ||

    typeof currency !==

    'string' ||

    currency.trim().length !==

    3

  ) {

    throw new AppError(

      'Invalid contribution obligation currency',

      400

    );

  }


  return currency

    .trim()

    .toUpperCase();

};


// ========================================
// VALIDATE PERIOD
// ========================================

const validatePeriod = ({

  period_start,

  period_end

}) => {

  const periodStart =

    validateDateValue(

      period_start,

      'contribution obligation period start'

    );


  const periodEnd =

    validateDateValue(

      period_end,

      'contribution obligation period end'

    );


  if (

    periodStart &&

    periodEnd &&

    periodStart >

    periodEnd

  ) {

    throw new AppError(

      'Contribution obligation period start cannot be after period end',

      400

    );

  }


  return {

    periodStart,

    periodEnd

  };

};


// ========================================
// VALIDATE DUE DATE
// ========================================

const validateDueDate = ({

  due_date,

  period_end

}) => {

  if (!due_date) {

    throw new AppError(

      'Contribution obligation due date is required',

      400

    );

  }


  const dueDate =

    validateDateValue(

      due_date,

      'contribution obligation due date'

    );


  const periodEnd =

    validateDateValue(

      period_end,

      'contribution obligation period end'

    );


  if (

    periodEnd &&

    dueDate <

    periodEnd

  ) {

    throw new AppError(

      'Contribution obligation due date cannot be before the contribution period ends',

      400

    );

  }


  return dueDate;

};


// ========================================
// FIND EXISTING OBLIGATION
// ========================================

const findExistingObligation = async ({

  plan_id,

  participant_type,

  participant_id,

  period_start,

  period_end,

  session

}) => {

  const query = {

    plan_id,

    participant_type,

    participant_id,

    period_start:

      period_start || null,

    period_end:

      period_end || null

  };


  return ContributionObligation.findOne(

    query

  )

    .session(

      session

    );

};


// ========================================
// DETERMINE OBLIGATION AMOUNT
// ========================================

const determineExpectedAmount = ({

  plan,

  expected_amount

}) => {

  // ======================================
  // EXPLICIT AMOUNT
  // ======================================

  if (

    expected_amount !==

    undefined &&

    expected_amount !==

    null

  ) {

    const amount =

      validateExpectedAmount(

        expected_amount

      );


    // ====================================
    // MINIMUM AMOUNT
    // ====================================

    if (

      plan.minimum_amount &&

      amount.lessThan(

        toDecimal(

          plan.minimum_amount

        )

      )

    ) {

      throw new AppError(

        'Expected obligation amount cannot be below the contribution plan minimum amount',

        400

      );

    }


    // ====================================
    // MAXIMUM AMOUNT
    // ====================================

    if (

      plan.maximum_amount &&

      amount.greaterThan(

        toDecimal(

          plan.maximum_amount

        )

      )

    ) {

      throw new AppError(

        'Expected obligation amount cannot exceed the contribution plan maximum amount',

        400

      );

    }


    return amount;

  }


  // ======================================
  // FIXED CONTRIBUTION
  // ======================================

  if (

    plan.contribution_type ===

    'fixed'

  ) {

    if (!plan.amount) {

      throw new AppError(

        'Fixed contribution plan does not have a configured amount',

        400

      );

    }


    return validateExpectedAmount(

      plan.amount

    );

  }


  // ======================================
  // TARGET CONTRIBUTION
  // ======================================

  if (

    plan.contribution_type ===

    'target'

  ) {

    if (

      plan.minimum_amount

    ) {

      return validateExpectedAmount(

        plan.minimum_amount

      );

    }


    if (

      plan.target_amount

    ) {

      return validateExpectedAmount(

        plan.target_amount

      );

    }

  }


  // ======================================
  // FREE-WILL CONTRIBUTION
  // ======================================

  if (

    plan.contribution_type ===

    'free_will'

  ) {

    throw new AppError(

      'Free-will contribution plans require an explicit expected amount when creating an obligation',

      400

    );

  }


  // ======================================
  // MERRY-GO-ROUND
  // ======================================

  if (

    plan.contribution_type ===

    'merry_go_round'

  ) {

    if (

      plan.amount

    ) {

      return validateExpectedAmount(

        plan.amount

      );

    }

  }


  // ======================================
  // FALLBACK
  // ======================================

  throw new AppError(

    'Unable to determine contribution obligation amount from the plan',

    400

  );

};


// ========================================
// GET CONTRIBUTION ACCOUNTING ACCOUNTS
// ========================================
//
// Resolves:
//
// DR 1300 Member Contributions Receivable
// CR 3000 Member Contributions
//
// ========================================

const getContributionObligationAccounts = async ({

  owner_type,

  owner_id,

  session

}) => {

  validateObjectId(

    owner_id,

    'owner ID'

  );


  validateOwnerType(

    owner_type

  );


  // ======================================
  // RECEIVABLE ACCOUNT
  // ======================================

  const receivableAccount =

    await getFinancialAccountByCode({

      owner_type,

      owner_id,

      account_code:

        CONTRIBUTION_RECEIVABLE_ACCOUNT_CODE,

      session

    });


  if (!receivableAccount) {

    throw new AppError(

      `Contribution receivable account ${CONTRIBUTION_RECEIVABLE_ACCOUNT_CODE} was not found for the specified owner`,

      500

    );

  }


  // ======================================
  // CONTRIBUTIONS ACCOUNT
  // ======================================

  const contributionAccount =

    await getFinancialAccountByCode({

      owner_type,

      owner_id,

      account_code:

        MEMBER_CONTRIBUTIONS_ACCOUNT_CODE,

      session

    });


  if (!contributionAccount) {

    throw new AppError(

      `Member contributions account ${MEMBER_CONTRIBUTIONS_ACCOUNT_CODE} was not found for the specified owner`,

      500

    );

  }


  // ======================================
  // VALIDATE ACCOUNT CURRENCIES
  // ======================================

  if (

    receivableAccount.currency !==

    contributionAccount.currency

  ) {

    throw new AppError(

      'Contribution receivable and member contribution accounts must use the same currency',

      500

    );

  }


  return {

    receivableAccount,

    contributionAccount

  };

};


// ========================================
// CREATE CONTRIBUTION OBLIGATION
// ========================================
//
// Creates a new financial obligation.
//
// Accounting:
//
// DR 1300 Member Contributions Receivable
// CR 3000 Member Contributions
//
// The obligation and accounting transaction
// are created inside the same MongoDB
// transaction.
//
// ========================================

export const createContributionObligation =

  async ({

    plan_id,

    owner_type,

    owner_id,

    participant_type,

    participant_id,

    expected_amount,

    currency,

    due_date,

    period_start = null,

    period_end = null,

    notes = '',

    created_by,

    posted_by = null,

    session:

      existingSession = null

  }) => {

    // ======================================
    // SESSION OWNERSHIP
    // ======================================

    const ownsSession =

      !existingSession;


    const session =

      existingSession ||

      await mongoose.startSession();


    try {

      // ====================================
      // START TRANSACTION
      // ====================================

      if (

        ownsSession

      ) {

        session.startTransaction();

      }


      // ====================================
      // VALIDATE CREATOR
      // ====================================

      validateObjectId(

        created_by,

        'created by user ID'

      );


      // ====================================
      // VALIDATE POSTER
      // ====================================

      if (

        posted_by

      ) {

        validateObjectId(

          posted_by,

          'posted by user ID'

        );

      }


      // ====================================
      // VALIDATE PLAN
      // ====================================

      const plan =

        await validateContributionPlan({

          plan_id,

          owner_type,

          owner_id,

          session

        });


      // ====================================
      // VALIDATE PARTICIPANT
      // ====================================

      await validateParticipant({

        owner_type,

        owner_id,

        participant_type,

        participant_id,

        session

      });


      // ====================================
      // DETERMINE AMOUNT
      // ====================================

      const amount =

        determineExpectedAmount({

          plan,

          expected_amount

        });


      // ====================================
      // VALIDATE CURRENCY
      // ====================================

      const obligationCurrency =

        validateCurrency(

          currency ||

          plan.currency ||

          'KES'

        );


      // ====================================
      // VALIDATE PLAN CURRENCY
      // ====================================

      if (

        plan.currency &&

        validateCurrency(

          plan.currency

        ) !==

        obligationCurrency

      ) {

        throw new AppError(

          'Contribution obligation currency must match the contribution plan currency',

          400

        );

      }


      // ====================================
      // VALIDATE PERIOD
      // ====================================

      const {

        periodStart,

        periodEnd

      } =

        validatePeriod({

          period_start,

          period_end

        });


      // ====================================
      // VALIDATE DUE DATE
      // ====================================

      const dueDate =

        validateDueDate({

          due_date,

          period_end

        });


      // ====================================
      // DUPLICATE CHECK
      // ====================================

      const existingObligation =

        await findExistingObligation({

          plan_id,

          participant_type,

          participant_id,

          period_start:

            periodStart,

          period_end:

            periodEnd,

          session

        });


      if (

        existingObligation

      ) {

        throw new AppError(

          'A contribution obligation already exists for this participant and contribution period',

          409

        );

      }


      // ====================================
      // VALIDATE ACCOUNTING ACCOUNTS
      // ====================================

      const {

        receivableAccount,

        contributionAccount

      } =

        await getContributionObligationAccounts({

          owner_type,

          owner_id,

          session

        });


      // ====================================
      // VALIDATE ACCOUNT CURRENCY
      // ====================================

      if (

        receivableAccount.currency !==

        obligationCurrency

      ) {

        throw new AppError(

          'Contribution receivable account currency does not match obligation currency',

          400

        );

      }


      if (

        contributionAccount.currency !==

        obligationCurrency

      ) {

        throw new AppError(

          'Member contributions account currency does not match obligation currency',

          400

        );

      }


      // ====================================
      // CREATE OBLIGATION
      // ====================================

      const obligation =

        new ContributionObligation({

          plan_id,

          owner_type,

          owner_id,

          participant_type,

          participant_id,

          expected_amount:

            mongoose.Types.Decimal128.fromString(

              amount.toFixed()

            ),

          paid_amount:

            mongoose.Types.Decimal128.fromString(

              '0'

            ),

          currency:

            obligationCurrency,

          due_date:

            dueDate,

          period_start:

            periodStart,

          period_end:

            periodEnd,

          status:

            'pending',

          notes:

            typeof notes ===

            'string'

              ? notes.trim()

              : ''

        });


      // ====================================
      // SAVE OBLIGATION
      // ====================================

      await obligation.save({

        session

      });


      // ====================================
      // POST ACCOUNTING TRANSACTION
      // ====================================
      //
      // DR 1300 Member Contributions Receivable
      // CR 3000 Member Contributions
      //
      // This records an amount owed.
      //
      // It does NOT represent cash received.
      //
      // ====================================

      const financialTransaction =

        await postFinancialTransaction({

          owner_type,

          owner_id,

          transaction_type:

            'contribution_obligation',

          amount,

          currency:

            obligationCurrency,

          source_type:

            'ContributionObligation',

          source_id:

            obligation._id,

          description:

            `Contribution obligation recognized for participant ${participant_id}`,

          created_by,

          posted_by:

            posted_by ||

            created_by,

          entries: [

            // ==================================
            // DEBIT RECEIVABLE
            // ==================================

            {

              account_id:

                receivableAccount._id,

              entry_type:

                'debit',

              amount,

              description:

                'Contribution amount receivable from member'

            },


            // ==================================
            // CREDIT MEMBER CONTRIBUTIONS
            // ==================================

            {

              account_id:

                contributionAccount._id,

              entry_type:

                'credit',

              amount,

              description:

                'Member contribution obligation recognized'

            }

          ],

          session

        });


      // ====================================
      // LINK FINANCIAL TRANSACTION
      // ====================================

      if (

        financialTransaction &&

        financialTransaction._id

      ) {

        obligation.financial_transaction_id =

          financialTransaction._id;


        await obligation.save({

          session

        });

      }


      // ====================================
      // COMMIT TRANSACTION
      // ====================================

      if (

        ownsSession

      ) {

        await session.commitTransaction();

      }


      // ====================================
      // RETURN RESULT
      // ====================================

      return {

        obligation,

        financialTransaction

      };


    } catch (error) {

      // ====================================
      // ABORT ONLY OWN TRANSACTION
      // ====================================

      if (

        ownsSession &&

        session.inTransaction()

      ) {

        await session.abortTransaction();

      }


      throw error;


    } finally {

      // ====================================
      // END ONLY OWN SESSION
      // ====================================

      if (

        ownsSession

      ) {

        await session.endSession();

      }

    }

  };


// ========================================
// CREATE MULTIPLE OBLIGATIONS
// ========================================
//
// Used by contributionPlan.service.js.
//
// Every obligation and accounting entry
// participates in the same parent transaction
// when an existing session is supplied.
//
// ========================================

export const createContributionObligations =

  async ({

    plan_id,

    owner_type,

    owner_id,

    participants,

    due_date,

    period_start = null,

    period_end = null,

    currency,

    created_by,

    posted_by = null,

    session:

      existingSession = null

  }) => {

    // ======================================
    // VALIDATE PARTICIPANTS ARRAY
    // ======================================

    if (

      !Array.isArray(

        participants

      ) ||

      participants.length ===

      0

    ) {

      throw new AppError(

        'At least one contribution participant is required',

        400

      );

    }


    // ======================================
    // VALIDATE CREATOR
    // ======================================

    validateObjectId(

      created_by,

      'created by user ID'

    );


    // ======================================
    // VALIDATE POSTER
    // ======================================

    if (

      posted_by

    ) {

      validateObjectId(

        posted_by,

        'posted by user ID'

      );

    }


    // ======================================
    // VALIDATE OWNER
    // ======================================

    validateObjectId(

      owner_id,

      'owner ID'

    );


    validateOwnerType(

      owner_type

    );


    // ======================================
    // PREVENT DUPLICATE PARTICIPANTS
    // ======================================

    const participantKeys =

      participants.map(

        participant =>

          `${participant.participant_type}:${participant.participant_id}`

      );


    const uniqueParticipantKeys =

      new Set(

        participantKeys

      );


    if (

      uniqueParticipantKeys.size !==

      participantKeys.length

    ) {

      throw new AppError(

        'Duplicate participants are not allowed when creating contribution obligations in bulk',

        409

      );

    }


    // ======================================
    // SESSION OWNERSHIP
    // ======================================

    const ownsSession =

      !existingSession;


    const session =

      existingSession ||

      await mongoose.startSession();


    try {

      // ====================================
      // START TRANSACTION
      // ====================================

      if (

        ownsSession

      ) {

        session.startTransaction();

      }


      // ====================================
      // VALIDATE PLAN ONCE
      // ====================================

      const plan =

        await validateContributionPlan({

          plan_id,

          owner_type,

          owner_id,

          session

        });


      // ====================================
      // VALIDATE SHARED CURRENCY
      // ====================================

      const obligationCurrency =

        validateCurrency(

          currency ||

          plan.currency ||

          'KES'

        );


      if (

        plan.currency &&

        validateCurrency(

          plan.currency

        ) !==

        obligationCurrency

      ) {

        throw new AppError(

          'Contribution obligation currency must match the contribution plan currency',

          400

        );

      }


      // ====================================
      // VALIDATE PERIOD ONCE
      // ====================================

      const {

        periodStart,

        periodEnd

      } =

        validatePeriod({

          period_start,

          period_end

        });


      // ====================================
      // VALIDATE DUE DATE ONCE
      // ====================================

      const dueDate =

        validateDueDate({

          due_date,

          period_end

        });


      // ====================================
      // CREATE OBLIGATIONS
      // ====================================

      const createdObligations = [];


      for (

        const participant

        of participants

      ) {

        if (

          !participant ||

          typeof participant !==

          'object'

        ) {

          throw new AppError(

            'Each contribution participant must be a valid object',

            400

          );

        }


        const result =

          await createContributionObligation({

            plan_id,

            owner_type,

            owner_id,

            participant_type:

              participant.participant_type,

            participant_id:

              participant.participant_id,

            expected_amount:

              participant.expected_amount,

            currency:

              obligationCurrency,

            due_date:

              dueDate,

            period_start:

              periodStart,

            period_end:

              periodEnd,

            notes:

              participant.notes ||

              '',

            created_by,

            posted_by,

            session

          });


        createdObligations.push(

          result

        );

      }


      // ====================================
      // COMMIT ONLY OWN TRANSACTION
      // ====================================

      if (

        ownsSession

      ) {

        await session.commitTransaction();

      }


      return createdObligations;


    } catch (error) {

      // ====================================
      // ABORT ONLY OWN TRANSACTION
      // ====================================

      if (

        ownsSession &&

        session.inTransaction()

      ) {

        await session.abortTransaction();

      }


      throw error;


    } finally {

      // ====================================
      // END ONLY OWN SESSION
      // ====================================

      if (

        ownsSession

      ) {

        await session.endSession();

      }

    }

  };


// ========================================
// GET OBLIGATION BY ID
// ========================================

export const getContributionObligationById =

  async ({

    obligation_id,

    session = null

  }) => {

    validateObjectId(

      obligation_id,

      'contribution obligation ID'

    );


    const obligation =

      await ContributionObligation.findById(

        obligation_id

      )

        .session(

          session

        );


    if (!obligation) {

      throw new AppError(

        'Contribution obligation not found',

        404

      );

    }


    return obligation;

  };


// ========================================
// GET OWNER OBLIGATIONS
// ========================================

export const getOwnerContributionObligations =

  async ({

    owner_type,

    owner_id,

    status = null,

    participant_type = null,

    participant_id = null,

    session = null

  }) => {

    validateObjectId(

      owner_id,

      'owner ID'

    );


    validateOwnerType(

      owner_type

    );


    if (

      status

    ) {

      validateObligationStatus(

        status

      );

    }


    const query = {

      owner_type,

      owner_id

    };


    // ======================================
    // STATUS FILTER
    // ======================================

    if (

      status

    ) {

      query.status =

        status;

    }


    // ======================================
    // PARTICIPANT TYPE FILTER
    // ======================================

    if (

      participant_type

    ) {

      validateParticipantType(

        participant_type

      );


      validateOwnerParticipantCompatibility({

        owner_type,

        participant_type

      });


      query.participant_type =

        participant_type;

    }


    // ======================================
    // PARTICIPANT ID FILTER
    // ======================================

    if (

      participant_id

    ) {

      validateObjectId(

        participant_id,

        'participant ID'

      );


      query.participant_id =

        participant_id;

    }


    return ContributionObligation.find(

      query

    )

      .sort({

        due_date:

          1,

        createdAt:

          1

      })

      .session(

        session

      );

  };


// ========================================
// GET PARTICIPANT OBLIGATIONS
// ========================================

export const getParticipantContributionObligations =

  async ({

    participant_type,

    participant_id,

    status = null,

    session = null

  }) => {

    validateObjectId(

      participant_id,

      'participant ID'

    );


    validateParticipantType(

      participant_type

    );


    if (

      status

    ) {

      validateObligationStatus(

        status

      );

    }


    const query = {

      participant_type,

      participant_id

    };


    if (

      status

    ) {

      query.status =

        status;

    }


    return ContributionObligation.find(

      query

    )

      .sort({

        due_date:

          1,

        createdAt:

          1

      })

      .session(

        session

      );

  };


// ========================================
// CALCULATE REMAINING AMOUNT
// ========================================
//
// expected_amount
//       -
// paid_amount
//
// ========================================

export const calculateRemainingObligationAmount = (

  obligation

) => {

  if (!obligation) {

    throw new AppError(

      'Contribution obligation is required',

      400

    );

  }


  const expectedAmount =

    toDecimal(

      obligation.expected_amount

    );


  const paidAmount =

    toDecimal(

      obligation.paid_amount ||

      '0'

    );


  const remainingAmount =

    subtractMoney(

      expectedAmount,

      paidAmount

    );


  if (

    remainingAmount.isNegative()

  ) {

    throw new AppError(

      'Contribution obligation has an invalid paid amount exceeding the expected amount',

      500

    );

  }


  return remainingAmount;

};


// ========================================
// MARK OVERDUE OBLIGATION
// ========================================

export const markObligationOverdue =

  async ({

    obligation_id,

    session = null

  }) => {

    const obligation =

      await getContributionObligationById({

        obligation_id,

        session

      });


    // ======================================
    // TERMINAL STATES
    // ======================================

    if (

      TERMINAL_OBLIGATION_STATUSES.includes(

        obligation.status

      )

    ) {

      return obligation;

    }


    // ======================================
    // ALREADY OVERDUE
    // ======================================

    if (

      obligation.status ===

      'overdue'

    ) {

      return obligation;

    }


    // ======================================
    // VALIDATE DUE DATE
    // ======================================

    const dueDate =

      validateDateValue(

        obligation.due_date,

        'contribution obligation due date'

      );


    if (

      new Date() <=

      dueDate

    ) {

      throw new AppError(

        'Contribution obligation is not yet overdue',

        400

      );

    }


    // ======================================
    // NEVER MARK PARTIALLY PAID AS OVERDUE
    // ======================================

    const remainingAmount =

      calculateRemainingObligationAmount(

        obligation

      );


    if (

      remainingAmount.isZero()

    ) {

      obligation.status =

        'paid';

    }

    else {

      obligation.status =

        'overdue';

    }


    await obligation.save({

      session

    });


    return obligation;

  };


// ========================================
// WAIVE OBLIGATION
// ========================================

export const waiveContributionObligation =

  async ({

    obligation_id,

    waived_by,

    waiver_reason = '',

    session = null

  }) => {

    const obligation =

      await getContributionObligationById({

        obligation_id,

        session

      });


    // ======================================
    // VALIDATE STATUS
    // ======================================

    if (

      TERMINAL_OBLIGATION_STATUSES.includes(

        obligation.status

      )

    ) {

      throw new AppError(

        `Cannot waive an obligation with status: ${obligation.status}`,

        400

      );

    }


    // ======================================
    // VALIDATE PAYMENT STATE
    // ======================================

    const remainingAmount =

      calculateRemainingObligationAmount(

        obligation

      );


    if (

      !isMoneyEqual(

        remainingAmount,

        toDecimal(

          obligation.expected_amount

        )

      )

    ) {

      throw new AppError(

        'Partially paid obligations cannot be waived through the standard waiver workflow',

        400

      );

    }


    // ======================================
    // VALIDATE USER
    // ======================================

    validateObjectId(

      waived_by,

      'waived by user ID'

    );


    // ======================================
    // UPDATE WAIVER
    // ======================================

    obligation.status =

      'waived';


    obligation.waived_by =

      waived_by;


    obligation.waived_at =

      new Date();


    obligation.waiver_reason =

      typeof waiver_reason ===

      'string'

        ? waiver_reason.trim()

        : '';


    await obligation.save({

      session

    });


    return obligation;

  };


// ========================================
// CANCEL OBLIGATION
// ========================================

export const cancelContributionObligation =

  async ({

    obligation_id,

    cancelled_by,

    cancellation_reason = '',

    session = null

  }) => {

    const obligation =

      await getContributionObligationById({

        obligation_id,

        session

      });


    // ======================================
    // VALIDATE STATUS
    // ======================================

    if (

      TERMINAL_OBLIGATION_STATUSES.includes(

        obligation.status

      )

    ) {

      throw new AppError(

        `Cannot cancel an obligation with status: ${obligation.status}`,

        400

      );

    }


    // ======================================
    // PREVENT CANCELLATION AFTER PAYMENT
    // ======================================

    const paidAmount =

      toDecimal(

        obligation.paid_amount ||

        '0'

      );


    if (

      paidAmount.greaterThan(

        toDecimal(

          '0'

        )

      )

    ) {

      throw new AppError(

        'Partially paid obligations cannot be cancelled through the standard cancellation workflow',

        400

      );

    }


    // ======================================
    // VALIDATE USER
    // ======================================

    validateObjectId(

      cancelled_by,

      'cancelled by user ID'

    );


    // ======================================
    // UPDATE CANCELLATION
    // ======================================

    obligation.status =

      'cancelled';


    obligation.cancelled_by =

      cancelled_by;


    obligation.cancelled_at =

      new Date();


    obligation.cancellation_reason =

      typeof cancellation_reason ===

      'string'

        ? cancellation_reason.trim()

        : '';


    await obligation.save({

      session

    });


    return obligation;

  };


// ========================================
// UPDATE OBLIGATION STATUS AFTER PAYMENT
// ========================================
//
// Called by:
//
// contributionPayment.service.js
//
// The payment service calculates the new
// paid amount.
//
// This service determines the resulting
// obligation state.
//
// ========================================

export const updateObligationPaymentState =

  async ({

    obligation,

    newPaidAmount,

    session = null

  }) => {

    if (!obligation) {

      throw new AppError(

        'Contribution obligation is required',

        400

      );

    }


    // ======================================
    // PREVENT PAYMENT ON TERMINAL STATES
    // ======================================

    if (

      TERMINAL_OBLIGATION_STATUSES.includes(

        obligation.status

      )

    ) {

      throw new AppError(

        `Cannot update payment state for an obligation with status: ${obligation.status}`,

        400

      );

    }


    const expectedAmount =

      toDecimal(

        obligation.expected_amount

      );


    const paidAmount =

      validateExpectedAmount(

        newPaidAmount

      );


    // ======================================
    // PREVENT OVERPAYMENT
    // ======================================

    if (

      paidAmount.greaterThan(

        expectedAmount

      )

    ) {

      throw new AppError(

        'Paid amount cannot exceed the contribution obligation expected amount',

        400

      );

    }


    // ======================================
    // UPDATE STATUS
    // ======================================

    if (

      isMoneyEqual(

        paidAmount,

        expectedAmount

      )

    ) {

      obligation.status =

        'paid';

    }

    else if (

      paidAmount.greaterThan(

        toDecimal(

          '0'

        )

      )

    ) {

      obligation.status =

        'partially_paid';

    }

    else if (

      new Date() >

      new Date(

        obligation.due_date

      )

    ) {

      obligation.status =

        'overdue';

    }

    else {

      obligation.status =

        'pending';

    }


    // ======================================
    // SAVE NEW PAID AMOUNT
    // ======================================

    obligation.paid_amount =

      mongoose.Types.Decimal128.fromString(

        paidAmount.toFixed()

      );


    await obligation.save({

      session

    });


    return obligation;

  };


// ========================================
// EXPORT VALIDATION HELPERS
// ========================================

export {

  OWNER_TYPES,

  PARTICIPANT_TYPES,

  OBLIGATION_STATUSES,

  validateObjectId,

  validateOwnerType,

  validateParticipantType,

  validateObligationStatus,

  validateParticipant,

  validateContributionPlan,

  validateOwnerParticipantCompatibility,

  validateExpectedAmount,

  validateCurrency,

  validatePeriod,

  validateDueDate,

  determineExpectedAmount,

  getContributionObligationAccounts

};