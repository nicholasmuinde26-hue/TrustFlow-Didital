import express from 'express';

import {
  createPlan,
  getPlanById,
  getPlans,
  updatePlan,
  activatePlan,
  pausePlan,
  resumePlan,
  completePlan,
  cancelPlan,
  getPlanObligations,
  getPlanPayments,
  getPlanFinancialSummary
} from './contributionPlan.controller.js';


// ========================================
// CONTRIBUTION PLAN ROUTER
// ========================================
//
// Base route:
//
// /api/contribution-plans
//
// Responsibilities:
//
// - Create contribution plans
// - Retrieve contribution plans
// - Update contribution plans
// - Manage plan lifecycle
// - View plan obligations
// - View plan payments
// - View plan financial summary
//
// Business logic remains inside:
//
// contributionPlan.service.js
//
// ========================================

const router = express.Router();


// ========================================
// PLAN CREATION
// ========================================
//
// POST /api/contribution-plans
//
// ========================================

router.post(
  '/',
  createPlan
);


// ========================================
// PLAN COLLECTION
// ========================================
//
// GET /api/contribution-plans
//
// Query parameters:
//
// ?owner_type=Chama
// ?owner_id=...
// ?status=active
// ?contribution_type=fixed
// ?frequency=monthly
//
// ========================================

router.get(
  '/',
  getPlans
);


// ========================================
// PLAN OBLIGATIONS
// ========================================
//
// GET /api/contribution-plans/:planId/obligations
//
// Query parameters:
//
// ?status=pending
// ?participant_type=ChamaMembership
// ?participant_id=...
//
// ========================================

router.get(
  '/:planId/obligations',
  getPlanObligations
);


// ========================================
// PLAN PAYMENTS
// ========================================
//
// GET /api/contribution-plans/:planId/payments
//
// Query parameters:
//
// ?status=completed
// ?participant_type=ChamaMembership
// ?participant_id=...
//
// ========================================

router.get(
  '/:planId/payments',
  getPlanPayments
);


// ========================================
// PLAN FINANCIAL SUMMARY
// ========================================
//
// GET /api/contribution-plans/:planId/financial-summary
//
// ========================================

router.get(
  '/:planId/financial-summary',
  getPlanFinancialSummary
);


// ========================================
// ACTIVATE PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/activate
//
// draft → active
//
// ========================================

router.patch(
  '/:planId/activate',
  activatePlan
);


// ========================================
// PAUSE PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/pause
//
// active → paused
//
// ========================================

router.patch(
  '/:planId/pause',
  pausePlan
);


// ========================================
// RESUME PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/resume
//
// paused → active
//
// ========================================

router.patch(
  '/:planId/resume',
  resumePlan
);


// ========================================
// COMPLETE PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/complete
//
// active / paused → completed
//
// ========================================

router.patch(
  '/:planId/complete',
  completePlan
);


// ========================================
// CANCEL PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/cancel
//
// ========================================

router.patch(
  '/:planId/cancel',
  cancelPlan
);


// ========================================
// UPDATE PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId
//
// ========================================

router.patch(
  '/:planId',
  updatePlan
);


// ========================================
// PLAN RETRIEVAL
// ========================================
//
// GET /api/contribution-plans/:planId
//
// ========================================

router.get(
  '/:planId',
  getPlanById
);


// ========================================
// EXPORT ROUTER
// ========================================

export default router;