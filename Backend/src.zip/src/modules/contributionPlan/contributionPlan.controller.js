import AppError from '../../utils/AppError.js';

import {
  createContributionPlan,
  getContributionPlanById,
  getOwnerContributionPlans,
  updateContributionPlan,
  activateContributionPlan,
  pauseContributionPlan,
  resumeContributionPlan,
  completeContributionPlan,
  cancelContributionPlan,
  getContributionPlanObligations,
  getContributionPlanPayments,
  getContributionPlanFinancialSummary
} from './contributionPlan.service.js';


// ========================================
// CONTRIBUTION PLAN CONTROLLER
// ========================================
//
// HTTP layer for ContributionPlan.
//
// Responsibilities:
//
// - Extract request data
// - Extract authenticated user
// - Call service layer
// - Return API response
//
// IMPORTANT:
//
// Controllers do NOT own business logic.
//
// Business rules belong to:
//
// contributionPlan.service.js
//
// Ownership validation is delegated to
// the service layer.
//
// ========================================


// ========================================
// GET AUTHENTICATED USER ID
// ========================================
//
// Supports common authentication patterns:
//
// req.user._id
// req.user.id
// req.user.user_id
//
// ========================================

const getAuthenticatedUserId = (req) => {

  const userId =
    req.user?._id ||
    req.user?.id ||
    req.user?.user_id;

  if (!userId) {

    throw new AppError(
      'Authenticated user not found',
      401
    );

  }

  return userId;

};


// ========================================
// CREATE CONTRIBUTION PLAN
// ========================================
//
// POST /api/contribution-plans
//
// Creates a new contribution plan.
//
// The authenticated user becomes the
// plan creator.
//
// ========================================

export const createPlan = async (
  req,
  res,
  next
) => {

  try {

    const createdBy =
      getAuthenticatedUserId(req);


    const {
      owner_type,
      owner_id,
      name,
      description,
      contribution_type,
      frequency,
      amount,
      target_amount,
      minimum_amount,
      maximum_amount,
      custom_frequency_days,
      start_date,
      end_date,
      is_permanent,
      merry_go_round
    } = req.body;


    const plan =
      await createContributionPlan({

        owner_type,

        owner_id,

        created_by:
          createdBy,

        name,

        description,

        contribution_type,

        frequency,

        amount,

        target_amount,

        minimum_amount,

        maximum_amount,

        custom_frequency_days,

        start_date,

        end_date,

        is_permanent,

        merry_go_round

      });


    return res.status(201).json({

      success: true,

      message:
        'Contribution plan created successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// GET CONTRIBUTION PLAN BY ID
// ========================================
//
// GET /api/contribution-plans/:planId
//
// Optional query parameters:
//
// ?owner_type=Chama
// ?owner_id=...
//
// Supplying owner context allows the service
// to verify that the plan belongs to the
// expected owner.
//
// ========================================

export const getPlanById = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id
    } = req.query;


    const plan =
      await getContributionPlanById({

        plan_id:
          planId,

        owner_type,

        owner_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan retrieved successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// GET CONTRIBUTION PLANS
// ========================================
//
// GET /api/contribution-plans
//
// Supported query parameters:
//
// owner_type
// owner_id
// status
//
// NOTE:
//
// The current service exposes
// getOwnerContributionPlans().
//
// Therefore owner_type and owner_id
// are required for this endpoint.
//
// ========================================

export const getPlans = async (
  req,
  res,
  next
) => {

  try {

    const {
      owner_type,
      owner_id,
      status
    } = req.query;


    const plans =
      await getOwnerContributionPlans({

        owner_type,

        owner_id,

        status

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plans retrieved successfully',

      data: {

        plans,

        count:
          plans.length

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// UPDATE CONTRIBUTION PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId
//
// Required body:
//
// owner_type
// owner_id
//
// Other fields are treated as plan updates.
//
// The service validates which fields are
// actually editable.
//
// ========================================

export const updatePlan = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id,
      ...updates
    } = req.body;


    const plan =
      await updateContributionPlan({

        plan_id:
          planId,

        owner_type,

        owner_id,

        updates

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan updated successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// ACTIVATE CONTRIBUTION PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/activate
//
// Required body:
//
// owner_type
// owner_id
//
// draft → active
//
// ========================================

export const activatePlan = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id
    } = req.body;


    const plan =
      await activateContributionPlan({

        plan_id:
          planId,

        owner_type,

        owner_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan activated successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// PAUSE CONTRIBUTION PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/pause
//
// Required body:
//
// owner_type
// owner_id
//
// active → paused
//
// ========================================

export const pausePlan = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id
    } = req.body;


    const plan =
      await pauseContributionPlan({

        plan_id:
          planId,

        owner_type,

        owner_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan paused successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// RESUME CONTRIBUTION PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/resume
//
// Required body:
//
// owner_type
// owner_id
//
// paused → active
//
// ========================================

export const resumePlan = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id
    } = req.body;


    const plan =
      await resumeContributionPlan({

        plan_id:
          planId,

        owner_type,

        owner_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan resumed successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// COMPLETE CONTRIBUTION PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/complete
//
// Required body:
//
// owner_type
// owner_id
//
// active / paused → completed
//
// ========================================

export const completePlan = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id
    } = req.body;


    const plan =
      await completeContributionPlan({

        plan_id:
          planId,

        owner_type,

        owner_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan completed successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// CANCEL CONTRIBUTION PLAN
// ========================================
//
// PATCH /api/contribution-plans/:planId/cancel
//
// Required body:
//
// owner_type
// owner_id
//
// ========================================

export const cancelPlan = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id
    } = req.body;


    const plan =
      await cancelContributionPlan({

        plan_id:
          planId,

        owner_type,

        owner_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan cancelled successfully',

      data: {

        plan

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// GET PLAN OBLIGATIONS
// ========================================
//
// GET /api/contribution-plans/:planId/obligations
//
// Query parameters:
//
// owner_type
// owner_id
// status
// participant_type
// participant_id
//
// ========================================

export const getPlanObligations = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id,
      status,
      participant_type,
      participant_id
    } = req.query;


    const obligations =
      await getContributionPlanObligations({

        plan_id:
          planId,

        owner_type,

        owner_id,

        status,

        participant_type,

        participant_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan obligations retrieved successfully',

      data: {

        obligations,

        count:
          obligations.length

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// GET PLAN PAYMENTS
// ========================================
//
// GET /api/contribution-plans/:planId/payments
//
// Query parameters:
//
// owner_type
// owner_id
// status
// participant_type
// participant_id
//
// ========================================

export const getPlanPayments = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id,
      status,
      participant_type,
      participant_id
    } = req.query;


    const payments =
      await getContributionPlanPayments({

        plan_id:
          planId,

        owner_type,

        owner_id,

        status,

        participant_type,

        participant_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan payments retrieved successfully',

      data: {

        payments,

        count:
          payments.length

      }

    });

  } catch (error) {

    next(error);

  }

};


// ========================================
// GET PLAN FINANCIAL SUMMARY
// ========================================
//
// GET /api/contribution-plans/:planId/financial-summary
//
// Query parameters:
//
// owner_type
// owner_id
//
// ========================================

export const getPlanFinancialSummary = async (
  req,
  res,
  next
) => {

  try {

    const {
      planId
    } = req.params;


    const {
      owner_type,
      owner_id
    } = req.query;


    const summary =
      await getContributionPlanFinancialSummary({

        plan_id:
          planId,

        owner_type,

        owner_id

      });


    return res.status(200).json({

      success: true,

      message:
        'Contribution plan financial summary retrieved successfully',

      data: {

        summary

      }

    });

  } catch (error) {

    next(error);

  }

};