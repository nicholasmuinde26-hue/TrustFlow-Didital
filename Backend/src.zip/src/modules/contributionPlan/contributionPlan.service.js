import mongoose from 'mongoose';

import ContributionPlan
  from '../../models/ContributionPlan.js';

import ContributionObligation
  from '../../models/ContributionObligation.js';

import ContributionPayment
  from '../../models/ContributionPayment.js';

import AppError
  from '../../utils/AppError.js';

import {
  toDecimal,
  addMoney,
  isMoneyEqual,
  isMoneyPositive
} from '../../shared/decimal.js';

import {
  getOwnerContributionPayments,
  reconcileContributionObligationPayments
} from './contributionPayment.service.js';


// ========================================
// CONTRIBUTION PLAN SERVICE
// ========================================
//
// Responsible for:
//
// - Creating contribution plans
// - Updating contribution plans
// - Managing plan lifecycle
// - Retrieving plans
// - Retrieving plan obligations
// - Retrieving plan payments
// - Calculating plan-level financial summaries
// - Reconciling plan payments
// - Generating participant summaries
//
// Architecture:
//
// ContributionPlan
//       │
//       ├── Contribution rules
//       │
//       ▼
// ContributionObligation
//       │
//       ├── Amount owed
//       │
//       ▼
// ContributionPayment
//       │
//       ├── Money received
//       │
//       ▼
// FinancialTransaction
//
// IMPORTANT:
//
// This service owns PLAN-level business logic.
//
// ContributionObligation service owns:
//
// - Obligation creation
// - Obligation lifecycle
// - Expected amount
// - Paid amount
//
// ContributionPayment service owns:
//
// - Payment creation
// - Payment validation
// - Payment lifecycle
// - Payment reconciliation
// - Financial transaction posting
//
// ========================================


// ========================================
// SUPPORTED OWNER TYPES
// ========================================

const OWNER_TYPES = [

  'Chama',

  'ContributionGroup'

];


// ========================================
// SUPPORTED PARTICIPANT TYPES
// ========================================

const PARTICIPANT_TYPES = [

  'ChamaMembership',

  'ContributionGroupMember'

];


// ========================================
// SUPPORTED CONTRIBUTION TYPES
// ========================================

const CONTRIBUTION_TYPES = [

  'fixed',

  'free_will',

  'target',

  'merry_go_round'

];


// ========================================
// SUPPORTED FREQUENCIES
// ========================================

const FREQUENCIES = [

  'once',

  'daily',

  'weekly',

  'monthly',

  'quarterly',

  'yearly',

  'custom'

];


// ========================================
// SUPPORTED PLAN STATUSES
// ========================================

const PLAN_STATUSES = [

  'draft',

  'active',

  'paused',

  'completed',

  'cancelled'

];


// ========================================
// MERRY-GO-ROUND INTERVALS
// ========================================

const MERRY_GO_ROUND_INTERVALS = [

  'weekly',

  'monthly',

  'quarterly',

  'yearly',

  'custom'

];


// ========================================
// VALIDATE OBJECT ID
// ========================================

const validateObjectId = (

  value,

  fieldName

) => {

  if (

    !value ||

    !mongoose.Types.ObjectId.isValid(

      value

    )

  ) {

    throw new AppError(

      `Invalid ${fieldName}`,

      400

    );

  }

};


// ========================================
// VALIDATE OWNER TYPE
// ========================================

const validateOwnerType = (

  owner_type

) => {

  if (

    !OWNER_TYPES.includes(

      owner_type

    )

  ) {

    throw new AppError(

      'Invalid contribution plan owner type',

      400

    );

  }

};


// ========================================
// VALIDATE PARTICIPANT TYPE
// ========================================

const validateParticipantType = (

  participant_type

) => {

  if (

    !PARTICIPANT_TYPES.includes(

      participant_type

    )

  ) {

    throw new AppError(

      'Invalid contribution plan participant type',

      400

    );

  }

};


// ========================================
// VALIDATE OWNER / PARTICIPANT
// COMPATIBILITY
// ========================================

const validateOwnerParticipantCompatibility = ({

  owner_type,

  participant_type

}) => {

  validateOwnerType(

    owner_type

  );

  validateParticipantType(

    participant_type

  );


  if (

    owner_type ===

    'Chama' &&

    participant_type !==

    'ChamaMembership'

  ) {

    throw new AppError(

      'Chama contribution plans must use ChamaMembership participants',

      400

    );

  }


  if (

    owner_type ===

    'ContributionGroup' &&

    participant_type !==

    'ContributionGroupMember'

  ) {

    throw new AppError(

      'ContributionGroup contribution plans must use ContributionGroupMember participants',

      400

    );

  }

};


// ========================================
// VALIDATE CONTRIBUTION TYPE
// ========================================

const validateContributionType = (

  contribution_type

) => {

  if (

    !CONTRIBUTION_TYPES.includes(

      contribution_type

    )

  ) {

    throw new AppError(

      'Invalid contribution plan type',

      400

    );

  }

};


// ========================================
// VALIDATE FREQUENCY
// ========================================

const validateFrequency = (

  frequency

) => {

  if (

    !FREQUENCIES.includes(

      frequency

    )

  ) {

    throw new AppError(

      'Invalid contribution plan frequency',

      400

    );

  }

};


// ========================================
// VALIDATE PLAN STATUS
// ========================================

const validatePlanStatus = (

  status

) => {

  if (

    !PLAN_STATUSES.includes(

      status

    )

  ) {

    throw new AppError(

      'Invalid contribution plan status',

      400

    );

  }

};


// ========================================
// VALIDATE DATE
// ========================================

const validateDate = (

  value,

  fieldName

) => {

  if (

    value === null ||

    value === undefined

  ) {

    return null;

  }


  const date =

    new Date(

      value

    );


  if (

    Number.isNaN(

      date.getTime()

    )

  ) {

    throw new AppError(

      `Invalid ${fieldName}`,

      400

    );

  }


  return date;

};


// ========================================
// VALIDATE PLAN DATES
// ========================================

const validatePlanDates = ({

  start_date,

  end_date,

  is_permanent

}) => {

  const startDate =

    validateDate(

      start_date,

      'plan start date'

    );


  const endDate =

    validateDate(

      end_date,

      'plan end date'

    );


  if (

    startDate &&

    endDate &&

    endDate < startDate

  ) {

    throw new AppError(

      'Plan end date cannot be before plan start date',

      400

    );

  }


  if (

    is_permanent &&

    endDate

  ) {

    throw new AppError(

      'A permanent contribution plan cannot have an end date',

      400

    );

  }


  return {

    startDate,

    endDate

  };

};


// ========================================
// VALIDATE INTEGER
// ========================================

const validatePositiveInteger = (

  value,

  fieldName

) => {

  if (

    value === null ||

    value === undefined

  ) {

    return null;

  }


  if (

    !Number.isInteger(

      Number(

        value

      )

    ) ||

    Number(

      value

    ) < 1

  ) {

    throw new AppError(

      `${fieldName} must be a positive integer`,

      400

    );

  }


  return Number(

    value

  );

};


// ========================================
// VALIDATE MONEY VALUE
// ========================================

const validateMoneyValue = (

  value,

  fieldName,

  options = {}

) => {

  if (

    value === null ||

    value === undefined

  ) {

    return null;

  }


  let decimalValue;


  try {

    decimalValue =

      toDecimal(

        value?.toString?.()

          ?? value

      );

  } catch (

    error

  ) {

    throw new AppError(

      `Invalid ${fieldName}`,

      400

    );

  }


  if (

    options.mustBePositive &&

    !isMoneyPositive(

      decimalValue

    )

  ) {

    throw new AppError(

      `${fieldName} must be greater than zero`,

      400

    );

  }


  if (

    !options.mustBePositive &&

    decimalValue.isNegative()

  ) {

    throw new AppError(

      `${fieldName} cannot be negative`,

      400

    );

  }


  return decimalValue;

};


// ========================================
// VALIDATE CONTRIBUTION RULES
// ========================================

const validateContributionRules = ({

  contribution_type,

  amount,

  target_amount,

  minimum_amount,

  maximum_amount,

  frequency,

  custom_frequency_days,

  merry_go_round

}) => {

  validateContributionType(

    contribution_type

  );


  validateFrequency(

    frequency

  );


  const fixedAmount =

    validateMoneyValue(

      amount,

      'contribution amount',

      {

        mustBePositive:

          true

      }

    );


  const targetAmount =

    validateMoneyValue(

      target_amount,

      'target amount',

      {

        mustBePositive:

          true

      }

    );


  const minimumAmount =

    validateMoneyValue(

      minimum_amount,

      'minimum contribution amount',

      {

        mustBePositive:

          true

      }

    );


  const maximumAmount =

    validateMoneyValue(

      maximum_amount,

      'maximum contribution amount',

      {

        mustBePositive:

          true

      }

    );


  const normalizedCustomFrequencyDays =

    validatePositiveInteger(

      custom_frequency_days,

      'custom_frequency_days'

    );


  // ======================================
  // FIXED
  // ======================================

  if (

    contribution_type ===

    'fixed' &&

    !fixedAmount

  ) {

    throw new AppError(

      'Fixed contribution plans require an amount',

      400

    );

  }


  // ======================================
  // TARGET
  // ======================================

  if (

    contribution_type ===

    'target' &&

    !targetAmount

  ) {

    throw new AppError(

      'Target contribution plans require a target amount',

      400

    );

  }


  // ======================================
  // FREE WILL
  // ======================================

  if (

    contribution_type ===

    'free_will'

  ) {

    if (

      minimumAmount &&

      maximumAmount &&

      minimumAmount.greaterThan(

        maximumAmount

      )

    ) {

      throw new AppError(

        'Minimum contribution amount cannot exceed maximum contribution amount',

        400

      );

    }

  }


  // ======================================
  // CUSTOM FREQUENCY
  // ======================================

  if (

    frequency ===

    'custom' &&

    !normalizedCustomFrequencyDays

  ) {

    throw new AppError(

      'Custom frequency plans require custom_frequency_days',

      400

    );

  }


  if (

    frequency !==

    'custom' &&

    normalizedCustomFrequencyDays !==

    null

  ) {

    throw new AppError(

      'custom_frequency_days can only be used with custom frequency',

      400

    );

  }


  // ======================================
  // MERRY-GO-ROUND
  // ======================================

  if (

    contribution_type ===

    'merry_go_round'

  ) {

    if (

      !fixedAmount

    ) {

      throw new AppError(

        'Merry-go-round plans require a contribution amount',

        400

      );

    }


    if (

      !merry_go_round ||

      merry_go_round.enabled !==

      true

    ) {

      throw new AppError(

        'Merry-go-round contribution plans must enable merry_go_round settings',

        400

      );

    }

  }


  // ======================================
  // MERRY-GO-ROUND SETTINGS
  // ======================================

  if (

    merry_go_round &&

    merry_go_round.enabled ===

    true

  ) {

    if (

      !MERRY_GO_ROUND_INTERVALS.includes(

        merry_go_round.payout_interval

      )

    ) {

      throw new AppError(

        'Invalid merry-go-round payout interval',

        400

      );

    }


    const payoutIntervalDays =

      validatePositiveInteger(

        merry_go_round.payout_interval_days,

        'payout_interval_days'

      );


    if (

      merry_go_round.payout_interval ===

      'custom' &&

      !payoutIntervalDays

    ) {

      throw new AppError(

        'Custom merry-go-round payout interval requires payout_interval_days',

        400

      );

    }


    if (

      merry_go_round.payout_interval !==

      'custom' &&

      payoutIntervalDays !==

      null

    ) {

      throw new AppError(

        'payout_interval_days can only be used with custom merry-go-round payout intervals',

        400

      );

    }

  }


  return {

    fixedAmount,

    targetAmount,

    minimumAmount,

    maximumAmount,

    customFrequencyDays:

      normalizedCustomFrequencyDays

  };

};


// ========================================
// CONVERT DECIMAL TO MONGOOSE DECIMAL128
// ========================================

const decimalToDecimal128 = (

  value

) => {

  if (

    value === null ||

    value === undefined

  ) {

    return null;

  }


  return mongoose.Types.Decimal128.fromString(

    value.toFixed()

  );

};


// ========================================
// LOAD PLAN
// ========================================

const loadPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  session

}) => {

  validateObjectId(

    plan_id,

    'contribution plan ID'

  );


  validateOwnerType(

    owner_type

  );


  validateObjectId(

    owner_id,

    'owner ID'

  );


  const plan =

    await ContributionPlan.findOne({

      _id:

        plan_id,

      owner_type,

      owner_id

    })

      .session(

        session

      );


  if (

    !plan

  ) {

    throw new AppError(

      'Contribution plan not found or does not belong to the specified owner',

      404

    );

  }


  return plan;

};


// ========================================
// ENSURE PLAN CAN BE UPDATED
// ========================================

const ensurePlanCanBeUpdated = (

  plan

) => {

  if (

    plan.status ===

    'cancelled'

  ) {

    throw new AppError(

      'Cancelled contribution plans cannot be updated',

      400

    );

  }


  if (

    plan.status ===

    'completed'

  ) {

    throw new AppError(

      'Completed contribution plans cannot be updated',

      400

    );

  }

};


// ========================================
// ENSURE PLAN CAN BE ACTIVATED
// ========================================

const ensurePlanCanBeActivated = (

  plan

) => {

  if (

    plan.status ===

    'cancelled'

  ) {

    throw new AppError(

      'Cancelled contribution plans cannot be activated',

      400

    );

  }


  if (

    plan.status ===

    'completed'

  ) {

    throw new AppError(

      'Completed contribution plans cannot be activated',

      400

    );

  }


  if (

    plan.status ===

    'active'

  ) {

    throw new AppError(

      'Contribution plan is already active',

      400

    );

  }


  if (

    plan.end_date &&

    new Date(

      plan.end_date

    ) < new Date()

  ) {

    throw new AppError(

      'Contribution plan has already expired',

      400

    );

  }

};


// ========================================
// CREATE CONTRIBUTION PLAN
// ========================================

export const createContributionPlan = async ({

  owner_type,

  owner_id,

  created_by,

  name,

  description = '',

  contribution_type,

  frequency = 'once',

  amount = null,

  target_amount = null,

  minimum_amount = null,

  maximum_amount = null,

  custom_frequency_days = null,

  start_date = new Date(),

  end_date = null,

  is_permanent = false,

  merry_go_round = null,

  status = 'draft',

  session:

    existingSession = null

}) => {

  const ownsSession =

    !existingSession;


  const session =

    existingSession ||

    await mongoose.startSession();


  try {

    if (

      ownsSession

    ) {

      session.startTransaction();

    }


    validateOwnerType(

      owner_type

    );


    validateObjectId(

      owner_id,

      'owner ID'

    );


    validateObjectId(

      created_by,

      'plan creator ID'

    );


    if (

      !name ||

      typeof name !==

      'string' ||

      name.trim().length < 2

    ) {

      throw new AppError(

        'Contribution plan name must contain at least 2 characters',

        400

      );

    }


    validatePlanStatus(

      status

    );


    const {

      startDate,

      endDate

    } = validatePlanDates({

      start_date,

      end_date,

      is_permanent

    });


    const {

      fixedAmount,

      targetAmount,

      minimumAmount,

      maximumAmount,

      customFrequencyDays

    } = validateContributionRules({

      contribution_type,

      amount,

      target_amount,

      minimum_amount,

      maximum_amount,

      frequency,

      custom_frequency_days,

      merry_go_round

    });


    const plan =

      new ContributionPlan({

        owner_type,

        owner_id,

        created_by,

        name:

          name.trim(),

        description:

          typeof description ===

          'string'

            ? description.trim()

            : '',

        contribution_type,

        frequency,

        amount:

          contribution_type ===

          'fixed' ||

          contribution_type ===

          'merry_go_round'

            ? decimalToDecimal128(

                fixedAmount

              )

            : null,

        target_amount:

          contribution_type ===

          'target'

            ? decimalToDecimal128(

                targetAmount

              )

            : null,

        minimum_amount:

          decimalToDecimal128(

            minimumAmount

          ),

        maximum_amount:

          decimalToDecimal128(

            maximumAmount

          ),

        custom_frequency_days:

          customFrequencyDays,

        start_date:

          startDate ||

          new Date(),

        end_date:

          endDate,

        is_permanent,

        merry_go_round:

          merry_go_round || {

            enabled:

              false

          },

        status

      });


    await plan.save({

      session

    });


    if (

      ownsSession

    ) {

      await session.commitTransaction();

    }


    return plan;

  } catch (

    error

  ) {

    if (

      ownsSession &&

      session.inTransaction()

    ) {

      await session.abortTransaction();

    }


    throw error;

  } finally {

    if (

      ownsSession

    ) {

      await session.endSession();

    }

  }

};


// ========================================
// UPDATE CONTRIBUTION PLAN
// ========================================

export const updateContributionPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  updates = {},

  session:

    existingSession = null

}) => {

  const ownsSession =

    !existingSession;


  const session =

    existingSession ||

    await mongoose.startSession();


  try {

    if (

      ownsSession

    ) {

      session.startTransaction();

    }


    const plan =

      await loadPlan({

        plan_id,

        owner_type,

        owner_id,

        session

      });


    ensurePlanCanBeUpdated(

      plan

    );


    const allowedFields = [

      'name',

      'description',

      'contribution_type',

      'frequency',

      'amount',

      'target_amount',

      'minimum_amount',

      'maximum_amount',

      'custom_frequency_days',

      'start_date',

      'end_date',

      'is_permanent',

      'merry_go_round'

    ];


    const unknownFields =

      Object.keys(

        updates

      ).filter(

        field =>

          !allowedFields.includes(

            field

          )

      );


    if (

      unknownFields.length

    ) {

      throw new AppError(

        `Unsupported contribution plan update fields: ${unknownFields.join(', ')}`,

        400

      );

    }


    if (

      updates.name !==

      undefined

    ) {

      if (

        typeof updates.name !==

        'string' ||

        updates.name.trim().length < 2

      ) {

        throw new AppError(

          'Contribution plan name must contain at least 2 characters',

          400

        );

      }


      plan.name =

        updates.name.trim();

    }


    if (

      updates.description !==

      undefined

    ) {

      if (

        typeof updates.description !==

        'string'

      ) {

        throw new AppError(

          'Contribution plan description must be a string',

          400

        );

      }


      plan.description =

        updates.description.trim();

    }


    const merged = {

      contribution_type:

        updates.contribution_type ??

        plan.contribution_type,

      frequency:

        updates.frequency ??

        plan.frequency,

      amount:

        updates.amount ??

        plan.amount,

      target_amount:

        updates.target_amount ??

        plan.target_amount,

      minimum_amount:

        updates.minimum_amount ??

        plan.minimum_amount,

      maximum_amount:

        updates.maximum_amount ??

        plan.maximum_amount,

      custom_frequency_days:

        updates.custom_frequency_days ??

        plan.custom_frequency_days,

      merry_go_round:

        updates.merry_go_round ??

        plan.merry_go_round

    };


    const {

      fixedAmount,

      targetAmount,

      minimumAmount,

      maximumAmount,

      customFrequencyDays

    } = validateContributionRules(

      merged

    );


    const mergedDates =

      validatePlanDates({

        start_date:

          updates.start_date ??

          plan.start_date,

        end_date:

          updates.end_date ??

          plan.end_date,

        is_permanent:

          updates.is_permanent ??

          plan.is_permanent

      });


    plan.contribution_type =

      merged.contribution_type;


    plan.frequency =

      merged.frequency;


    plan.amount =

      merged.contribution_type ===

      'fixed' ||

      merged.contribution_type ===

      'merry_go_round'

        ? decimalToDecimal128(

            fixedAmount

          )

        : null;


    plan.target_amount =

      merged.contribution_type ===

      'target'

        ? decimalToDecimal128(

            targetAmount

          )

        : null;


    plan.minimum_amount =

      decimalToDecimal128(

        minimumAmount

      );


    plan.maximum_amount =

      decimalToDecimal128(

        maximumAmount

      );


    plan.custom_frequency_days =

      customFrequencyDays;


    plan.merry_go_round =

      merged.merry_go_round;


    plan.start_date =

      mergedDates.startDate;


    plan.end_date =

      mergedDates.endDate;


    plan.is_permanent =

      updates.is_permanent ??

      plan.is_permanent;


    await plan.save({

      session

    });


    if (

      ownsSession

    ) {

      await session.commitTransaction();

    }


    return plan;

  } catch (

    error

  ) {

    if (

      ownsSession &&

      session.inTransaction()

    ) {

      await session.abortTransaction();

    }


    throw error;

  } finally {

    if (

      ownsSession

    ) {

      await session.endSession();

    }

  }

};


// ========================================
// ACTIVATE CONTRIBUTION PLAN
// ========================================

export const activateContributionPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  session:

    existingSession = null

}) => {

  const ownsSession =

    !existingSession;


  const session =

    existingSession ||

    await mongoose.startSession();


  try {

    if (

      ownsSession

    ) {

      session.startTransaction();

    }


    const plan =

      await loadPlan({

        plan_id,

        owner_type,

        owner_id,

        session

      });


    ensurePlanCanBeActivated(

      plan

    );


    if (

      plan.start_date &&

      new Date(

        plan.start_date

      ) > new Date()

    ) {

      throw new AppError(

        'Contribution plan cannot be activated before its start date',

        400

      );

    }


    plan.status =

      'active';


    await plan.save({

      session

    });


    if (

      ownsSession

    ) {

      await session.commitTransaction();

    }


    return plan;

  } catch (

    error

  ) {

    if (

      ownsSession &&

      session.inTransaction()

    ) {

      await session.abortTransaction();

    }


    throw error;

  } finally {

    if (

      ownsSession

    ) {

      await session.endSession();

    }

  }

};


// ========================================
// PAUSE CONTRIBUTION PLAN
// ========================================

export const pauseContributionPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  session:

    existingSession = null

}) => {

  const ownsSession =

    !existingSession;


  const session =

    existingSession ||

    await mongoose.startSession();


  try {

    if (

      ownsSession

    ) {

      session.startTransaction();

    }


    const plan =

      await loadPlan({

        plan_id,

        owner_type,

        owner_id,

        session

      });


    if (

      plan.status !==

      'active'

    ) {

      throw new AppError(

        'Only active contribution plans can be paused',

        400

      );

    }


    plan.status =

      'paused';


    await plan.save({

      session

    });


    if (

      ownsSession

    ) {

      await session.commitTransaction();

    }


    return plan;

  } catch (

    error

  ) {

    if (

      ownsSession &&

      session.inTransaction()

    ) {

      await session.abortTransaction();

    }


    throw error;

  } finally {

    if (

      ownsSession

    ) {

      await session.endSession();

    }

  }

};


// ========================================
// RESUME CONTRIBUTION PLAN
// ========================================

export const resumeContributionPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  session:

    existingSession = null

}) => {

  const ownsSession =

    !existingSession;


  const session =

    existingSession ||

    await mongoose.startSession();


  try {

    if (

      ownsSession

    ) {

      session.startTransaction();

    }


    const plan =

      await loadPlan({

        plan_id,

        owner_type,

        owner_id,

        session

      });


    if (

      plan.status !==

      'paused'

    ) {

      throw new AppError(

        'Only paused contribution plans can be resumed',

        400

      );

    }


    ensurePlanCanBeActivated(

      plan

    );


    plan.status =

      'active';


    await plan.save({

      session

    });


    if (

      ownsSession

    ) {

      await session.commitTransaction();

    }


    return plan;

  } catch (

    error

  ) {

    if (

      ownsSession &&

      session.inTransaction()

    ) {

      await session.abortTransaction();

    }


    throw error;

  } finally {

    if (

      ownsSession

    ) {

      await session.endSession();

    }

  }

};


// ========================================
// COMPLETE CONTRIBUTION PLAN
// ========================================

export const completeContributionPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  session:

    existingSession = null

}) => {

  const ownsSession =

    !existingSession;


  const session =

    existingSession ||

    await mongoose.startSession();


  try {

    if (

      ownsSession

    ) {

      session.startTransaction();

    }


    const plan =

      await loadPlan({

        plan_id,

        owner_type,

        owner_id,

        session

      });


    if (

      plan.status ===

      'cancelled'

    ) {

      throw new AppError(

        'Cancelled contribution plans cannot be completed',

        400

      );

    }


    if (

      plan.status ===

      'completed'

    ) {

      throw new AppError(

        'Contribution plan is already completed',

        400

      );

    }


    plan.status =

      'completed';


    await plan.save({

      session

    });


    if (

      ownsSession

    ) {

      await session.commitTransaction();

    }


    return plan;

  } catch (

    error

  ) {

    if (

      ownsSession &&

      session.inTransaction()

    ) {

      await session.abortTransaction();

    }


    throw error;

  } finally {

    if (

      ownsSession

    ) {

      await session.endSession();

    }

  }

};


// ========================================
// CANCEL CONTRIBUTION PLAN
// ========================================

export const cancelContributionPlan = async ({

  plan_id,

  owner_type,

  owner_id,

  session:

    existingSession = null

}) => {

  const ownsSession =

    !existingSession;


  const session =

    existingSession ||

    await mongoose.startSession();


  try {

    if (

      ownsSession

    ) {

      session.startTransaction();

    }


    const plan =

      await loadPlan({

        plan_id,

        owner_type,

        owner_id,

        session

      });


    if (

      plan.status ===

      'completed'

    ) {

      throw new AppError(

        'Completed contribution plans cannot be cancelled',

        400

      );

    }


    if (

      plan.status ===

      'cancelled'

    ) {

      throw new AppError(

        'Contribution plan is already cancelled',

        400

      );

    }


    plan.status =

      'cancelled';


    await plan.save({

      session

    });


    if (

      ownsSession

    ) {

      await session.commitTransaction();

    }


    return plan;

  } catch (

    error

  ) {

    if (

      ownsSession &&

      session.inTransaction()

    ) {

      await session.abortTransaction();

    }


    throw error;

  } finally {

    if (

      ownsSession

    ) {

      await session.endSession();

    }

  }

};


// ========================================
// GET CONTRIBUTION PLAN BY ID
// ========================================

export const getContributionPlanById = async ({

  plan_id,

  owner_type = null,

  owner_id = null,

  session = null

}) => {

  validateObjectId(

    plan_id,

    'contribution plan ID'

  );


  const query = {

    _id:

      plan_id

  };


  if (

    owner_type

  ) {

    validateOwnerType(

      owner_type

    );


    query.owner_type =

      owner_type;

  }


  if (

    owner_id

  ) {

    validateObjectId(

      owner_id,

      'owner ID'

    );


    query.owner_id =

      owner_id;

  }


  const plan =

    await ContributionPlan.findOne(

      query

    )

      .session(

        session

      );


  if (

    !plan

  ) {

    throw new AppError(

      'Contribution plan not found',

      404

    );

  }


  return plan;

};


// ========================================
// GET OWNER CONTRIBUTION PLANS
// ========================================

export const getOwnerContributionPlans = async ({

  owner_type,

  owner_id,

  status = null,

  session = null

}) => {

  validateOwnerType(

    owner_type

  );


  validateObjectId(

    owner_id,

    'owner ID'

  );


  const query = {

    owner_type,

    owner_id

  };


  if (

    status

  ) {

    validatePlanStatus(

      status

    );


    query.status =

      status;

  }


  return ContributionPlan.find(

    query

  )

    .sort({

      createdAt:

        -1

    })

    .session(

      session

    );

};


// ========================================
// GET CONTRIBUTION PLANS
// ========================================

export const getContributionPlans = async ({

  owner_type = null,

  owner_id = null,

  status = null,

  contribution_type = null,

  frequency = null,

  session = null

}) => {

  const query = {};


  if (

    owner_type

  ) {

    validateOwnerType(

      owner_type

    );


    query.owner_type =

      owner_type;

  }


  if (

    owner_id

  ) {

    validateObjectId(

      owner_id,

      'owner ID'

    );


    query.owner_id =

      owner_id;

  }


  if (

    status

  ) {

    validatePlanStatus(

      status

    );


    query.status =

      status;

  }


  if (

    contribution_type

  ) {

    validateContributionType(

      contribution_type

    );


    query.contribution_type =

      contribution_type;

  }


  if (

    frequency

  ) {

    validateFrequency(

      frequency

    );


    query.frequency =

      frequency;

  }


  return ContributionPlan.find(

    query

  )

    .sort({

      createdAt:

        -1

    })

    .session(

      session

    );

};


// ========================================
// GET PARTICIPANT-COMPATIBLE PLANS
// ========================================

export const getParticipantCompatiblePlans = async ({

  participant_type,

  owner_id,

  status = null,

  session = null

}) => {

  validateParticipantType(

    participant_type

  );


  validateObjectId(

    owner_id,

    'owner ID'

  );


  const owner_type =

    participant_type ===

    'ChamaMembership'

      ? 'Chama'

      : 'ContributionGroup';


  return getOwnerContributionPlans({

    owner_type,

    owner_id,

    status,

    session

  });

};


// ========================================
// GET PLAN OBLIGATIONS
// ========================================

export const getContributionPlanObligations = async ({

  plan_id,

  owner_type = null,

  owner_id = null,

  status = null,

  participant_type = null,

  participant_id = null,

  session = null

}) => {

  const plan =

    await getContributionPlanById({

      plan_id,

      owner_type,

      owner_id,

      session

    });


  const query = {

    plan_id:

      plan._id

  };


  if (

    status

  ) {

    query.status =

      status;

  }


  if (

    participant_type

  ) {

    validateOwnerParticipantCompatibility({

      owner_type:

        plan.owner_type,

      participant_type

    });


    query.participant_type =

      participant_type;

  }


  if (

    participant_id

  ) {

    validateObjectId(

      participant_id,

      'participant ID'

    );


    query.participant_id =

      participant_id;

  }


  return ContributionObligation.find(

    query

  )

    .sort({

      due_date:

        1,

      createdAt:

        1

    })

    .session(

      session

    );

};


// ========================================
// GET PLAN PAYMENTS
// ========================================

export const getContributionPlanPayments = async ({

  plan_id,

  owner_type,

  owner_id,

  status = null,

  participant_type = null,

  participant_id = null,

  session = null

}) => {

  const plan =

    await getContributionPlanById({

      plan_id,

      owner_type,

      owner_id,

      session

    });


  if (

    participant_type

  ) {

    validateOwnerParticipantCompatibility({

      owner_type:

        plan.owner_type,

      participant_type

    });

  }


  const payments =

    await getOwnerContributionPayments({

      owner_type:

        plan.owner_type,

      owner_id:

        plan.owner_id,

      status,

      participant_type,

      participant_id,

      session

    });


  return payments.filter(

    payment =>

      String(

        payment.plan_id

      ) ===

      String(

        plan._id

      )

  );

};


// ========================================
// CALCULATE PLAN PAYMENT TOTAL
// ========================================

export const calculateContributionPlanPaymentTotal = async ({

  plan_id,

  owner_type = null,

  owner_id = null,

  session = null

}) => {

  const plan =

    await getContributionPlanById({

      plan_id,

      owner_type,

      owner_id,

      session

    });


  const payments =

    await ContributionPayment.find({

      plan_id:

        plan._id,

      status:

        'completed'

    })

      .select(

        'amount currency'

      )

      .session(

        session

      );


  let total =

    toDecimal(

      '0'

    );


  let currency =

    null;


  for (

    const payment

    of payments

  ) {

    const paymentCurrency =

      String(

        payment.currency

      )

        .trim()

        .toUpperCase();


    if (

      currency &&

      currency !==

      paymentCurrency

    ) {

      throw new AppError(

        'Contribution plan payments contain multiple currencies',

        500

      );

    }


    currency =

      paymentCurrency;


    total =

      addMoney(

        total,

        toDecimal(

          payment.amount?.toString?.()

            ?? payment.amount

        )

      );

  }


  return {

    plan_id:

      plan._id,

    total,

    currency,

    paymentCount:

      payments.length

  };

};


// ========================================
// CALCULATE PLAN OBLIGATION TOTAL
// ========================================

export const calculateContributionPlanObligationTotal = async ({

  plan_id,

  owner_type = null,

  owner_id = null,

  session = null

}) => {

  const plan =

    await getContributionPlanById({

      plan_id,

      owner_type,

      owner_id,

      session

    });


  const obligations =

    await ContributionObligation.find({

      plan_id:

        plan._id

    })

      .select(

        'expected_amount paid_amount currency status'

      )

      .session(

        session

      );


  let expectedTotal =

    toDecimal(

      '0'

    );


  let paidTotal =

    toDecimal(

      '0'

    );


  let currency =

    null;


  const statusCounts = {};


  for (

    const obligation

    of obligations

  ) {

    const obligationCurrency =

      String(

        obligation.currency

      )

        .trim()

        .toUpperCase();


    if (

      currency &&

      currency !==

      obligationCurrency

    ) {

      throw new AppError(

        'Contribution plan obligations contain multiple currencies',

        500

      );

    }


    currency =

      obligationCurrency;


    expectedTotal =

      addMoney(

        expectedTotal,

        toDecimal(

          obligation.expected_amount?.toString?.()

            ?? obligation.expected_amount

        )

      );


    paidTotal =

      addMoney(

        paidTotal,

        toDecimal(

          obligation.paid_amount?.toString?.()

            ?? obligation.paid_amount

        )

      );


    statusCounts[

      obligation.status

    ] =

      (

        statusCounts[

          obligation.status

        ] ||

        0

      ) + 1;

  }


  return {

    plan_id:

      plan._id,

    expectedTotal,

    paidTotal,

    outstandingTotal:

      expectedTotal.minus(

        paidTotal

      ),

    obligationCount:

      obligations.length,

    statusCounts,

    currency

  };

};


// ========================================
// GET PLAN FINANCIAL SUMMARY
// ========================================

export const getContributionPlanFinancialSummary = async ({

  plan_id,

  owner_type = null,

  owner_id = null,

  session = null

}) => {

  const plan =

    await getContributionPlanById({

      plan_id,

      owner_type,

      owner_id,

      session

    });


  const obligationSummary =

    await calculateContributionPlanObligationTotal({

      plan_id:

        plan._id,

      session

    });


  const paymentSummary =

    await calculateContributionPlanPaymentTotal({

      plan_id:

        plan._id,

      session

    });


  if (

    obligationSummary.currency &&

    paymentSummary.currency &&

    obligationSummary.currency !==

    paymentSummary.currency

  ) {

    throw new AppError(

      'Plan obligations and payments contain inconsistent currencies',

      500

    );

  }


  return {

    plan,

    currency:

      obligationSummary.currency ||

      paymentSummary.currency ||

      null,

    expectedTotal:

      obligationSummary.expectedTotal,

    paidAmountFromObligations:

      obligationSummary.paidTotal,

    outstandingTotal:

      obligationSummary.outstandingTotal,

    completedPaymentTotal:

      paymentSummary.total,

    paymentCount:

      paymentSummary.paymentCount,

    obligationCount:

      obligationSummary.obligationCount,

    obligationStatusCounts:

      obligationSummary.statusCounts,

    paymentBalanceMatches:

      isMoneyEqual(

        obligationSummary.paidTotal,

        paymentSummary.total

      )

  };

};


// ========================================
// RECONCILE PLAN PAYMENTS
// ========================================

export const reconcileContributionPlanPayments = async ({

  plan_id,

  owner_type = null,

  owner_id = null,

  session = null

}) => {

  const plan =

    await getContributionPlanById({

      plan_id,

      owner_type,

      owner_id,

      session

    });


  const obligations =

    await ContributionObligation.find({

      plan_id:

        plan._id

    })

      .select(

        '_id'

      )

      .session(

        session

      );


  const results = [];


  for (

    const obligation

    of obligations

  ) {

    const reconciliation =

      await reconcileContributionObligationPayments({

        obligation_id:

          obligation._id,

        session

      });


    results.push(

      reconciliation

    );

  }


  const balancedCount =

    results.filter(

      result =>

        result.isBalanced

    ).length;


  const unbalancedCount =

    results.length -

    balancedCount;


  return {

    plan_id:

      plan._id,

    obligationCount:

      results.length,

    balancedCount,

    unbalancedCount,

    isBalanced:

      unbalancedCount ===

      0,

    obligations:

      results

  };

};


// ========================================
// GET PLAN PAYMENT SUMMARY BY PARTICIPANT
// ========================================

export const getContributionPlanParticipantSummary = async ({

  plan_id,

  owner_type,

  owner_id,

  participant_type,

  participant_id = null,

  session = null

}) => {

  const plan =

    await getContributionPlanById({

      plan_id,

      owner_type,

      owner_id,

      session

    });


  validateOwnerParticipantCompatibility({

    owner_type:

      plan.owner_type,

    participant_type

  });


  const query = {

    plan_id:

      plan._id,

    participant_type

  };


  if (

    participant_id

  ) {

    validateObjectId(

      participant_id,

      'participant ID'

    );


    query.participant_id =

      participant_id;

  }


  const obligations =

    await ContributionObligation.find(

      query

    )

      .select(

        'participant_id expected_amount paid_amount currency status'

      )

      .session(

        session

      );


  const summary = new Map();


  for (

    const obligation

    of obligations

  ) {

    const key =

      String(

        obligation.participant_id

      );


    if (

      !summary.has(

        key

      )

    ) {

      summary.set(

        key,

        {

          participant_id:

            obligation.participant_id,

          expectedAmount:

            toDecimal(

              '0'

            ),

          paidAmount:

            toDecimal(

              '0'

            ),

          outstandingAmount:

            toDecimal(

              '0'

            ),

          obligationCount:

            0,

          statuses: {}

        }

      );

    }


    const participantSummary =

      summary.get(

        key

      );


    participantSummary.expectedAmount =

      addMoney(

        participantSummary.expectedAmount,

        toDecimal(

          obligation.expected_amount?.toString?.()

            ?? obligation.expected_amount

        )

      );


    participantSummary.paidAmount =

      addMoney(

        participantSummary.paidAmount,

        toDecimal(

          obligation.paid_amount?.toString?.()

            ?? obligation.paid_amount

        )

      );


    participantSummary.outstandingAmount =

      participantSummary.expectedAmount.minus(

        participantSummary.paidAmount

      );


    participantSummary.obligationCount +=

      1;


    participantSummary.statuses[

      obligation.status

    ] =

      (

        participantSummary.statuses[

          obligation.status

        ] ||

        0

      ) + 1;

  }


  return {

    plan_id:

      plan._id,

    owner_type:

      plan.owner_type,

    owner_id:

      plan.owner_id,

    participant_type,

    participants:

      Array.from(

        summary.values()

      )

  };

};


// ========================================
// EXPORT VALIDATION HELPERS
// ========================================

export {

  validateObjectId,

  validateOwnerType,

  validateParticipantType,

  validateOwnerParticipantCompatibility,

  validateContributionType,

  validateFrequency,

  validatePlanStatus,

  validatePlanDates,

  validateMoneyValue,

  validateContributionRules,

  loadPlan,

  ensurePlanCanBeUpdated,

  ensurePlanCanBeActivated

};