// ========================================
// CONTRIBUTION PAYMENT ROUTES
// ========================================
//
// Production responsibilities:
//
// 1. Define contribution payment endpoints
// 2. Authenticate every protected request
// 3. Delegate HTTP requests to controllers
// 4. Keep business logic out of routes
//
// Authentication:
//
// protect
//   │
//   ├── Validates JWT
//   ├── Resolves User
//   ├── Checks account status
//   └── Attaches req.user
//
// Authorization:
//
// Resource-level authorization is enforced
// by the contribution payment service layer.
//
// This is necessary because:
//
// - User.role is NOT the authoritative
//   Chama-specific role
//
// - ChamaMembership contains the user's
//   Chama-level role
//
// - ContributionGroupMember contains
//   contribution-group membership context
//
// Therefore:
//
// req.user
//    │
//    ▼
// Resource membership
//    │
//    ├── ChamaMembership
//    │
//    └── ContributionGroupMember
//           │
//           ▼
//     Resource-level role
//
// Business logic:
//
// contributionPayment.service.js
//
// HTTP/controller logic:
//
// contributionPayment.controller.js
//
// Authentication:
//
// ../../middleware/auth.middleware.js
//
// Data validation:
//
// Service-level validation
// +
// Optional request validation middleware
//
// Financial integrity:
//
// contributionPayment.service.js
//
// ========================================


import express from 'express';


// ========================================
// CONTROLLERS
// ========================================

import {

  createContributionPayment,

  getContributionPayment,

  getObligationContributionPayments,

  getOwnerContributionPaymentsController,

  getParticipantContributionPaymentsController,

  getContributionPaymentByExternalReferenceController,

  verifyContributionPaymentController,

  reverseContributionPaymentController,

  calculateObligationPaymentTotalController,

  reconcileContributionObligationPaymentsController

} from './contributionPayment.controller.js';


// ========================================
// AUTHENTICATION
// ========================================
//
// Actual project authentication middleware:
//
// src/middleware/auth.middleware.js
//
// protect:
//
// 1. Reads Bearer token
// 2. Verifies JWT
// 3. Loads User
// 4. Checks account status
// 5. Attaches req.user
//
// Every contribution payment endpoint
// requires authentication.
//
// ========================================

import {
  protect
} from '../../middleware/auth.middleware.js';


// ========================================
// ROUTER
// ========================================

const router =
  express.Router();


// ========================================
// CREATE CONTRIBUTION PAYMENT
// ========================================
//
// POST /contribution-payments
//
// Creates:
//
// ContributionPayment
//        │
//        ├── FinancialTransaction
//        │
//        └── ContributionObligation balance update
//
// Authentication:
//
// REQUIRED
//
// Resource authorization:
//
// MUST be enforced by the service layer.
//
// The service must verify that the
// authenticated user has authority to
// record a payment against the requested:
//
// - Chama
// - ContributionGroup
// - ContributionObligation
//
// Audit identities:
//
// MUST come from req.user.
//
// Client-supplied values such as:
//
// created_by
// recorded_by
// posted_by
//
// MUST NOT be trusted.
//
// ========================================

router.post(

  '/',

  protect,

  createContributionPayment

);


// ========================================
// GET PAYMENT BY EXTERNAL REFERENCE
// ========================================
//
// GET /contribution-payments/external/:externalReference
//
// Optional:
//
// ?owner_type=Chama
// ?owner_id=<id>
//
// IMPORTANT:
//
// This route MUST appear before:
//
// /:paymentId
//
// Otherwise:
//
// "external"
//
// could be interpreted as a paymentId.
//
// ========================================

router.get(

  '/external/:externalReference',

  protect,

  getContributionPaymentByExternalReferenceController

);


// ========================================
// GET PAYMENTS FOR OBLIGATION
// ========================================
//
// GET /contribution-payments/obligation/:obligationId
//
// Optional:
//
// ?status=completed
//
// Resource authorization:
//
// The service layer must verify that
// the authenticated user can access
// the obligation's owning resource.
//
// ========================================

router.get(

  '/obligation/:obligationId',

  protect,

  getObligationContributionPayments

);


// ========================================
// GET OBLIGATION PAYMENT TOTAL
// ========================================
//
// GET /contribution-payments/obligation/:obligationId/total
//
// Returns:
//
// - total completed payments
// - payment currency
// - completed payment count
//
// READ-ONLY.
//
// Resource authorization:
//
// Enforced by service layer.
//
// ========================================

router.get(

  '/obligation/:obligationId/total',

  protect,

  calculateObligationPaymentTotalController

);


// ========================================
// RECONCILE OBLIGATION PAYMENTS
// ========================================
//
// GET /contribution-payments/obligation/:obligationId/reconcile
//
// Compares:
//
// ContributionObligation.paid_amount
//
// against:
//
// SUM(ContributionPayment.amount)
//
// where:
//
// status = completed
//
// Recommended access:
//
// - Treasurer
// - Auditor
// - Authorized financial administrator
//
// IMPORTANT:
//
// Authorization must be resource-aware.
//
// A global User.role check is insufficient
// because Chama roles are stored in
// ChamaMembership.
//
// READ-ONLY.
//
// This endpoint MUST NEVER modify
// financial records.
//
// ========================================

router.get(

  '/obligation/:obligationId/reconcile',

  protect,

  reconcileContributionObligationPaymentsController

);


// ========================================
// GET OWNER CONTRIBUTION PAYMENTS
// ========================================
//
// GET /contribution-payments/owner/:ownerType/:ownerId
//
// Supported owners:
//
// - Chama
// - ContributionGroup
//
// Optional:
//
// ?status=completed
//
// ?participant_type=ChamaMembership
//
// ?participant_id=<id>
//
// Resource authorization:
//
// Enforced by service layer.
//
// ========================================

router.get(

  '/owner/:ownerType/:ownerId',

  protect,

  getOwnerContributionPaymentsController

);


// ========================================
// GET PARTICIPANT CONTRIBUTION PAYMENTS
// ========================================
//
// GET /contribution-payments/participant/:participantType/:participantId
//
// Supported participants:
//
// - ChamaMembership
// - ContributionGroupMember
//
// Optional:
//
// ?status=completed
//
// Resource authorization:
//
// Enforced by service layer.
//
// ========================================

router.get(

  '/participant/:participantType/:participantId',

  protect,

  getParticipantContributionPaymentsController

);


// ========================================
// VERIFY CONTRIBUTION PAYMENT
// ========================================
//
// PATCH /contribution-payments/:paymentId/verify
//
// Verification:
//
// - Does not create another payment
// - Does not create another transaction
// - Does not increase paid_amount
// - Records verified_by
// - Records verified_at
//
// Recommended roles:
//
// - Treasurer
// - Auditor
// - Authorized financial administrator
//
// IMPORTANT:
//
// Authorization must be resolved using
// the payment's actual resource context.
//
// Example:
//
// Payment
//    │
//    ▼
// ContributionObligation
//    │
//    ▼
// ContributionGroup / Chama
//    │
//    ▼
// ChamaMembership
//    │
//    ▼
// Authenticated User
//
// The service layer must verify that the
// authenticated user has permission to
// verify this specific payment.
//
// ========================================

router.patch(

  '/:paymentId/verify',

  protect,

  verifyContributionPaymentController

);


// ========================================
// REVERSE CONTRIBUTION PAYMENT
// ========================================
//
// POST /contribution-payments/:paymentId/reverse
//
// Creates a compensating accounting
// transaction.
//
// Original transaction:
//
// DR Payment Account
// CR Contribution Receivable
//
// Reversal:
//
// DR Contribution Receivable
// CR Payment Account
//
// Original payment records remain immutable.
//
// Recommended role:
//
// - Treasurer
// - Authorized financial administrator
//
// IMPORTANT:
//
// The service layer MUST:
//
// 1. Verify resource access
// 2. Verify reversal authority
// 3. Prevent duplicate reversal
// 4. Preserve original payment
// 5. Create compensating transaction
// 6. Restore obligation balance
// 7. Record authenticated actor
// 8. Record reversal reason
//
// ========================================

router.post(

  '/:paymentId/reverse',

  protect,

  reverseContributionPaymentController

);


// ========================================
// GET CONTRIBUTION PAYMENT BY ID
// ========================================
//
// GET /contribution-payments/:paymentId
//
// IMPORTANT:
//
// This generic parameter route MUST be
// declared LAST.
//
// Otherwise it may capture:
//
// /external/...
// /obligation/...
// /owner/...
// /participant/...
//
// as paymentId values.
//
// ========================================

router.get(

  '/:paymentId',

  protect,

  getContributionPayment

);


// ========================================
// EXPORT ROUTER
// ========================================

export default router;