
// ========================================
// CONTRIBUTION PAYMENT CONTROLLER
// ========================================
//
// Responsibilities:
//
// 1. Receive HTTP requests
// 2. Extract route parameters, query params, and body
// 3. Resolve authenticated user
// 4. Validate basic request requirements
// 5. Call contribution payment services
// 6. Return standardized HTTP responses
// 7. Pass errors to Express error middleware
//
// Business logic belongs in:
//
// contributionPayment.service.js
//
// Routes belong in:
//
// contributionPayment.routes.js
//
// IMPORTANT:
//
// Audit identities are ALWAYS resolved from
// the authenticated user.
//
// Clients MUST NOT be allowed to impersonate:
//
// - created_by
// - recorded_by
// - posted_by
// - verified_by
// - reversed_by
//
// Financial mutations:
//
// CREATE PAYMENT
// VERIFY PAYMENT
// REVERSE PAYMENT
//
// must always have an authenticated actor.
//
// ========================================

import {

  postContributionPayment,

  verifyContributionPayment,

  reverseContributionPayment,

  getContributionPaymentById,

  getPaymentsForObligation,

  getOwnerContributionPayments,

  getParticipantContributionPayments,

  getContributionPaymentByExternalReference,

  calculateObligationPaymentTotal,

  reconcileContributionObligationPayments

} from './contributionPayment.service.js';


// ========================================
// RESPONSE HELPERS
// ========================================
//
// Keeps controller responses consistent.
//
// ========================================

const sendSuccess = (
  res,
  {
    statusCode = 200,
    message,
    data
  } = {}
) => {

  const response = {

    success:
      true

  };

  if (
    message
  ) {

    response.message =
      message;

  }

  if (
    data !== undefined
  ) {

    response.data =
      data;

  }

  return res
    .status(statusCode)
    .json(
      response
    );

};


const sendNotFound = (
  res,
  message
) => {

  return res
    .status(404)
    .json({

      success:
        false,

      message

    });

};


// ========================================
// GET AUTHENTICATED USER ID
// ========================================
//
// Supports common authentication middleware
// payload formats.
//
// Example:
//
// req.user = {
//   _id: "..."
// }
//
// or:
//
// req.user = {
//   id: "..."
// }
//
// ========================================

const getAuthenticatedUserId = (
  req
) => {

  return (

    req.user?._id ||

    req.user?.id ||

    null

  );

};


// ========================================
// REQUIRE AUTHENTICATED USER
// ========================================
//
// Every financial mutation must have
// an authenticated actor.
//
// ========================================

const requireAuthenticatedUserId = (
  req
) => {

  const userId =
    getAuthenticatedUserId(
      req
    );

  if (
    !userId
  ) {

    const error =
      new Error(
        'Authenticated user is required'
      );

    error.statusCode =
      401;

    throw error;

  }

  return userId;

};


// ========================================
// REQUIRE PARAMETER
// ========================================
//
// Basic controller-level validation.
//
// Deep validation belongs in the service
// layer and/or request validation middleware.
//
// ========================================

const requireParam = (
  value,
  name
) => {

  if (
    !value ||
    typeof value !== 'string' ||
    !value.trim()
  ) {

    const error =
      new Error(
        `${name} is required`
      );

    error.statusCode =
      400;

    throw error;

  }

  return value.trim();

};


// ========================================
// NORMALIZE OPTIONAL QUERY VALUE
// ========================================
//
// Express query values may be:
//
// string
// string[]
// undefined
//
// We only accept a single string value.
//
// ========================================

const getQueryString = (
  value
) => {

  if (
    typeof value === 'string'
  ) {

    return value.trim() || null;

  }

  return null;

};


// ========================================
// CREATE CONTRIBUTION PAYMENT
// ========================================
//
// POST /api/contribution-payments
//
// Creates:
//
// ContributionPayment
//        +
// FinancialTransaction
//        +
// Obligation balance update
//
// Audit identities are derived from the
// authenticated user.
//
// Client supplied audit fields are ignored.
//
// ========================================

export const createContributionPayment = async (
  req,
  res,
  next
) => {

  try {

    const authenticatedUserId =
      requireAuthenticatedUserId(
        req
      );

    const {

      obligation_id,

      owner_type,

      owner_id,

      participant_type,

      participant_id,

      amount,

      currency,

      payment_method,

      payment_account_id,

      external_reference,

      description,

      paid_at,

      notes

    } = req.body || {};


    const obligationId =
      requireParam(
        obligation_id,
        'obligation_id'
      );


    const result =
      await postContributionPayment({

        obligation_id:
          obligationId,

        owner_type,

        owner_id,

        participant_type,

        participant_id,

        amount,

        currency,

        payment_method,

        payment_account_id,

        external_reference,

        description,

        paid_at,

        recorded_by:
          authenticatedUserId,

        created_by:
          authenticatedUserId,

        posted_by:
          authenticatedUserId,

        notes

      });


    return sendSuccess(
      res,
      {

        statusCode:
          201,

        message:
          'Contribution payment recorded successfully',

        data:
          result

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// GET CONTRIBUTION PAYMENT BY ID
// ========================================
//
// GET /api/contribution-payments/:paymentId
//
// ========================================

export const getContributionPayment = async (
  req,
  res,
  next
) => {

  try {

    const paymentId =
      requireParam(
        req.params.paymentId,
        'paymentId'
      );


    const payment =
      await getContributionPaymentById({

        payment_id:
          paymentId

      });


    if (
      !payment
    ) {

      return sendNotFound(
        res,
        'Contribution payment not found'
      );

    }


    return sendSuccess(
      res,
      {

        data:
          payment

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// GET PAYMENTS FOR OBLIGATION
// ========================================
//
// GET /api/contribution-payments/obligation/:obligationId
//
// Optional:
//
// ?status=completed
//
// ========================================

export const getObligationContributionPayments = async (
  req,
  res,
  next
) => {

  try {

    const obligationId =
      requireParam(
        req.params.obligationId,
        'obligationId'
      );


    const status =
      getQueryString(
        req.query.status
      );


    const payments =
      await getPaymentsForObligation({

        obligation_id:
          obligationId,

        status:
          status ||
          'completed'

      });


    return sendSuccess(
      res,
      {

        data:
          payments

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// GET OWNER CONTRIBUTION PAYMENTS
// ========================================
//
// GET /api/contribution-payments/owner/:ownerType/:ownerId
//
// Optional:
//
// ?status=completed
// ?participant_type=ChamaMembership
// ?participant_id=...
//
// ========================================

export const getOwnerContributionPaymentsController = async (
  req,
  res,
  next
) => {

  try {

    const ownerType =
      requireParam(
        req.params.ownerType,
        'ownerType'
      );


    const ownerId =
      requireParam(
        req.params.ownerId,
        'ownerId'
      );


    const status =
      getQueryString(
        req.query.status
      );


    const participantType =
      getQueryString(
        req.query.participant_type
      );


    const participantId =
      getQueryString(
        req.query.participant_id
      );


    const payments =
      await getOwnerContributionPayments({

        owner_type:
          ownerType,

        owner_id:
          ownerId,

        status,

        participant_type:
          participantType,

        participant_id:
          participantId

      });


    return sendSuccess(
      res,
      {

        data:
          payments

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// GET PARTICIPANT CONTRIBUTION PAYMENTS
// ========================================
//
// GET /api/contribution-payments/participant/:participantType/:participantId
//
// Optional:
//
// ?status=completed
//
// ========================================

export const getParticipantContributionPaymentsController = async (
  req,
  res,
  next
) => {

  try {

    const participantType =
      requireParam(
        req.params.participantType,
        'participantType'
      );


    const participantId =
      requireParam(
        req.params.participantId,
        'participantId'
      );


    const status =
      getQueryString(
        req.query.status
      );


    const payments =
      await getParticipantContributionPayments({

        participant_type:
          participantType,

        participant_id:
          participantId,

        status

      });


    return sendSuccess(
      res,
      {

        data:
          payments

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// GET PAYMENT BY EXTERNAL REFERENCE
// ========================================
//
// GET /api/contribution-payments/external/:externalReference
//
// Optional:
//
// ?owner_type=Chama
// ?owner_id=...
//
// External references should be URL encoded.
//
// ========================================

export const getContributionPaymentByExternalReferenceController = async (
  req,
  res,
  next
) => {

  try {

    const externalReference =
      requireParam(
        req.params.externalReference,
        'externalReference'
      );


    const ownerType =
      getQueryString(
        req.query.owner_type
      );


    const ownerId =
      getQueryString(
        req.query.owner_id
      );


    const payment =
      await getContributionPaymentByExternalReference({

        external_reference:
          externalReference,

        owner_type:
          ownerType,

        owner_id:
          ownerId

      });


    if (
      !payment
    ) {

      return sendNotFound(
        res,
        'Contribution payment not found'
      );

    }


    return sendSuccess(
      res,
      {

        data:
          payment

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// VERIFY CONTRIBUTION PAYMENT
// ========================================
//
// PATCH /api/contribution-payments/:paymentId/verify
//
// Verification:
//
// - Does not create another payment
// - Does not create another financial transaction
// - Does not modify obligation balance
// - Records authenticated user as verifier
//
// ========================================

export const verifyContributionPaymentController = async (
  req,
  res,
  next
) => {

  try {

    const verifiedBy =
      requireAuthenticatedUserId(
        req
      );


    const paymentId =
      requireParam(
        req.params.paymentId,
        'paymentId'
      );


    const payment =
      await verifyContributionPayment({

        payment_id:
          paymentId,

        verified_by:
          verifiedBy

      });


    return sendSuccess(
      res,
      {

        message:
          'Contribution payment verified successfully',

        data:
          payment

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// REVERSE CONTRIBUTION PAYMENT
// ========================================
//
// POST /api/contribution-payments/:paymentId/reverse
//
// Reversal:
//
// Original payment
//        │
//        ├── remains immutable
//        │
//        ▼
// Reversal transaction
//
// The reversal also restores the obligation
// balance through the service layer.
//
// ========================================

export const reverseContributionPaymentController = async (
  req,
  res,
  next
) => {

  try {

    const authenticatedUserId =
      requireAuthenticatedUserId(
        req
      );


    const paymentId =
      requireParam(
        req.params.paymentId,
        'paymentId'
      );


    const {

      reversal_reason

    } = req.body || {};


    const result =
      await reverseContributionPayment({

        payment_id:
          paymentId,

        reversed_by:
          authenticatedUserId,

        reversal_reason,

        created_by:
          authenticatedUserId,

        posted_by:
          authenticatedUserId

      });


    return sendSuccess(
      res,
      {

        message:
          'Contribution payment reversed successfully',

        data:
          result

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// CALCULATE OBLIGATION PAYMENT TOTAL
// ========================================
//
// GET /api/contribution-payments/obligation/:obligationId/total
//
// Returns:
//
// - total completed payments
// - currency
// - payment count
//
// Read-only financial calculation.
//
// ========================================

export const calculateObligationPaymentTotalController = async (
  req,
  res,
  next
) => {

  try {

    const obligationId =
      requireParam(
        req.params.obligationId,
        'obligationId'
      );


    const result =
      await calculateObligationPaymentTotal({

        obligation_id:
          obligationId

      });


    return sendSuccess(
      res,
      {

        data:
          result

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};


// ========================================
// RECONCILE OBLIGATION PAYMENTS
// ========================================
//
// GET /api/contribution-payments/obligation/:obligationId/reconcile
//
// Compares:
//
// ContributionObligation.paid_amount
//
// against:
//
// SUM(ContributionPayment.amount)
//
// where:
//
// status = completed
//
// This endpoint is READ-ONLY.
//
// It must never modify financial records.
//
// ========================================

export const reconcileContributionObligationPaymentsController = async (
  req,
  res,
  next
) => {

  try {

    const obligationId =
      requireParam(
        req.params.obligationId,
        'obligationId'
      );


    const result =
      await reconcileContributionObligationPayments({

        obligation_id:
          obligationId

      });


    return sendSuccess(
      res,
      {

        data:
          result

      }
    );

  } catch (
    error
  ) {

    next(
      error
    );

  }

};

