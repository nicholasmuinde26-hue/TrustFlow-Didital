import mongoose from 'mongoose';

import ContributionPayment
  from '../../models/ContributionPayment.js';

import ContributionObligation
  from '../../models/ContributionObligation.js';

import FinancialAccount
  from '../../models/FinancialAccount.js';

import FinancialTransaction
  from '../../models/FinancialTransaction.js';

import AppError
  from '../../utils/AppError.js';

import {
  postFinancialTransaction
} from '../finance/financeTransaction.service.js';

import {
  getFinancialAccountByCode
} from '../finance/financeAccount.service.js';

import {
  toDecimal,
  addMoney,
  subtractMoney,
  isMoneyEqual,
  isMoneyPositive
} from '../../shared/decimal.js';


// ============================================================
// CONTRIBUTION PAYMENT SERVICE
// ============================================================
//
// PAYMENT LIFECYCLE
//
//                 ContributionObligation
//                         │
//                         ▼
//                createContributionPayment()
//                         │
//                         ▼
//                      pending
//                    /    |    \
//                   /     |     \
//                  ▼      ▼      ▼
//             completed failed cancelled
//                  │
//                  ▼
//               reversed
//
// COMPLETION
//
// pending
//   │
//   ├── Validate payment
//   ├── Validate obligation
//   ├── Validate financial accounts
//   ├── Post FinancialTransaction
//   ├── Atomically update obligation
//   └── Mark payment completed
//
// REVERSAL
//
// completed
//    │
//    ├── Validate original transaction
//    ├── Restore obligation balance
//    ├── Post compensating transaction
//    └── Mark payment reversed
//
// IMPORTANT
//
// A ContributionPayment is the operational payment record.
//
// A FinancialTransaction is the accounting record.
//
// A ContributionObligation represents what the member owes.
//
// These records have different responsibilities.
//
// ContributionPayment
//        │
//        ├── Payment lifecycle
//        ├── Provider information
//        ├── Payment instrument snapshot
//        └── Financial transaction reference
//
// ContributionObligation
//        │
//        ├── Expected amount
//        ├── Paid amount
//        └── Payment status
//
// FinancialTransaction
//        │
//        └── Double-entry accounting
//
// ============================================================


// ============================================================
// CONSTANTS
// ============================================================

const OWNER_TYPES = [
  'Chama',
  'ContributionGroup'
];

const PARTICIPANT_TYPES = [
  'ChamaMembership',
  'ContributionGroupMember'
];

const PAYMENT_CHANNELS = [
  'cash',
  'bank',
  'mpesa',
  'mobile_money',
  'card',
  'transfer',
  'other'
];

const PAYMENT_METHODS = [
  'cash',
  'bank',
  'mpesa',
  'mobile_money',
  'card',
  'transfer',
  'other'
];

const PAYMENT_STATUSES = [
  'pending',
  'completed',
  'failed',
  'reversed',
  'cancelled'
];

const PROVIDER_STATUSES = [
  'initiated',
  'pending',
  'success',
  'failed',
  'cancelled',
  'reversed',
  'unknown'
];

const RECONCILIATION_STATUSES = [
  'not_required',
  'pending',
  'matched',
  'unmatched',
  'exception'
];


// ============================================================
// STATUS CONSTANTS
// ============================================================

const PAYMENT_STATUS = 'completed';

const PENDING_STATUS = 'pending';

const FAILED_STATUS = 'failed';

const CANCELLED_STATUS = 'cancelled';

const REVERSED_STATUS = 'reversed';


// ============================================================
// FINANCIAL ACCOUNT CONSTANTS
// ============================================================
//
// 1300 = Contribution Receivable
//
// Payment:
//
// Debit  Cash / Bank / Mobile Money
// Credit Contribution Receivable
//
// Reversal:
//
// Debit  Contribution Receivable
// Credit Original Payment Account
//
// ============================================================

const CONTRIBUTION_RECEIVABLE_ACCOUNT_CODE =
  '1300';


// ============================================================
// TRANSACTION CONSTANTS
// ============================================================

const CONTRIBUTION_PAYMENT_TRANSACTION_TYPE =
  'contribution_payment';

const CONTRIBUTION_PAYMENT_REVERSAL_TRANSACTION_TYPE =
  'contribution_payment_reversal';


// ============================================================
// REFERENCE CONSTANTS
// ============================================================

const PAYMENT_REFERENCE_PREFIX =
  'CP';

const REVERSAL_REFERENCE_PREFIX =
  'REV';


// ============================================================
// VALIDATE OBJECT ID
// ============================================================

const validateObjectId = (
  value,
  fieldName
) => {

  if (
    !value ||
    !mongoose.Types.ObjectId.isValid(value)
  ) {

    throw new AppError(
      `Invalid ${fieldName}`,
      400
    );

  }

  return value;

};


// ============================================================
// VALIDATE OWNER TYPE
// ============================================================

const validateOwnerType = (
  owner_type
) => {

  if (
    !OWNER_TYPES.includes(owner_type)
  ) {

    throw new AppError(
      `Invalid contribution payment owner type. Supported types: ${OWNER_TYPES.join(', ')}`,
      400
    );

  }

  return owner_type;

};


// ============================================================
// VALIDATE PARTICIPANT TYPE
// ============================================================

const validateParticipantType = (
  participant_type
) => {

  if (
    !PARTICIPANT_TYPES.includes(
      participant_type
    )
  ) {

    throw new AppError(
      `Invalid contribution payment participant type. Supported types: ${PARTICIPANT_TYPES.join(', ')}`,
      400
    );

  }

  return participant_type;

};


// ============================================================
// VALIDATE OWNER / PARTICIPANT COMPATIBILITY
// ============================================================

const validateOwnerParticipantCompatibility = ({
  owner_type,
  participant_type
}) => {

  validateOwnerType(
    owner_type
  );

  validateParticipantType(
    participant_type
  );

  if (
    owner_type === 'Chama' &&
    participant_type !== 'ChamaMembership'
  ) {

    throw new AppError(
      'Chama contribution payments must use ChamaMembership participants',
      400
    );

  }

  if (
    owner_type === 'ContributionGroup' &&
    participant_type !== 'ContributionGroupMember'
  ) {

    throw new AppError(
      'ContributionGroup contribution payments must use ContributionGroupMember participants',
      400
    );

  }

  return true;

};


// ============================================================
// VALIDATE PAYMENT CHANNEL
// ============================================================

const validatePaymentChannel = (
  payment_channel
) => {

  if (
    !PAYMENT_CHANNELS.includes(
      payment_channel
    )
  ) {

    throw new AppError(
      `Invalid payment channel. Supported channels: ${PAYMENT_CHANNELS.join(', ')}`,
      400
    );

  }

  return payment_channel;

};


// ============================================================
// VALIDATE PAYMENT METHOD
// ============================================================

const validatePaymentMethod = (
  payment_method
) => {

  if (
    !PAYMENT_METHODS.includes(
      payment_method
    )
  ) {

    throw new AppError(
      `Invalid payment method. Supported methods: ${PAYMENT_METHODS.join(', ')}`,
      400
    );

  }

  return payment_method;

};


// ============================================================
// VALIDATE PAYMENT STATUS
// ============================================================

const validatePaymentStatus = (
  status
) => {

  if (
    !PAYMENT_STATUSES.includes(
      status
    )
  ) {

    throw new AppError(
      `Invalid contribution payment status. Supported statuses: ${PAYMENT_STATUSES.join(', ')}`,
      400
    );

  }

  return status;

};


// ============================================================
// VALIDATE PROVIDER STATUS
// ============================================================

const validateProviderStatus = (
  status
) => {

  if (
    status === null ||
    status === undefined
  ) {

    return null;

  }

  if (
    !PROVIDER_STATUSES.includes(
      status
    )
  ) {

    throw new AppError(
      `Invalid provider status. Supported statuses: ${PROVIDER_STATUSES.join(', ')}`,
      400
    );

  }

  return status;

};


// ============================================================
// VALIDATE RECONCILIATION STATUS
// ============================================================

const validateReconciliationStatus = (
  status
) => {

  if (
    status === null ||
    status === undefined
  ) {

    return null;

  }

  if (
    !RECONCILIATION_STATUSES.includes(
      status
    )
  ) {

    throw new AppError(
      `Invalid reconciliation status. Supported statuses: ${RECONCILIATION_STATUSES.join(', ')}`,
      400
    );

  }

  return status;

};


// ============================================================
// VALIDATE PAYMENT AMOUNT
// ============================================================

const validatePaymentAmount = (
  amount
) => {

  let paymentAmount;

  try {

    paymentAmount =
      toDecimal(
        amount
      );

  } catch {

    throw new AppError(
      'Invalid contribution payment amount',
      400
    );

  }

  if (
    !isMoneyPositive(
      paymentAmount
    )
  ) {

    throw new AppError(
      'Contribution payment amount must be greater than zero',
      400
    );

  }

  return paymentAmount;

};


// ============================================================
// VALIDATE CURRENCY
// ============================================================

const validateCurrency = (
  currency
) => {

  if (
    !currency ||
    typeof currency !== 'string'
  ) {

    throw new AppError(
      'Invalid contribution payment currency',
      400
    );

  }

  const normalizedCurrency =
    currency
      .trim()
      .toUpperCase();

  if (
    normalizedCurrency.length !== 3
  ) {

    throw new AppError(
      'Contribution payment currency must be a valid 3-letter currency code',
      400
    );

  }

  return normalizedCurrency;

};


// ============================================================
// VALIDATE EXTERNAL REFERENCE
// ============================================================

const validateExternalReference = (
  external_reference
) => {

  if (
    external_reference === null ||
    external_reference === undefined
  ) {

    return null;

  }

  if (
    typeof external_reference !== 'string'
  ) {

    throw new AppError(
      'External payment reference must be a string',
      400
    );

  }

  const normalizedReference =
    external_reference.trim();

  if (
    !normalizedReference
  ) {

    return null;

  }

  if (
    normalizedReference.length > 150
  ) {

    throw new AppError(
      'External payment reference cannot exceed 150 characters',
      400
    );

  }

  return normalizedReference;

};


// ============================================================
// VALIDATE PROVIDER
// ============================================================

const validateProvider = (
  provider
) => {

  if (
    provider === null ||
    provider === undefined
  ) {

    return null;

  }

  if (
    typeof provider !== 'string'
  ) {

    throw new AppError(
      'Payment provider must be a string',
      400
    );

  }

  const normalizedProvider =
    provider.trim();

  if (
    !normalizedProvider
  ) {

    return null;

  }

  if (
    normalizedProvider.length > 100
  ) {

    throw new AppError(
      'Payment provider cannot exceed 100 characters',
      400
    );

  }

  return normalizedProvider;

};


// ============================================================
// VALIDATE PROVIDER TRANSACTION ID
// ============================================================

const validateProviderTransactionId = (
  provider_transaction_id
) => {

  if (
    provider_transaction_id === null ||
    provider_transaction_id === undefined
  ) {

    return null;

  }

  if (
    typeof provider_transaction_id !== 'string'
  ) {

    throw new AppError(
      'Provider transaction ID must be a string',
      400
    );

  }

  const normalizedId =
    provider_transaction_id.trim();

  if (
    !normalizedId
  ) {

    return null;

  }

  if (
    normalizedId.length > 150
  ) {

    throw new AppError(
      'Provider transaction ID cannot exceed 150 characters',
      400
    );

  }

  return normalizedId;

};


// ============================================================
// VALIDATE IDEMPOTENCY KEY
// ============================================================

const validateIdempotencyKey = (
  idempotency_key
) => {

  if (
    idempotency_key === null ||
    idempotency_key === undefined
  ) {

    return null;

  }

  if (
    typeof idempotency_key !== 'string'
  ) {

    throw new AppError(
      'Idempotency key must be a string',
      400
    );

  }

  const normalizedKey =
    idempotency_key.trim();

  if (
    !normalizedKey
  ) {

    return null;

  }

  if (
    normalizedKey.length > 150
  ) {

    throw new AppError(
      'Idempotency key cannot exceed 150 characters',
      400
    );

  }

  return normalizedKey;

};


// ============================================================
// VALIDATE PAYMENT INSTRUMENT SNAPSHOT
// ============================================================
//
// Historical snapshot only.
//
// NEVER store:
//
// - Full card PAN
// - CVV
// - CVC
// - PIN
// - Password
//
// ============================================================

const validatePaymentInstrumentSnapshot = (
  snapshot
) => {

  if (
    snapshot === null ||
    snapshot === undefined
  ) {

    return null;

  }

  if (
    typeof snapshot !== 'object' ||
    Array.isArray(snapshot)
  ) {

    throw new AppError(
      'Payment instrument snapshot must be an object',
      400
    );

  }

  const sanitizedSnapshot = {
    ...snapshot
  };

  delete sanitizedSnapshot.card_number;

  delete sanitizedSnapshot.pan;

  delete sanitizedSnapshot.cvv;

  delete sanitizedSnapshot.cvc;

  delete sanitizedSnapshot.pin;

  delete sanitizedSnapshot.password;


  if (
    sanitizedSnapshot.phone_number
  ) {

    if (
      typeof sanitizedSnapshot.phone_number !==
      'string'
    ) {

      throw new AppError(
        'Payment instrument phone number must be a string',
        400
      );

    }

    sanitizedSnapshot.phone_number =
      sanitizedSnapshot.phone_number.trim();

  }


  if (
    sanitizedSnapshot.account_number
  ) {

    if (
      typeof sanitizedSnapshot.account_number !==
      'string'
    ) {

      throw new AppError(
        'Payment instrument account number must be a string',
        400
      );

    }

    const accountNumber =
      sanitizedSnapshot.account_number
        .trim();

    sanitizedSnapshot.account_last4 =
      accountNumber.slice(-4);

    delete sanitizedSnapshot.account_number;

  }


  if (
    sanitizedSnapshot.last4
  ) {

    sanitizedSnapshot.last4 =
      String(
        sanitizedSnapshot.last4
      ).slice(-4);

  }


  return sanitizedSnapshot;

};


// ============================================================
// VALIDATE REVERSAL REASON
// ============================================================

const validateReversalReason = (
  reversal_reason
) => {

  if (
    !reversal_reason ||
    typeof reversal_reason !== 'string'
  ) {

    throw new AppError(
      'A reversal reason is required',
      400
    );

  }

  const normalizedReason =
    reversal_reason.trim();

  if (
    !normalizedReason
  ) {

    throw new AppError(
      'A reversal reason is required',
      400
    );

  }

  if (
    normalizedReason.length > 500
  ) {

    throw new AppError(
      'Reversal reason cannot exceed 500 characters',
      400
    );

  }

  return normalizedReason;

};


// ============================================================
// GENERATE PAYMENT REFERENCE
// ============================================================

const generatePaymentReference = () => {

  const datePart =
    new Date()
      .toISOString()
      .slice(0, 10)
      .replace(/-/g, '');

  const randomPart =
    new mongoose.Types.ObjectId()
      .toHexString()
      .slice(-8)
      .toUpperCase();

  return `${PAYMENT_REFERENCE_PREFIX}-${datePart}-${randomPart}`;

};


// ============================================================
// GENERATE REVERSAL REFERENCE
// ============================================================

const generateReversalReference = (
  paymentReference
) => {

  return `${REVERSAL_REFERENCE_PREFIX}-${paymentReference}`;

};


// ============================================================
// LOAD CONTRIBUTION OBLIGATION
// ============================================================

const loadContributionObligation = async ({
  obligation_id,
  owner_type,
  owner_id,
  participant_type,
  participant_id,
  session
}) => {

  validateObjectId(
    obligation_id,
    'contribution obligation ID'
  );

  validateObjectId(
    owner_id,
    'owner ID'
  );

  validateObjectId(
    participant_id,
    'participant ID'
  );

  validateOwnerParticipantCompatibility({
    owner_type,
    participant_type
  });

  const obligation =
    await ContributionObligation
      .findOne({

        _id:
          obligation_id,

        owner_type,

        owner_id,

        participant_type,

        participant_id

      })
      .session(session);

  if (
    !obligation
  ) {

    throw new AppError(
      'Contribution obligation not found or does not belong to the specified owner and participant',
      404
    );

  }

  return obligation;

};


// ============================================================
// VALIDATE OBLIGATION STATUS
// ============================================================

const validateObligationStatus = (
  obligation
) => {

  if (
    obligation.status ===
    CANCELLED_STATUS
  ) {

    throw new AppError(
      'Cannot make a payment toward a cancelled contribution obligation',
      400
    );

  }

  if (
    obligation.status ===
    'waived'
  ) {

    throw new AppError(
      'Cannot make a payment toward a waived contribution obligation',
      400
    );

  }

  if (
    obligation.status ===
    'paid'
  ) {

    throw new AppError(
      'Contribution obligation has already been fully paid',
      400
    );

  }

};


// ============================================================
// CALCULATE REMAINING AMOUNT
// ============================================================

const calculateRemainingAmount = (
  obligation
) => {

  const expectedAmount =
    toDecimal(
      obligation.expected_amount
    );

  const paidAmount =
    toDecimal(
      obligation.paid_amount
    );

  if (
    expectedAmount.isNegative()
  ) {

    throw new AppError(
      'Contribution obligation has an invalid negative expected amount',
      500
    );

  }

  if (
    paidAmount.isNegative()
  ) {

    throw new AppError(
      'Contribution obligation has an invalid negative paid amount',
      500
    );

  }

  const remainingAmount =
    subtractMoney(
      expectedAmount,
      paidAmount
    );

  if (
    remainingAmount.isNegative()
  ) {

    throw new AppError(
      'Contribution obligation has an invalid paid amount exceeding expected amount',
      500
    );

  }

  return {

    expectedAmount,

    paidAmount,

    remainingAmount

  };

};


// ============================================================
// VALIDATE NO OVERPAYMENT
// ============================================================

const validateNoOverpayment = ({
  paymentAmount,
  remainingAmount
}) => {

  if (
    paymentAmount.greaterThan(
      remainingAmount
    )
  ) {

    throw new AppError(
      `Payment exceeds the remaining contribution obligation. Remaining amount is ${remainingAmount.toFixed()}`,
      400
    );

  }

};


// ============================================================
// DETERMINE NEW PAID AMOUNT
// ============================================================

const determineNewPaidAmount = ({
  paidAmount,
  paymentAmount,
  expectedAmount
}) => {

  const newPaidAmount =
    addMoney(
      paidAmount,
      paymentAmount
    );

  if (
    newPaidAmount.greaterThan(
      expectedAmount
    )
  ) {

    throw new AppError(
      'New paid amount cannot exceed contribution obligation expected amount',
      400
    );

  }

  return newPaidAmount;

};


// ============================================================
// VALIDATE FINANCIAL ACCOUNT
// ============================================================

const validateFinancialAccount = async ({
  accountId,
  ownerType,
  ownerId,
  currency,
  accountLabel,
  session
}) => {

  validateObjectId(
    accountId,
    `${accountLabel} financial account ID`
  );

  validateOwnerType(
    ownerType
  );

  validateObjectId(
    ownerId,
    `${accountLabel} owner ID`
  );

  const account =
    await FinancialAccount
      .findOne({

        _id:
          accountId,

        owner_type:
          ownerType,

        owner_id:
          ownerId,

        status:
          'active'

      })
      .session(session);

  if (
    !account
  ) {

    throw new AppError(
      `${accountLabel} financial account is invalid, inactive, or does not belong to this owner`,
      400
    );

  }

  if (
    account.currency !==
    currency
  ) {

    throw new AppError(
      `${accountLabel} financial account currency does not match contribution obligation currency`,
      400
    );

  }

  return account;

};


// ============================================================
// GET CONTRIBUTION RECEIVABLE ACCOUNT
// ============================================================

const getContributionReceivableAccount = async ({
  owner_type,
  owner_id,
  currency,
  session
}) => {

  validateOwnerType(
    owner_type
  );

  validateObjectId(
    owner_id,
    'owner ID'
  );

  const account =
    await getFinancialAccountByCode({

      owner_type,

      owner_id,

      account_code:
        CONTRIBUTION_RECEIVABLE_ACCOUNT_CODE,

      session

    });

  if (
    !account
  ) {

    throw new AppError(
      'Contribution receivable financial account was not found',
      500
    );

  }

  if (
    account.status !==
    'active'
  ) {

    throw new AppError(
      'Contribution receivable financial account is not active',
      500
    );

  }

  if (
    account.currency !==
    currency
  ) {

    throw new AppError(
      'Contribution receivable account currency does not match contribution obligation currency',
      400
    );

  }

  return account;

};


// ============================================================
// CHECK DUPLICATE EXTERNAL REFERENCE
// ============================================================

const checkDuplicateExternalReference = async ({
  external_reference,
  owner_type,
  owner_id,
  session,
  excludePaymentId = null
}) => {

  if (
    !external_reference
  ) {

    return null;

  }

  const query = {

    external_reference,

    owner_type,

    owner_id

  };

  if (
    excludePaymentId
  ) {

    query._id = {

      $ne:
        excludePaymentId

    };

  }

  const existingPayment =
    await ContributionPayment
      .findOne(
        query
      )
      .session(session);

  if (
    existingPayment
  ) {

    throw new AppError(
      'A contribution payment with this external reference already exists for this owner',
      409
    );

  }

  return null;

};


// ============================================================
// CHECK DUPLICATE PROVIDER TRANSACTION
// ============================================================

const checkDuplicateProviderTransaction = async ({
  provider,
  provider_transaction_id,
  session,
  excludePaymentId = null
}) => {

  if (
    !provider ||
    !provider_transaction_id
  ) {

    return null;

  }

  const query = {

    provider,

    provider_transaction_id

  };

  if (
    excludePaymentId
  ) {

    query._id = {

      $ne:
        excludePaymentId

    };

  }

  const existingPayment =
    await ContributionPayment
      .findOne(
        query
      )
      .session(session);

  if (
    existingPayment
  ) {

    throw new AppError(
      'A contribution payment with this provider transaction ID already exists',
      409
    );

  }

  return null;

};


// ============================================================
// FIND EXISTING PAYMENT BY IDEMPOTENCY KEY
// ============================================================

const findExistingPaymentByIdempotencyKey = async ({
  idempotency_key,
  owner_type,
  owner_id,
  session
}) => {

  if (
    !idempotency_key
  ) {

    return null;

  }

  return ContributionPayment
    .findOne({

      idempotency_key,

      owner_type,

      owner_id

    })
    .session(session);

};


// ============================================================
// CREATE PAYMENT INSTRUMENT SNAPSHOT
// ============================================================

const createPaymentInstrumentSnapshot = ({
  payment_channel,
  payment_instrument_id,
  payment_instrument_snapshot
}) => {

  const snapshot =
    validatePaymentInstrumentSnapshot(
      payment_instrument_snapshot
    );

  return {

    payment_channel,

    payment_instrument_id:
      payment_instrument_id ||
      null,

    payment_instrument_snapshot:
      snapshot

  };

};


// ============================================================
// CREATE PENDING PAYMENT
// ============================================================
//
// ONLY creates the payment record.
//
// DOES NOT:
//
// - Post accounting
// - Update obligation
// - Mark completed
//
// ============================================================

const createPendingContributionPayment = async ({
  obligation,
  amount,
  currency,
  payment_channel,
  payment_method,
  payment_instrument_id,
  payment_instrument_snapshot,
  provider,
  provider_status,
  provider_transaction_id,
  external_reference,
  idempotency_key,
  paid_at,
  initiated_at,
  recorded_by,
  notes,
  session
}) => {

  const payment =
    new ContributionPayment({

      obligation_id:
        obligation._id,

      plan_id:
        obligation.plan_id,

      owner_type:
        obligation.owner_type,

      owner_id:
        obligation.owner_id,

      participant_type:
        obligation.participant_type,

      participant_id:
        obligation.participant_id,

      amount:
        mongoose.Types.Decimal128
          .fromString(
            amount.toFixed()
          ),

      currency,

      payment_channel,

      payment_method,

      payment_instrument_id:
        payment_instrument_id ||
        null,

      payment_instrument_snapshot:
        payment_instrument_snapshot ||
        null,

      provider:
        provider ||
        null,

      provider_status:
        provider_status ||
        null,

      provider_transaction_id:
        provider_transaction_id ||
        null,

      external_reference:
        external_reference ||
        null,

      idempotency_key:
        idempotency_key ||
        null,

      reference:
        generatePaymentReference(),

      status:
        PENDING_STATUS,

      paid_at:
        paid_at ||
        null,

      initiated_at:
        initiated_at ||
        new Date(),

      completed_at:
        null,

      failed_at:
        null,

      failure_reason:
        null,

      callback_received_at:
        null,

      reconciliation_status:
        payment_channel === 'cash'
          ? 'not_required'
          : 'pending',

      recorded_by:
        recorded_by ||
        null,

      financial_transaction_id:
        null,

      reversal_transaction_id:
        null,

      verified_by:
        null,

      verified_at:
        null,

      reversed_by:
        null,

      reversed_at:
        null,

      reversal_reason:
        null,

      notes:
        notes ||
        ''

    });

  await payment.save({

    session

  });

  return payment;

};


// ============================================================
// ATOMICALLY APPLY PAYMENT TO OBLIGATION
// ============================================================

const atomicallyApplyPaymentToObligation = async ({
  obligation,
  paymentAmount,
  session
}) => {

  const expectedAmount =
    toDecimal(
      obligation.expected_amount
    );

  const currentPaidAmount =
    toDecimal(
      obligation.paid_amount
    );

  const newPaidAmount =
    determineNewPaidAmount({

      paidAmount:
        currentPaidAmount,

      paymentAmount,

      expectedAmount

    });

  const isFullyPaid =
    isMoneyEqual(
      newPaidAmount,
      expectedAmount
    );

  const newStatus =
    isFullyPaid
      ? 'paid'
      : 'partially_paid';

  const updatedObligation =
    await ContributionObligation
      .findOneAndUpdate(

        {

          _id:
            obligation._id,

          owner_type:
            obligation.owner_type,

          owner_id:
            obligation.owner_id,

          participant_type:
            obligation.participant_type,

          participant_id:
            obligation.participant_id,

          status: {

            $nin: [

              'cancelled',

              'waived',

              'paid'

            ]

          },

          paid_amount:
            obligation.paid_amount

        },

        {

          $set: {

            paid_amount:
              mongoose.Types.Decimal128
                .fromString(
                  newPaidAmount.toFixed()
                ),

            status:
              newStatus

          }

        },

        {

          new:
            true,

          session,

          runValidators:
            true

        }

      );

  if (
    !updatedObligation
  ) {

    throw new AppError(
      'Contribution obligation was modified by another transaction. Please retry the payment.',
      409
    );

  }

  return {

    obligation:
      updatedObligation,

    newPaidAmount

  };

};


// ============================================================
// ATOMICALLY REVERSE PAYMENT FROM OBLIGATION
// ============================================================

const atomicallyReversePaymentFromObligation = async ({
  obligation,
  paymentAmount,
  session
}) => {

  const currentPaidAmount =
    toDecimal(
      obligation.paid_amount
    );

  if (
    currentPaidAmount.lessThan(
      paymentAmount
    )
  ) {

    throw new AppError(
      'Cannot reverse payment because obligation paid amount is smaller than payment amount',
      409
    );

  }

  const newPaidAmount =
    subtractMoney(
      currentPaidAmount,
      paymentAmount
    );

  const expectedAmount =
    toDecimal(
      obligation.expected_amount
    );

  let newStatus;

  if (
    newPaidAmount.isZero()
  ) {

    newStatus =
      'pending';

  } else if (
    newPaidAmount.lessThan(
      expectedAmount
    )
  ) {

    newStatus =
      'partially_paid';

  } else {

    newStatus =
      'paid';

  }

  const updatedObligation =
    await ContributionObligation
      .findOneAndUpdate(

        {

          _id:
            obligation._id,

          paid_amount:
            obligation.paid_amount

        },

        {

          $set: {

            paid_amount:
              mongoose.Types.Decimal128
                .fromString(
                  newPaidAmount.toFixed()
                ),

            status:
              newStatus

          }

        },

        {

          new:
            true,

          session,

          runValidators:
            true

        }

      );

  if (
    !updatedObligation
  ) {

    throw new AppError(
      'Contribution obligation was modified by another transaction. Payment reversal must be retried.',
      409
    );

  }

  return updatedObligation;

};


// ============================================================
// VALIDATE ORIGINAL PAYMENT TRANSACTION
// ============================================================

const validateOriginalPaymentTransaction = ({
  transaction,
  payment
}) => {

  if (
    !transaction
  ) {

    throw new AppError(
      'Original financial transaction for contribution payment was not found',
      500
    );

  }

  if (
    transaction.owner_type !==
    payment.owner_type ||

    String(
      transaction.owner_id
    ) !==
    String(
      payment.owner_id
    )
  ) {

    throw new AppError(
      'Original financial transaction does not belong to the contribution payment owner',
      500
    );

  }

  if (
    transaction.transaction_type !==
    CONTRIBUTION_PAYMENT_TRANSACTION_TYPE
  ) {

    throw new AppError(
      'Original financial transaction is not a contribution payment transaction',
      500
    );

  }

  if (
    transaction.source_type !==
    'ContributionPayment'
  ) {

    throw new AppError(
      'Original financial transaction source type is invalid',
      500
    );

  }

  if (
    String(
      transaction.source_id
    ) !==
    String(
      payment._id
    )
  ) {

    throw new AppError(
      'Original financial transaction does not reference this contribution payment',
      500
    );

  }

  return transaction;

};


// ============================================================
// FIND ORIGINAL PAYMENT ACCOUNT
// ============================================================

const findOriginalPaymentAccount = async ({
  transaction,
  payment,
  currency,
  session
}) => {

  const debitEntries =
    transaction.entries
      ?.filter(
        entry =>
          entry.entry_type ===
          'debit'
      ) || [];

  if (
    debitEntries.length !==
    1
  ) {

    throw new AppError(
      'Original contribution payment transaction must contain exactly one debit payment account',
      500
    );

  }

  const originalDebitEntry =
    debitEntries[0];

  return validateFinancialAccount({

    accountId:
      originalDebitEntry.account_id,

    ownerType:
      payment.owner_type,

    ownerId:
      payment.owner_id,

    currency,

    accountLabel:
      'Original payment',

    session

  });

};


// ============================================================
// POST CONTRIBUTION ACCOUNTING TRANSACTION
// ============================================================

const postContributionAccountingTransaction = async ({
  payment,
  paymentAccount,
  contributionReceivableAccount,
  created_by,
  posted_by,
  description,
  session
}) => {

  const paymentAmount =
    validatePaymentAmount(
      payment.amount
    );

  const paymentCurrency =
    validateCurrency(
      payment.currency
    );

  return postFinancialTransaction({

    owner_type:
      payment.owner_type,

    owner_id:
      payment.owner_id,

    transaction_type:
      CONTRIBUTION_PAYMENT_TRANSACTION_TYPE,

    amount:
      paymentAmount,

    currency:
      paymentCurrency,

    source_type:
      'ContributionPayment',

    source_id:
      payment._id,

    description:
      description ||
      `Contribution payment received for obligation ${payment.obligation_id}`,

    external_reference:
      payment.external_reference,

    created_by,

    posted_by:
      posted_by ||
      created_by,

    entries: [

      {

        account_id:
          paymentAccount._id,

        entry_type:
          'debit',

        amount:
          paymentAmount,

        description:
          'Contribution payment received'

      },

      {

        account_id:
          contributionReceivableAccount._id,

        entry_type:
          'credit',

        amount:
          paymentAmount,

        description:
          'Contribution receivable settled'

      }

    ],

    session

  });

};


// ============================================================
// COMPLETE CONTRIBUTION PAYMENT
// ============================================================
//
// CENTRAL PAYMENT COMPLETION LIFECYCLE.
//
// pending
//   │
//   ├── Validate provider success
//   ├── Validate provider reference
//   ├── Validate obligation
//   ├── Validate accounts
//   ├── Post financial transaction
//   ├── Atomically update obligation
//   └── Mark payment completed
//
// ============================================================

export const completeContributionPayment = async ({
  payment_id,
  provider_transaction_id = null,
  provider_status = 'success',
  external_reference = null,
  callback_received_at = null,
  payment_account_id,
  created_by,
  posted_by = null,
  description = '',
  session:
    existingSession = null
}) => {

  validateObjectId(
    payment_id,
    'contribution payment ID'
  );

  validateObjectId(
    created_by,
    'payment completion creator ID'
  );

  validateObjectId(
    payment_account_id,
    'payment financial account ID'
  );

  const normalizedProviderStatus =
    validateProviderStatus(
      provider_status
    );

  if (
    normalizedProviderStatus !==
    'success'
  ) {

    throw new AppError(
      'Only successful provider payments can be completed',
      400
    );

  }

  const normalizedProviderTransactionId =
    validateProviderTransactionId(
      provider_transaction_id
    );

  const normalizedExternalReference =
    validateExternalReference(
      external_reference
    );

  const ownsSession =
    !existingSession;

  const session =
    existingSession ||
    await mongoose.startSession();

  try {

    if (
      ownsSession
    ) {

      session.startTransaction();

    }

    // ======================================================
    // LOAD PAYMENT
    // ======================================================

    const payment =
      await ContributionPayment
        .findById(
          payment_id
        )
        .session(session);

    if (
      !payment
    ) {

      throw new AppError(
        'Contribution payment not found',
        404
      );

    }

    // ======================================================
    // IDEMPOTENT COMPLETION
    // ======================================================

    if (
      payment.status ===
      PAYMENT_STATUS
    ) {

      if (
        normalizedProviderTransactionId &&
        payment.provider_transaction_id &&
        payment.provider_transaction_id !==
        normalizedProviderTransactionId
      ) {

        throw new AppError(
          'Payment is already completed with a different provider transaction ID',
          409
        );

      }

      if (
        ownsSession
      ) {

        await session.commitTransaction();

      }

      return {

        payment,

        obligation:
          await ContributionObligation
            .findById(
              payment.obligation_id
            )
            .session(session),

        financialTransaction:
          payment.financial_transaction_id
            ? await FinancialTransaction
                .findById(
                  payment.financial_transaction_id
                )
                .session(session)
            : null,

        existing:
          true

      };

    }

    if (
      payment.status !==
      PENDING_STATUS
    ) {

      throw new AppError(
        `Contribution payment cannot be completed from status "${payment.status}"`,
        409
      );

    }

    // ======================================================
    // VALIDATE PAYMENT
    // ======================================================

    const paymentAmount =
      validatePaymentAmount(
        payment.amount
      );

    const paymentCurrency =
      validateCurrency(
        payment.currency
      );

    const provider =
      validateProvider(
        payment.provider
      );

    // ======================================================
    // PROVIDER TRANSACTION DUPLICATE CHECK
    // ======================================================

    await checkDuplicateProviderTransaction({

      provider,

      provider_transaction_id:
        normalizedProviderTransactionId,

      session,

      excludePaymentId:
        payment._id

    });

    // ======================================================
    // EXTERNAL REFERENCE DUPLICATE CHECK
    // ======================================================

    if (
      normalizedExternalReference
    ) {

      await checkDuplicateExternalReference({

        external_reference:
          normalizedExternalReference,

        owner_type:
          payment.owner_type,

        owner_id:
          payment.owner_id,

        session,

        excludePaymentId:
          payment._id

      });

    }

    // ======================================================
    // LOAD OBLIGATION
    // ======================================================

    const obligation =
      await ContributionObligation
        .findById(
          payment.obligation_id
        )
        .session(session);

    if (
      !obligation
    ) {

      throw new AppError(
        'Contribution obligation associated with payment was not found',
        404
      );

    }

    validateObligationStatus(
      obligation
    );

    const obligationCurrency =
      validateCurrency(
        obligation.currency
      );

    if (
      obligationCurrency !==
      paymentCurrency
    ) {

      throw new AppError(
        'Payment currency does not match contribution obligation currency',
        400
      );

    }

    // ======================================================
    // VALIDATE REMAINING OBLIGATION
    // ======================================================

    const {
      remainingAmount
    } =
      calculateRemainingAmount(
        obligation
      );

    validateNoOverpayment({

      paymentAmount,

      remainingAmount

    });

    // ======================================================
    // VALIDATE PAYMENT ACCOUNT
    // ======================================================

    const paymentAccount =
      await validateFinancialAccount({

        accountId:
          payment_account_id,

        ownerType:
          payment.owner_type,

        ownerId:
          payment.owner_id,

        currency:
          paymentCurrency,

        accountLabel:
          'Payment',

        session

      });

    // ======================================================
    // GET RECEIVABLE ACCOUNT
    // ======================================================

    const contributionReceivableAccount =
      await getContributionReceivableAccount({

        owner_type:
          payment.owner_type,

        owner_id:
          payment.owner_id,

        currency:
          paymentCurrency,

        session

      });

    // ======================================================
    // POST FINANCIAL TRANSACTION
    // ======================================================

    const financialTransaction =
      await postContributionAccountingTransaction({

        payment,

        paymentAccount,

        contributionReceivableAccount,

        created_by,

        posted_by:
          posted_by ||
          created_by,

        description,

        session

      });

    // ======================================================
    // ATOMICALLY APPLY PAYMENT
    // ======================================================

    const {
      obligation:
        updatedObligation
    } =
      await atomicallyApplyPaymentToObligation({

        obligation,

        paymentAmount,

        session

      });

    // ======================================================
    // FINALIZE PAYMENT
    // ======================================================

    const completedPayment =
      await ContributionPayment
        .findOneAndUpdate(

          {

            _id:
              payment._id,

            status:
              PENDING_STATUS,

            financial_transaction_id:
              null

          },

          {

            $set: {

              status:
                PAYMENT_STATUS,

              financial_transaction_id:
                financialTransaction._id,

              provider_transaction_id:
                normalizedProviderTransactionId ||
                payment.provider_transaction_id,

              provider_status:
                normalizedProviderStatus,

              external_reference:
                normalizedExternalReference ||
                payment.external_reference,

              callback_received_at:
                callback_received_at ||
                new Date(),

              completed_at:
                new Date(),

              paid_at:
                payment.paid_at ||
                new Date(),

              reconciliation_status:
                payment.payment_channel ===
                'cash'
                  ? 'not_required'
                  : 'pending'

            }

          },

          {

            new:
              true,

            session,

            runValidators:
              true

          }

        );

    if (
      !completedPayment
    ) {

      throw new AppError(
        'Contribution payment could not be completed because it was modified by another process',
        409
      );

    }

    if (
      ownsSession
    ) {

      await session.commitTransaction();

    }

    return {

      payment:
        completedPayment,

      obligation:
        updatedObligation,

      financialTransaction,

      existing:
        false

    };

  } catch (error) {

    if (
      ownsSession &&
      session.inTransaction()
    ) {

      await session.abortTransaction();

    }

    if (
      error?.code ===
      11000
    ) {

      throw new AppError(
        'Duplicate payment reference, provider transaction, external reference, or idempotency key detected',
        409
      );

    }

    throw error;

  } finally {

    if (
      ownsSession
    ) {

      await session.endSession();

    }

  }

};


// ============================================================
// CREATE CONTRIBUTION PAYMENT
// ============================================================
//
// Digital:
//
// createContributionPayment()
//        ↓
// pending
//        ↓
// Provider
//        ↓
// completeContributionPayment()
//
// Cash:
//
// createContributionPayment()
//        ↓
// pending
//        ↓
// completeContributionPayment()
//        ↓
// completed
//
// ============================================================

export const createContributionPayment = async ({
  obligation_id,
  owner_type,
  owner_id,
  participant_type,
  participant_id,
  amount,
  currency = 'KES',

  payment_channel,

  payment_method = null,

  payment_instrument_id = null,

  payment_instrument_snapshot = null,

  provider = null,

  external_reference = null,

  idempotency_key = null,

  description = '',

  paid_at = null,

  initiated_at = null,

  recorded_by = null,

  created_by,

  posted_by = null,

  payment_account_id = null,

  notes = '',

  session:
    existingSession = null
}) => {

  const ownsSession =
    !existingSession;

  const session =
    existingSession ||
    await mongoose.startSession();

  try {

    if (
      ownsSession
    ) {

      session.startTransaction();

    }

    // ======================================================
    // VALIDATION
    // ======================================================

    validateObjectId(
      owner_id,
      'owner ID'
    );

    validateOwnerType(
      owner_type
    );

    validateObjectId(
      participant_id,
      'participant ID'
    );

    validateOwnerParticipantCompatibility({

      owner_type,

      participant_type

    });

    validateObjectId(
      created_by,
      'payment creator ID'
    );

    const paymentRecorder =
      recorded_by ||
      created_by;

    validateObjectId(
      paymentRecorder,
      'payment recorder ID'
    );

    const paymentAmount =
      validatePaymentAmount(
        amount
      );

    const paymentCurrency =
      validateCurrency(
        currency
      );

    const normalizedChannel =
      validatePaymentChannel(
        payment_channel
      );

    const normalizedMethod =
      payment_method
        ? validatePaymentMethod(
            payment_method
          )
        : normalizedChannel;

    const normalizedProvider =
      validateProvider(
        provider
      );

    const normalizedExternalReference =
      validateExternalReference(
        external_reference
      );

    const normalizedIdempotencyKey =
      validateIdempotencyKey(
        idempotency_key
      );

    const normalizedInstrumentSnapshot =
      validatePaymentInstrumentSnapshot(
        payment_instrument_snapshot
      );

    // ======================================================
    // IDEMPOTENCY
    // ======================================================

    const existingPayment =
      await findExistingPaymentByIdempotencyKey({

        idempotency_key:
          normalizedIdempotencyKey,

        owner_type,

        owner_id,

        session

      });

    if (
      existingPayment
    ) {

      if (
        ownsSession
      ) {

        await session.commitTransaction();

      }

      return {

        payment:
          existingPayment,

        existing:
          true

      };

    }

    // ======================================================
    // EXTERNAL REFERENCE
    // ======================================================

    await checkDuplicateExternalReference({

      external_reference:
        normalizedExternalReference,

      owner_type,

      owner_id,

      session

    });

    // ======================================================
    // LOAD OBLIGATION
    // ======================================================

    const obligation =
      await loadContributionObligation({

        obligation_id,

        owner_type,

        owner_id,

        participant_type,

        participant_id,

        session

      });

    validateObligationStatus(
      obligation
    );

    const obligationCurrency =
      validateCurrency(
        obligation.currency
      );

    if (
      obligationCurrency !==
      paymentCurrency
    ) {

      throw new AppError(
        'Payment currency does not match contribution obligation currency',
        400
      );

    }

    // ======================================================
    // VALIDATE REMAINING BALANCE
    // ======================================================

    const {
      remainingAmount
    } =
      calculateRemainingAmount(
        obligation
      );

    validateNoOverpayment({

      paymentAmount,

      remainingAmount

    });

    // ======================================================
    // CREATE PAYMENT SNAPSHOT
    // ======================================================

    const instrumentData =
      createPaymentInstrumentSnapshot({

        payment_channel:
          normalizedChannel,

        payment_instrument_id,

        payment_instrument_snapshot:
          normalizedInstrumentSnapshot

      });

    // ======================================================
    // CREATE PENDING PAYMENT
    // ======================================================

    const payment =
      await createPendingContributionPayment({

        obligation,

        amount:
          paymentAmount,

        currency:
          paymentCurrency,

        payment_channel:
          normalizedChannel,

        payment_method:
          normalizedMethod,

        payment_instrument_id:
          instrumentData
            .payment_instrument_id,

        payment_instrument_snapshot:
          instrumentData
            .payment_instrument_snapshot,

        provider:
          normalizedProvider,

        provider_status:
          normalizedProvider
            ? 'initiated'
            : null,

        provider_transaction_id:
          null,

        external_reference:
          normalizedExternalReference,

        idempotency_key:
          normalizedIdempotencyKey,

        paid_at,

        initiated_at,

        recorded_by:
          paymentRecorder,

        notes,

        session

      });

    // ======================================================
    // CASH PAYMENT
    // ======================================================

    if (
      normalizedChannel ===
      'cash'
    ) {

      if (
        !payment_account_id
      ) {

        throw new AppError(
          'Payment financial account ID is required for cash contribution payments',
          400
        );

      }

      const completion =
        await completeContributionPayment({

          payment_id:
            payment._id,

          provider_transaction_id:
            null,

          provider_status:
            'success',

          external_reference:
            normalizedExternalReference,

          payment_account_id,

          created_by,

          posted_by:
            posted_by ||
            created_by,

          description:
            description ||
            `Cash contribution payment received for obligation ${obligation._id}`,

          session

        });

      if (
        ownsSession
      ) {

        await session.commitTransaction();

      }

      return {

        ...completion,

        existing:
          false

      };

    }

    // ======================================================
    // DIGITAL PAYMENT
    // ======================================================

    if (
      ownsSession
    ) {

      await session.commitTransaction();

    }

    return {

      payment,

      obligation,

      status:
        PENDING_STATUS,

      requiresProviderCompletion:
        true,

      existing:
        false

    };

  } catch (error) {

    if (
      ownsSession &&
      session.inTransaction()
    ) {

      await session.abortTransaction();

    }

    if (
      error?.code ===
      11000
    ) {

      throw new AppError(
        'Duplicate contribution payment detected',
        409
      );

    }

    throw error;

  } finally {

    if (
      ownsSession
    ) {

      await session.endSession();

    }

  }

};


// ============================================================
// LEGACY / MANUAL PAYMENT WRAPPER
// ============================================================

export const postContributionPayment = async ({
  obligation_id,
  owner_type,
  owner_id,
  participant_type,
  participant_id,
  amount,
  currency = 'KES',
  payment_method,
  payment_channel = null,
  payment_account_id,
  payment_instrument_id = null,
  payment_instrument_snapshot = null,
  provider = null,
  external_reference = null,
  idempotency_key = null,
  description = '',
  paid_at = null,
  recorded_by = null,
  created_by,
  posted_by = null,
  notes = '',
  session:
    existingSession = null
}) => {

  const resolvedChannel =
    payment_channel ||
    payment_method;

  return createContributionPayment({

    obligation_id,

    owner_type,

    owner_id,

    participant_type,

    participant_id,

    amount,

    currency,

    payment_channel:
      resolvedChannel,

    payment_method,

    payment_instrument_id,

    payment_instrument_snapshot,

    provider,

    external_reference,

    idempotency_key,

    description,

    paid_at,

    recorded_by,

    created_by,

    posted_by,

    payment_account_id,

    notes,

    session:
      existingSession

  });

};


// ============================================================
// FAIL CONTRIBUTION PAYMENT
// ============================================================
//
// Failed payments:
//
// - Do not affect obligation
// - Do not create accounting transaction
// - Remain in history
//
// ============================================================

export const failContributionPayment = async ({
  payment_id,
  provider_status = 'failed',
  failure_reason,
  callback_received_at = null,
  session:
    existingSession = null
}) => {

  validateObjectId(
    payment_id,
    'contribution payment ID'
  );

  const normalizedProviderStatus =
    validateProviderStatus(
      provider_status
    );

  if (
    normalizedProviderStatus !==
    FAILED_STATUS
  ) {

    throw new AppError(
      'Only failed provider status can mark a contribution payment as failed',
      400
    );

  }

  if (
    !failure_reason ||
    typeof failure_reason !==
    'string'
  ) {

    throw new AppError(
      'A failure reason is required',
      400
    );

  }

  const normalizedReason =
    failure_reason.trim();

  if (
    !normalizedReason
  ) {

    throw new AppError(
      'A failure reason is required',
      400
    );

  }

  const ownsSession =
    !existingSession;

  const session =
    existingSession ||
    await mongoose.startSession();

  try {

    if (
      ownsSession
    ) {

      session.startTransaction();

    }

    const failedPayment =
      await ContributionPayment
        .findOneAndUpdate(

          {

            _id:
              payment_id,

            status:
              PENDING_STATUS

          },

          {

            $set: {

              status:
                FAILED_STATUS,

              provider_status:
                normalizedProviderStatus,

              failed_at:
                new Date(),

              failure_reason:
                normalizedReason,

              callback_received_at:
                callback_received_at ||
                new Date()

            }

          },

          {

            new:
              true,

            session,

            runValidators:
              true

          }

        );

    if (
      !failedPayment
    ) {

      throw new AppError(
        'Contribution payment is not pending or has already been processed',
        409
      );

    }

    if (
      ownsSession
    ) {

      await session.commitTransaction();

    }

    return failedPayment;

  } catch (error) {

    if (
      ownsSession &&
      session.inTransaction()
    ) {

      await session.abortTransaction();

    }

    throw error;

  } finally {

    if (
      ownsSession
    ) {

      await session.endSession();

    }

  }

};


// ============================================================
// CANCEL CONTRIBUTION PAYMENT
// ============================================================

export const cancelContributionPayment = async ({
  payment_id,
  cancelled_by,
  cancellation_reason,
  session:
    existingSession = null
}) => {

  validateObjectId(
    payment_id,
    'contribution payment ID'
  );

  validateObjectId(
    cancelled_by,
    'payment cancellation user ID'
  );

  if (
    !cancellation_reason ||
    typeof cancellation_reason !==
    'string'
  ) {

    throw new AppError(
      'A cancellation reason is required',
      400
    );

  }

  const normalizedReason =
    cancellation_reason.trim();

  if (
    !normalizedReason
  ) {

    throw new AppError(
      'A cancellation reason is required',
      400
    );

  }

  const ownsSession =
    !existingSession;

  const session =
    existingSession ||
    await mongoose.startSession();

  try {

    if (
      ownsSession
    ) {

      session.startTransaction();

    }

    const payment =
      await ContributionPayment
        .findOneAndUpdate(

          {

            _id:
              payment_id,

            status:
              PENDING_STATUS

          },

          {

            $set: {

              status:
                CANCELLED_STATUS,

              failure_reason:
                normalizedReason,

              failed_at:
                new Date()

            }

          },

          {

            new:
              true,

            session,

            runValidators:
              true

          }

        );

    if (
      !payment
    ) {

      throw new AppError(
        'Only pending contribution payments can be cancelled',
        409
      );

    }

    if (
      ownsSession
    ) {

      await session.commitTransaction();

    }

    return payment;

  } catch (error) {

    if (
      ownsSession &&
      session.inTransaction()
    ) {

      await session.abortTransaction();

    }

    throw error;

  } finally {

    if (
      ownsSession
    ) {

      await session.endSession();

    }

  }

};


// ============================================================
// VERIFY CONTRIBUTION PAYMENT
// ============================================================
//
// Verification:
//
// - Does not create accounting
// - Does not update obligation
// - Does not alter payment amount
//
// It is an operational control.
//
// ============================================================

export const verifyContributionPayment = async ({
  payment_id,
  verified_by,
  session:
    existingSession = null
}) => {

  validateObjectId(
    payment_id,
    'contribution payment ID'
  );

  validateObjectId(
    verified_by,
    'payment verifier ID'
  );

  const ownsSession =
    !existingSession;

  const session =
    existingSession ||
    await mongoose.startSession();

  try {

    if (
      ownsSession
    ) {

      session.startTransaction();

    }

    const payment =
      await ContributionPayment
        .findById(
          payment_id
        )
        .session(session);

    if (
      !payment
    ) {

      throw new AppError(
        'Contribution payment not found',
        404
      );

    }

    if (
      payment.status !==
      PAYMENT_STATUS
    ) {

      throw new AppError(
        'Only completed contribution payments can be verified',
        400
      );

    }

    if (
      !payment.financial_transaction_id
    ) {

      throw new AppError(
        'Contribution payment has no financial transaction and cannot be verified',
        400
      );

    }

    if (
      payment.verified_by
    ) {

      throw new AppError(
        'Contribution payment has already been verified',
        409
      );

    }

    const updatedPayment =
      await ContributionPayment
        .findOneAndUpdate(

          {

            _id:
              payment_id,

            status:
              PAYMENT_STATUS,

            verified_by:
              null

          },

          {

            $set: {

              verified_by,

              verified_at:
                new Date()

            }

          },

          {

            new:
              true,

            session,

            runValidators:
              true

          }

        );

    if (
      !updatedPayment
    ) {

      throw new AppError(
        'Contribution payment was verified by another process. Please refresh the payment.',
        409
      );

    }

    if (
      ownsSession
    ) {

      await session.commitTransaction();

    }

    return updatedPayment;

  } catch (error) {

    if (
      ownsSession &&
      session.inTransaction()
    ) {

      await session.abortTransaction();

    }

    throw error;

  } finally {

    if (
      ownsSession
    ) {

      await session.endSession();

    }

  }

};


// ============================================================
// REVERSE CONTRIBUTION PAYMENT
// ============================================================
//
// completed
//    │
//    ├── Restore obligation
//    ├── Debit receivable
//    ├── Credit original payment account
//    ├── Save reversal transaction
//    └── Mark payment reversed
//
// Original payment is NEVER deleted.
//
// ============================================================

export const reverseContributionPayment = async ({
  payment_id,
  reversed_by,
  reversal_reason,
  created_by,
  posted_by = null,
  session:
    existingSession = null
}) => {

  validateObjectId(
    payment_id,
    'contribution payment ID'
  );

  validateObjectId(
    reversed_by,
    'payment reverser ID'
  );

  validateObjectId(
    created_by,
    'reversal creator ID'
  );

  const normalizedReason =
    validateReversalReason(
      reversal_reason
    );

  const ownsSession =
    !existingSession;

  const session =
    existingSession ||
    await mongoose.startSession();

  try {

    if (
      ownsSession
    ) {

      session.startTransaction();

    }

    // ======================================================
    // LOAD PAYMENT
    // ======================================================

    const payment =
      await ContributionPayment
        .findById(
          payment_id
        )
        .session(session);

    if (
      !payment
    ) {

      throw new AppError(
        'Contribution payment not found',
        404
      );

    }

    if (
      payment.status ===
      REVERSED_STATUS
    ) {

      throw new AppError(
        'Contribution payment has already been reversed',
        409
      );

    }

    if (
      payment.status !==
      PAYMENT_STATUS
    ) {

      throw new AppError(
        'Only completed contribution payments can be reversed',
        400
      );

    }

    if (
      !payment.financial_transaction_id
    ) {

      throw new AppError(
        'Completed contribution payment is missing its financial transaction',
        500
      );

    }

    // ======================================================
    // VALIDATE PAYMENT
    // ======================================================

    const paymentAmount =
      validatePaymentAmount(
        payment.amount
      );

    const paymentCurrency =
      validateCurrency(
        payment.currency
      );

    // ======================================================
    // LOAD OBLIGATION
    // ======================================================

    const obligation =
      await ContributionObligation
        .findById(
          payment.obligation_id
        )
        .session(session);

    if (
      !obligation
    ) {

      throw new AppError(
        'Contribution obligation associated with payment was not found',
        404
      );

    }

    // ======================================================
    // LOAD ORIGINAL TRANSACTION
    // ======================================================

    const originalTransaction =
      await FinancialTransaction
        .findById(
          payment.financial_transaction_id
        )
        .session(session);

    validateOriginalPaymentTransaction({

      transaction:
        originalTransaction,

      payment

    });

    // ======================================================
    // FIND ORIGINAL PAYMENT ACCOUNT
    // ======================================================

    const originalPaymentAccount =
      await findOriginalPaymentAccount({

        transaction:
          originalTransaction,

        payment,

        currency:
          paymentCurrency,

        session

      });

    // ======================================================
    // GET RECEIVABLE ACCOUNT
    // ======================================================

    const contributionReceivableAccount =
      await getContributionReceivableAccount({

        owner_type:
          payment.owner_type,

        owner_id:
          payment.owner_id,

        currency:
          paymentCurrency,

        session

      });

    // ======================================================
    // RESTORE OBLIGATION
    // ======================================================

    const updatedObligation =
      await atomicallyReversePaymentFromObligation({

        obligation,

        paymentAmount,

        session

      });

    // ======================================================
    // POST REVERSAL TRANSACTION
    // ======================================================

    const reversalTransaction =
      await postFinancialTransaction({

        owner_type:
          payment.owner_type,

        owner_id:
          payment.owner_id,

        transaction_type:
          CONTRIBUTION_PAYMENT_REVERSAL_TRANSACTION_TYPE,

        amount:
          paymentAmount,

        currency:
          paymentCurrency,

        source_type:
          'ContributionPaymentReversal',

        source_id:
          payment._id,

        description:
          `Reversal of contribution payment ${payment.reference}: ${normalizedReason}`,

        external_reference:
          generateReversalReference(
            payment.reference
          ),

        created_by,

        posted_by:
          posted_by ||
          created_by,

        entries: [

          {

            account_id:
              contributionReceivableAccount._id,

            entry_type:
              'debit',

            amount:
              paymentAmount,

            description:
              'Contribution receivable restored after payment reversal'

          },

          {

            account_id:
              originalPaymentAccount._id,

            entry_type:
              'credit',

            amount:
              paymentAmount,

            description:
              'Original payment account credited after contribution payment reversal'

          }

        ],

        session

      });

    // ======================================================
    // MARK PAYMENT REVERSED
    // ======================================================

    const reversedPayment =
      await ContributionPayment
        .findOneAndUpdate(

          {

            _id:
              payment._id,

            status:
              PAYMENT_STATUS,

            reversal_transaction_id:
              null

          },

          {

            $set: {

              status:
                REVERSED_STATUS,

              reversed_at:
                new Date(),

              reversed_by,

              reversal_reason:
                normalizedReason,

              reversal_transaction_id:
                reversalTransaction._id

            }

          },

          {

            new:
              true,

            session,

            runValidators:
              true

          }

        );

    if (
      !reversedPayment
    ) {

      throw new AppError(
        'Contribution payment was already reversed or modified by another process',
        409
      );

    }

    if (
      ownsSession
    ) {

      await session.commitTransaction();

    }

    return {

      payment:
        reversedPayment,

      obligation:
        updatedObligation,

      reversalTransaction

    };

  } catch (error) {

    if (
      ownsSession &&
      session.inTransaction()
    ) {

      await session.abortTransaction();

    }

    throw error;

  } finally {

    if (
      ownsSession
    ) {

      await session.endSession();

    }

  }

};


// ============================================================
// GET CONTRIBUTION PAYMENT BY ID
// ============================================================

export const getContributionPaymentById = async ({
  payment_id,
  session = null
}) => {

  validateObjectId(
    payment_id,
    'contribution payment ID'
  );

  const payment =
    await ContributionPayment
      .findById(
        payment_id
      )
      .session(session);

  if (
    !payment
  ) {

    throw new AppError(
      'Contribution payment not found',
      404
    );

  }

  return payment;

};


// ============================================================
// GET PAYMENTS FOR OBLIGATION
// ============================================================

export const getPaymentsForObligation = async ({
  obligation_id,
  status = PAYMENT_STATUS,
  session = null
}) => {

  validateObjectId(
    obligation_id,
    'contribution obligation ID'
  );

  if (
    status
  ) {

    validatePaymentStatus(
      status
    );

  }

  const query = {

    obligation_id

  };

  if (
    status
  ) {

    query.status =
      status;

  }

  return ContributionPayment
    .find(
      query
    )
    .sort({

      paid_at:
        -1,

      createdAt:
        -1

    })
    .session(session);

};


// ============================================================
// GET OWNER CONTRIBUTION PAYMENTS
// ============================================================

export const getOwnerContributionPayments = async ({
  owner_type,
  owner_id,
  status = null,
  participant_type = null,
  participant_id = null,
  payment_channel = null,
  provider = null,
  session = null
}) => {

  validateObjectId(
    owner_id,
    'owner ID'
  );

  validateOwnerType(
    owner_type
  );

  if (
    participant_id &&
    !participant_type
  ) {

    throw new AppError(
      'participant_type is required when participant_id is provided',
      400
    );

  }

  const query = {

    owner_type,

    owner_id

  };

  if (
    status
  ) {

    validatePaymentStatus(
      status
    );

    query.status =
      status;

  }

  if (
    participant_type
  ) {

    validateOwnerParticipantCompatibility({

      owner_type,

      participant_type

    });

    query.participant_type =
      participant_type;

  }

  if (
    participant_id
  ) {

    validateObjectId(
      participant_id,
      'participant ID'
    );

    query.participant_id =
      participant_id;

  }

  if (
    payment_channel
  ) {

    query.payment_channel =
      validatePaymentChannel(
        payment_channel
      );

  }

  if (
    provider
  ) {

    query.provider =
      validateProvider(
        provider
      );

  }

  return ContributionPayment
    .find(
      query
    )
    .sort({

      paid_at:
        -1,

      createdAt:
        -1

    })
    .session(session);

};


// ============================================================
// GET PARTICIPANT PAYMENTS
// ============================================================

export const getParticipantContributionPayments = async ({
  participant_type,
  participant_id,
  status = null,
  payment_channel = null,
  session = null
}) => {

  validateParticipantType(
    participant_type
  );

  validateObjectId(
    participant_id,
    'participant ID'
  );

  const query = {

    participant_type,

    participant_id

  };

  if (
    status
  ) {

    validatePaymentStatus(
      status
    );

    query.status =
      status;

  }

  if (
    payment_channel
  ) {

    query.payment_channel =
      validatePaymentChannel(
        payment_channel
      );

  }

  return ContributionPayment
    .find(
      query
    )
    .sort({

      paid_at:
        -1,

      createdAt:
        -1

    })
    .session(session);

};


// ============================================================
// GET PAYMENT BY EXTERNAL REFERENCE
// ============================================================

export const getContributionPaymentByExternalReference = async ({
  external_reference,
  owner_type = null,
  owner_id = null,
  session = null
}) => {

  const normalizedReference =
    validateExternalReference(
      external_reference
    );

  if (
    !normalizedReference
  ) {

    throw new AppError(
      'External payment reference is required',
      400
    );

  }

  const query = {

    external_reference:
      normalizedReference

  };

  if (
    owner_type
  ) {

    validateOwnerType(
      owner_type
    );

    query.owner_type =
      owner_type;

  }

  if (
    owner_id
  ) {

    validateObjectId(
      owner_id,
      'owner ID'
    );

    query.owner_id =
      owner_id;

  }

  return ContributionPayment
    .findOne(
      query
    )
    .session(session);

};


// ============================================================
// GET PAYMENT BY PROVIDER TRANSACTION
// ============================================================

export const getContributionPaymentByProviderTransaction = async ({
  provider,
  provider_transaction_id,
  session = null
}) => {

  const normalizedProvider =
    validateProvider(
      provider
    );

  const normalizedTransactionId =
    validateProviderTransactionId(
      provider_transaction_id
    );

  if (
    !normalizedProvider ||
    !normalizedTransactionId
  ) {

    throw new AppError(
      'Provider and provider transaction ID are required',
      400
    );

  }

  return ContributionPayment
    .findOne({

      provider:
        normalizedProvider,

      provider_transaction_id:
        normalizedTransactionId

    })
    .session(session);

};


// ============================================================
// CALCULATE OBLIGATION PAYMENT TOTAL
// ============================================================
//
// Only completed payments count.
//
// Reversed payments are excluded.
//
// ============================================================

export const calculateObligationPaymentTotal = async ({
  obligation_id,
  session = null
}) => {

  validateObjectId(
    obligation_id,
    'contribution obligation ID'
  );

  const payments =
    await ContributionPayment
      .find({

        obligation_id,

        status:
          PAYMENT_STATUS

      })
      .select(
        'amount currency'
      )
      .session(session);

  let total =
    toDecimal(
      '0'
    );

  let currency =
    null;

  for (
    const payment
    of payments
  ) {

    const paymentCurrency =
      validateCurrency(
        payment.currency
      );

    if (
      currency &&
      currency !==
      paymentCurrency
    ) {

      throw new AppError(
        'Contribution obligation payments contain multiple currencies',
        500
      );

    }

    currency =
      paymentCurrency;

    total =
      addMoney(

        total,

        toDecimal(
          payment.amount
        )

      );

  }

  return {

    total,

    currency,

    paymentCount:
      payments.length

  };

};


// ============================================================
// RECONCILE OBLIGATION PAYMENT BALANCE
// ============================================================

export const reconcileContributionObligationPayments = async ({
  obligation_id,
  session = null
}) => {

  validateObjectId(
    obligation_id,
    'contribution obligation ID'
  );

  const obligation =
    await ContributionObligation
      .findById(
        obligation_id
      )
      .session(session);

  if (
    !obligation
  ) {

    throw new AppError(
      'Contribution obligation not found',
      404
    );

  }

  const {

    total,

    currency,

    paymentCount

  } =
    await calculateObligationPaymentTotal({

      obligation_id,

      session

    });

  const obligationPaidAmount =
    toDecimal(
      obligation.paid_amount
    );

  const obligationCurrency =
    validateCurrency(
      obligation.currency
    );

  if (
    currency &&
    currency !==
    obligationCurrency
  ) {

    throw new AppError(
      'Contribution payment currency does not match obligation currency during reconciliation',
      500
    );

  }

  const isBalanced =
    isMoneyEqual(

      obligationPaidAmount,

      total

    );

  return {

    obligation_id:
      obligation._id,

    obligationPaidAmount,

    recordedPaymentTotal:
      total,

    paymentCount,

    currency:
      obligationCurrency,

    isBalanced

  };

};


// ============================================================
// EXPORT HELPERS
// ============================================================

export {

  validateObjectId,

  validateOwnerType,

  validateParticipantType,

  validateOwnerParticipantCompatibility,

  validatePaymentChannel,

  validatePaymentMethod,

  validatePaymentStatus,

  validateProviderStatus,

  validateReconciliationStatus,

  validatePaymentAmount,

  validateCurrency,

  validateExternalReference,

  validateProvider,

  validateProviderTransactionId,

  validateIdempotencyKey,

  validatePaymentInstrumentSnapshot,

  validateReversalReason,

  generatePaymentReference,

  generateReversalReference,

  calculateRemainingAmount,

  validateNoOverpayment,

  determineNewPaidAmount,

  validateFinancialAccount,

  getContributionReceivableAccount,

  createPaymentInstrumentSnapshot,

  createPendingContributionPayment,

  atomicallyApplyPaymentToObligation,

  atomicallyReversePaymentFromObligation,

  validateOriginalPaymentTransaction,

  findOriginalPaymentAccount

};